function [rows,cacheInfo]=v8_smooth_study(cache,folder,options)
% Separate paired numerical-settings study; V6/V7 sources are read-only.
% cache is a struct array with dataset,p,d,alpha,selectionValid,SetupSeconds.
% v8_smooth_study([],folder,struct('TestsOnly',true)) runs bounded fixtures.
if nargin<1,cache=[];end
if nargin<2||isempty(folder),folder=fullfile(fileparts(mfilename('fullpath')),'outputs');end
if nargin<3,options=struct;end
if ~exist(folder,'dir'),mkdir(folder);end
cacheInfo=struct([]);
if option('TestsOnly',false),rows=fixtures(folder);return;end
if iscell(cache),cache=[cache{:}];end
assert(isstruct(cache)&&~isempty(cache),'A prepared dataset cache struct array is required.');
variants=struct('label',{'beta_5e-2_fixed','beta_1e-6_fixed','beta_1e-4_fixed', ...
 'beta_1e-3_fixed','beta_1e-2_fixed','beta_1e-3_adaptive','beta_1e-3_continuation'}, ...
 'beta',{.05,1e-6,1e-4,1e-3,1e-2,1e-3,1e-3}, ...
 'adaptive',{false,false,false,false,false,true,false}, ...
 'continuation',{false,false,false,false,false,false,true});
rows=struct([]);
for di=1:numel(cache)
 entry=cache(di);p=entry.p;alpha=entry.alpha;
 assert(isfinite(alpha)&&alpha>0,'Stored positive parent Tikhonov alpha is required.');
 selectionValid=false;
 if isfield(entry,'selectionValid'),selectionValid=entry.selectionValid;
 elseif isfield(entry,'parentSelectionValid'),selectionValid=entry.parentSelectionValid;end
 setupTimer=tic;p.v8SmoothPrepared=prepare(p,alpha);familySetup=toc(setupTimer);
 rootSetup=0;if isfield(entry,'SetupSeconds'),rootSetup=entry.SetupSeconds;end
 setup=struct('dataset',entry.dataset,'FamilySetupSeconds',familySetup, ...
  'RootSetupSeconds',rootSetup,'TotalSetupSeconds',familySetup+rootSetup, ...
  'alpha',alpha,'inheritedSelectionValid',logical(selectionValid));
 cacheInfo=[cacheInfo;setup]; %#ok<AGROW>
 for vi=1:numel(variants)
  variant=variants(vi);settings=struct('beta',variant.beta,'adaptive',variant.adaptive, ...
   'earlyTolerance',1e-7,'finalTolerance',1e-13,'damping',1e-10, ...
   'maxIterations',option('MaxIterations',20),'maxLSQRIterations',option('MaxLSQRIterations',300), ...
   'qrLimit',option('QRLimit',64),'maxSeconds',option('MaxSeconds',25));
  recordOptions=settings;recordOptions.SetupSeconds=setup.TotalSetupSeconds;
  recordOptions.Continuation=variant.continuation;recordOptions.StoredParentAlpha=alpha;
  recordOptions.InheritedSelectionValid=logical(selectionValid);
  fprintf('\nSMOOTH8 %s %s beta%.3g adaptive%d continuation%d\n',entry.dataset,variant.label,variant.beta,variant.adaptive,variant.continuation);
  timer=tic;
  try
   if variant.continuation
    [x,info]=continued(p,alpha,settings);
   else
    [x,info]=v8_smooth_candidate(p,alpha,p.zero,settings);
   end
  catch err
   x=p.zero;info=struct('converged',false,'success',false,'iterations',0,'kkt',Inf, ...
    'objective',NaN,'error',getReport(err,'extended','hyperlinks','off'));
   fprintf(2,'%s\n',info.error);
  end
  seconds=toc(timer);
  % The recorder, not the optimization or setting selection, consults truth.
  row=v8_record_result(entry.dataset,'Tikhonov',variant.label,x,info,p,entry.d, ...
   alpha,logical(selectionValid),seconds,recordOptions,folder);
  rows=[rows;row]; %#ok<AGROW>
 end
end
save(fullfile(folder,'smooth_cache_info.mat'),'cacheInfo','-v7');
 function value=option(name,default)
  if isfield(options,name),value=options.(name);else,value=default;end
 end
end

function prepared=prepare(p,alpha)
if isfield(p,'tikhFactor'),L=p.tikhFactor;
else,L=p.g.L/sqrt(max(norm(p.g.L'*p.g.L,inf),eps));end
factorError=norm(L'*L-p.R,'fro')/max(norm(p.R,'fro'),eps);
assert(factorError<1e-10,'Original penalty factor convention mismatch.');
C=[p.B;sqrt(alpha)*L];b=[p.b;zeros(size(L,1),1)];
column=sqrt(full(sum(C.^2,1)))';S=ones(p.n,1);positive=column>0;S(positive)=1./column(positive);
prepared=struct('L',L,'C',C,'b',b,'S',S,'alpha',alpha,'factorError',factorError);
end

function [x,info]=continued(p,alpha,settings)
% SAME final target objective. Total outer budget is shared, not tripled.
factors=[30 sqrt(30) 1];weights=[.2 .2 .6];cap=settings.maxIterations;
outer=[floor(.2*cap) floor(.2*cap) 0];outer(3)=cap-sum(outer(1:2));
x=p.zero;stages=struct([]);timer=tic;totalIterations=0;totalInner=0;
for k=1:numel(factors)
 remaining=max(0,settings.maxSeconds-toc(timer));stage=settings;
 stage.maxIterations=outer(k);
 if k<3,stage.maxSeconds=min(remaining,weights(k)*settings.maxSeconds);
 else,stage.maxSeconds=remaining;end
 if k==3
  stage.minIterations=1;
  if isfield(settings,'continuationMinIterations'),stage.minIterations=settings.continuationMinIterations;end
 end
 stageTimer=tic;[x,current]=v8_smooth_candidate(p,alpha*factors(k),x,stage);
 stages=[stages;struct('alpha',alpha*factors(k),'iterations',current.iterations, ...
  'innerLSQRIterations',current.innerLSQRIterations,'seconds',toc(stageTimer), ...
  'converged',current.converged,'kkt',current.kkt,'objective',current.objective, ...
  'budgetStopped',current.budgetStopped,'attemptedIterations',current.attemptedIterations, ...
  'minimumRequiredIterations',current.minimumRequiredIterations)]; %#ok<AGROW>
 totalIterations=totalIterations+current.iterations;totalInner=totalInner+current.innerLSQRIterations;
end
info=current;info.iterations=totalIterations;info.innerLSQRIterations=totalInner;
info.continuationStages=stages;info.finalObjectiveAlpha=alpha;
info.totalContinuationSeconds=toc(timer);
info.continuationUsesTruth=false;info.finalTargetCertificateOnly=true;
end

function report=fixtures(folder)
% Independent dense-reference fixtures, not merely matching implementation.
c=v7_config;c.revisionTrace=false;results=struct([]);
diagonal=[1;1e-12;1e-6;1e6];B=diag(diagonal);b=B*[1;2;3;4];L=eye(4);
p=make(B,b,L,c);alpha=1e-24;reference=(diagonal.*b)./(diagonal.^2+alpha);
settings=struct('maxIterations',200,'maxLSQRIterations',1000,'maxSeconds',10,'qrLimit',192);
[x,info]=v8_smooth_candidate(p,alpha,p.zero,settings);
assert(info.converged&&norm(x-reference,inf)<1e-6,'Weak-column exact diagonal reference failed');
checkObjective(p,alpha,x,info);results=[results;summary('diagonal reference',info)]; %#ok<AGROW>
A=[eye(6);.3 .5 .8 .1 .2 .9;.9 .1 .4 .8 .5 .2;.1 .9 .3 .2 .8 .5; ...
 .7 .2 .1 .9 .3 .4;.4 .6 .9 .3 .1 .7;.8 .4 .2 .5 .7 .1];
W=diag(logspace(-6,6,size(A,1)));b=W*A*[1;0;.3;0;.8;0]+.02*sin((1:size(A,1))');
L=[diff(eye(6),2);.01*eye(6)];p=make(W*A,b,L,c);alpha=.25;
[reference,referenceObjective]=enumerate([p.B;sqrt(alpha)*L],[b;zeros(size(L,1),1)]);
for beta=[.05 1e-6 1e-4 1e-3 1e-2]
 settings.beta=beta;settings.qrLimit=0;settings.adaptive=false;
 [x,info]=v8_smooth_candidate(p,alpha,p.zero,settings);
 assert(info.converged&&norm(x-reference,inf)<5e-4,'LSQR independent reference beta%.3g failed',beta);
 assert(abs(info.objective-referenceObjective)<=1e-6*max(1,referenceObjective));
 checkObjective(p,alpha,x,info);
 bound=v8_tikhonov_certificate(p,alpha,x);
 assert(bound.dualObjective<=referenceObjective+1e-7*max(1,referenceObjective),'Dual lower bound exceeds independent optimum');
 results=[results;summary(sprintf('independent beta%.3g',beta),info)]; %#ok<AGROW>
end
% With matching numerical settings, default V8 exactly reproduces BOTH V7 arms.
p.c.v7SmoothIterations=200;p.c.v7StrongIterations=200;
p.c.v7SmoothLSQRIterations=1000;p.c.v7StrongLSQRIterations=1000;
p.c.v7SmoothQRLimit=0;p.c.v7StrongQRLimit=0;
p.c.v7SmoothMaxSeconds=10;p.c.v7StrongMaxSeconds=10;
for beta=[.05 1e-6]
 settings.beta=beta;settings.adaptive=false;
 [x,new]=v8_smooth_candidate(p,alpha,p.zero,settings);
 if beta==.05,[oldX,old]=v7_smooth_candidate(p,alpha,'Tikhonov',p.zero);
 else,[oldX,old]=v7_strong_candidate(p,alpha,'Tikhonov',p.zero);end
 assert(norm(x-oldX,inf)<1e-11&&abs(new.objective-old.objective)<1e-11);
 assert(new.converged==old.converged&&abs(new.kkt-old.kkt)<1e-11,'V7 certificate changed');
end
settings.beta=1e-3;settings.adaptive=true;
[x,adaptive]=v8_smooth_candidate(p,alpha,p.zero,settings);
assert(adaptive.converged&&norm(x-reference,inf)<5e-4);checkObjective(p,alpha,x,adaptive);
assert(all(adaptive.toleranceHistory>=1e-13*(1-1e-12))&&all(adaptive.toleranceHistory<=1e-7*(1+1e-12)));
assert(~isempty(adaptive.toleranceHistory)&&abs(adaptive.toleranceHistory(1)/1e-7-1)<1e-12);
results=[results;summary('adaptive inner tolerance',adaptive)]; %#ok<AGROW>
% Prepared family cache is numerically identical and contains no truth.
p.v8SmoothPrepared=prepare(p,alpha);[cached,ci]=v8_smooth_candidate(p,alpha,p.zero,settings);
assert(norm(cached-x,inf)<1e-11&&abs(ci.objective-adaptive.objective)<1e-11);
% Retain the hard12-decade example and expose the prior stopping weakness.
% Its numerical KKT normalization alone did NOT prove target-objective accuracy.
settings.adaptive=false;settings.maxIterations=200;
settings.continuationMinIterations=0;[oldX,oldContinuation]=continued(p,alpha,settings);
oldBound=v8_tikhonov_certificate(p,alpha,oldX);
assert(oldBound.dualObjective<=referenceObjective+1e-7*max(1,referenceObjective));
oldReferenceError=norm(oldX-reference,inf);
oldObjectiveGap=oldContinuation.objective-referenceObjective;
assert(oldObjectiveGap>1e-3&&~oldBound.converged,'Adversarial wrong-target objective must not pass the independent gap');
settings.continuationMinIterations=1;[hardX,hardContinuation]=continued(p,alpha,settings);
hardBound=v8_tikhonov_certificate(p,alpha,hardX);
assert(hardBound.dualObjective<=referenceObjective+1e-7*max(1,referenceObjective));
hardReferenceError=norm(hardX-reference,inf);checkObjective(p,alpha,hardX,hardContinuation);
hardReferencePassed=hardContinuation.converged&&hardBound.converged&&hardReferenceError<5e-4;
fprintf('HARD8 continuation: OLD KKT%.4g referr%.4g objgap%.4g dualgap%.4g; corrected KKT%.4g referr%.4g dualgap%.4g independently qualified%d\n', ...
 oldContinuation.kkt,oldReferenceError,oldObjectiveGap,oldBound.relativeGap, ...
 hardContinuation.kkt,hardReferenceError,hardBound.relativeGap,hardReferencePassed);
save(fullfile(folder,'smooth_continuation_adversarial_diagnostics.mat'),'oldContinuation','oldBound', ...
 'oldReferenceError','oldObjectiveGap','oldX','hardContinuation','hardBound','hardReferenceError', ...
 'hardReferencePassed','hardX','reference','referenceObjective','alpha','settings','-v7');
% A hard-case failure is recorded; it is not converted into an implementation
% pass, nor allowed to stop the other independently testable solver families.
hardQualification=struct('passed',hardReferencePassed,'referenceError',hardReferenceError, ...
 'normalizedLegacyKKT',hardContinuation.kkt,'independentGap',hardBound.relativeGap, ...
 'previousObjectiveGap',oldObjectiveGap,'previousWrongTargetRejected',~oldBound.converged);

% Prove the continuation mechanics against an independent MODERATE problem.
moderateB=A;moderateData=A*[1;0;.3;0;.8;0]+.02*sin((1:size(A,1))');
moderate=make(moderateB,moderateData,L,c);
[moderateReference,moderateObjective]=enumerate([moderate.B;sqrt(alpha)*L], ...
 [moderate.b;zeros(size(L,1),1)]);
[x,continuation]=continued(moderate,alpha,settings);
certificate=v8_tikhonov_certificate(moderate,alpha,x);moderateReferenceError=norm(x-moderateReference,inf);
assert(certificate.dualObjective<=moderateObjective+1e-9*max(1,moderateObjective));
save(fullfile(folder,'smooth_continuation_moderate_diagnostics.mat'),'continuation','certificate', ...
 'moderateReference','moderateObjective','moderateReferenceError','x','alpha','settings','-v7');
assert(continuation.converged&&certificate.converged&&moderateReferenceError<5e-4, ...
 'Moderate continuation failed: KKT%.4g, independent gap%.4g, reference error%.4g.', ...
 continuation.kkt,certificate.relativeGap,moderateReferenceError);
checkObjective(moderate,alpha,x,continuation);
assert(continuation.finalObjectiveAlpha==alpha&&continuation.iterations<=200);
results=[results;summary('moderate same-target continuation + independent dual gap',continuation)]; %#ok<AGROW>
settings.maxIterations=0;[~,failure]=v8_smooth_candidate(p,alpha,p.zero,settings);
assert(~failure.converged,'Zero-budget failure was falsely certified');
report=struct('passed',true,'cases',results,'adversarialContinuation',hardQualification, ...
 'scope','Implementation references passed; adversarial qualification is a separate explicit diagnostic, not a blanket success');
save(fullfile(folder,'smooth_fixture_results.mat'),'report','failure','adaptive','continuation','certificate','-v7');
fprintf('PASS SMOOTH8 implementation references; hard continuation independently qualified=%d, wrong-target objective explicitly rejected.\n',hardReferencePassed);
end

function p=make(B,b,L,c)
p=struct('B',sparse(B),'b',b,'R',sparse(L'*L),'tikhFactor',sparse(L), ...
 'rhs',B'*b,'diagQ',sum(B.^2,1)','n',size(B,2),'m',size(B,1), ...
 'lip',norm(B,2)^2,'zero',zeros(size(B,2),1),'target',1,'sigma',ones(size(b)),'c',c,'auxC',[]);
end

function checkObjective(p,alpha,x,info)
r=p.B*x-p.b;f=.5*(r'*r)+.5*alpha*(x'*(p.R*x));gradient=p.B'*r+alpha*(p.R*x);
assert(abs(info.objective-f)<=1e-11*max(1,abs(f)),'Original Tikhonov objective changed');
assert(norm(info.originalGradient-gradient,inf)<=1e-12*max(1,norm(gradient,inf)),'Original gradient changed');
scale=1./sqrt(max(full(sum(p.B.^2,1))'+alpha*full(diag(p.R)),realmin));
free=x>1e-13*max(1,norm(x,inf))|gradient<0;projected=gradient;projected(~free)=0;
legacy=norm(scale.*projected,inf)/max(1,norm(scale.*(p.B'*p.b),inf));
assert(abs(info.kkt-legacy)<1e-12,'Strict original certificate changed');
assert(info.changedMeasurementWeights==false);
end

function [best,objective]=enumerate(C,b)
n=size(C,2);best=zeros(n,1);objective=.5*norm(b)^2;
for mask=1:2^n-1
 active=find(bitget(mask,1:n));[Q,T]=qr(full(C(:,active)),0);
 if any(diag(T)==0),continue;end
 v=T\(Q'*b);if any(v<-1e-10*max(1,norm(v,inf))),continue;end
 candidate=zeros(n,1);candidate(active)=max(v,0);f=.5*norm(C*candidate-b)^2;
 if f<objective,objective=f;best=candidate;end
end
end

function row=summary(label,info)
row=struct('caseLabel',label,'converged',info.converged,'kkt',info.kkt, ...
 'objective',info.objective,'iterations',info.iterations,'innerLSQRIterations',info.innerLSQRIterations);
end
