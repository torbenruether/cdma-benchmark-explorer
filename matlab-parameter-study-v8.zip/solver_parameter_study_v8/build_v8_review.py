"""Audit bounded controls, create a short report and a separate website panel."""
import csv,json,math,html,zipfile,shutil
from pathlib import Path
import numpy as np
import scipy.io as sio
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
OUT=ROOT/"outputs"
def flag(v):return str(v).lower() in ("1","true")
def num(r,k):return float(r[k])
def fmt(v):return "—" if not math.isfinite(v) else f"{v:.3g}"
files=sorted(OUT.glob("ds*_*.csv"))
rows=[]
for file in files:
 with file.open(encoding="utf-8-sig",newline="") as f:
  r=list(csv.DictReader(f))
 assert len(r)==1
 rows.extend(r)
keys=[(r["Dataset"],r["Family"],r["Setting"]) for r in rows]
assert len(set(keys))==len(keys)
for r in rows:
 assert r["Dataset"] in ("ds00002","ds00005")
 assert num(r,"ConstraintViolation")<=1e-9
 expected=flag(r["ExecutionSuccess"]) and flag(r["ObjectiveConverged"]) and flag(r["DataCompatible"]) and flag(r["ParameterSelectionValid"])
 assert flag(r["Validated"])==expected
 assert flag(r["TargetPass"])==(expected and flag(r["QualityTargetsPass"]))
 assert abs(num(r,"ColdTotalSeconds")-num(r,"SolveSeconds")-num(r,"SetupSeconds"))<1e-5
 assert flag(r["FitExcluded"])
 assert num(r,"WarmStartSeconds")<=num(r,"SolveSeconds")+1e-6
# The exact MAT path label is MATLAB's regex; verify every result independently.
import re
for r in rows:
 file=OUT/(r["Dataset"]+"_"+re.sub("[^A-Za-z0-9]","_",r["Family"]+"_"+r["Setting"])+".mat")
 d=sio.loadmat(str(file),simplify_cells=True)
 x=np.asarray(d["x"]);assert np.all(np.isfinite(x)) and np.min(x)>=-1e-12
 assert bool(d["info"]["converged"])==flag(r["ObjectiveConverged"])
 if r['Family']=='Tikhonov':
  z=d['info']['independentDualCertificate']
  assert z['dualFeasible'] and z['dualGradientMinimum']>=0
  assert bool(d['info']['converged'])==(bool(d['info']['originalKKTConverged']) and bool(z['converged']))
 assert np.isclose(np.sum(d["X"]),num(r,"TotalN_cm3"))
 assert np.isclose(float(d["row"]["RelativeL2"]),num(r,"RelativeL2"))
 archived=OUT/'metadata_before_strict_dual'/file.name
 if archived.exists():
  old=sio.loadmat(str(archived),simplify_cells=True)
  assert np.array_equal(old['x'],d['x']) and np.array_equal(old['X'],d['X'])
  for k in ('RelativeL2','TotalN_cm3','GMD_dm_nm','GMD_dst_nm','GSD_dm','GSD_dst','Parameter'):
   assert old['row'][k]==d['row'][k]
p=json.loads((OUT/"progress.json").read_text())
if p["state"]=="complete":assert len(rows)==38
# Check identical final alpha within each objective/dataset.
for dataset in ("ds00002","ds00005"):
 for family in ("Tikhonov","TV-ADMM","POCS","TV-PD"):
  rr=[r for r in rows if r["Dataset"]==dataset and r["Family"]==family]
  if rr:assert len({r["Parameter"] for r in rr})==1
# Group ordering keeps baseline alongside variants; never rank by true error.
familyorder={"Tikhonov":0,"TV-ADMM":1,"POCS":2,"TV-PD":3}
rows.sort(key=lambda r:(r["Dataset"],familyorder.get(r["Family"],9),r["Setting"]))
with (OUT/"parameter_results.csv").open("w",encoding="utf-8-sig",newline="") as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else []);w.writeheader();w.writerows(rows)
lines=["CDMA PARAMETERSTUDIE v8 -- "+p["state"],f"{len(rows)}/38 Kontrollen; Hauptbenchmark v6 bleibt pausiert bei83/297.",
 "Gleiche gespeicherte Messdaten, finales alpha, Rauschgewichte und Nebenbedingungen.",
 "Truth nur für nachträgliche Fehlermetriken; keine Auswahl anhand der Sollverteilung.",
 "Laufzeit umfasst Pilotarbeit; ColdTotalSeconds zusätzlich gemeinsame Vorbereitung.",
 "Ein Zeitversuch pro Einstellung: Zeitunterschiede sind explorativ, kein statistischer Speedup.",
 "Unbestätigte Eltern-Parameterauswahl bleibt unbestätigt. Fit ausgeschlossen.",
 "",
 f"Numerisch zertifiziert: {sum(flag(r['ObjectiveConverged']) for r in rows)}/{len(rows)}.",
 f"Vollständig validiert: {sum(flag(r['Validated']) for r in rows)}/{len(rows)}.",
 f"Alle Genauigkeitsziele UND Validierung: {sum(flag(r['TargetPass']) for r in rows)}/{len(rows)}.",""]
lines.append(f"Ausführungsfehler: {sum(not flag(r['ExecutionSuccess']) for r in rows)}.")
lines.append("Tikhonov: zusätzlich unabhängige zulässige Dual-Untergrenze und relative Zielfunktionslücke; ursprüngliche KKT unverändert.")
for r in rows:
 lines.append(f"{r['Dataset']} {r['Family']} {r['Setting']}: solve{num(r,'SolveSeconds'):.2f}s +setup{num(r,'SetupSeconds'):.2f}s; "
  f"objective={int(flag(r['ObjectiveConverged']))} data={int(flag(r['DataCompatible']))} alpha={int(flag(r['ParameterSelectionValid']))}; "
  f"KKT={fmt(num(r,'KKT'))}, L2={100*num(r,'RelativeL2'):.2f}%, targets={int(flag(r['TargetPass']))}.")
timing=[];timing_summary=[]
timing_file=OUT/'timing_repeats'/'study_results.csv'
if timing_file.exists():
 with timing_file.open(encoding='utf-8-sig',newline='') as f:timing=list(csv.DictReader(f))
 assert len(timing)==9
 assert all(flag(r['Validated']) and not flag(r['TargetPass']) for r in timing)
 for base in ('beta_5e-2_fixed','beta_1e-3_fixed','beta_1e-3_adaptive'):
  rr=[r for r in timing if r['Setting'].startswith(base+'_repeat')]
  assert len(rr)==3
  times=[num(r,'SolveSeconds') for r in rr]
  timing_summary.append(dict(setting=base,median=float(np.median(times)),minimum=min(times),maximum=max(times),certified=sum(flag(r['Validated']) for r in rr)))
 lines+=['','ZUSÄTZLICHE ZEITWIEDERHOLUNGEN: 9 Läufe, je3 pro Einstellung, rotierte Reihenfolge.']
 for r in timing_summary:lines.append(f"{r['setting']}: Median{r['median']:.3f}s, Bereich{r['minimum']:.3f}..{r['maximum']:.3f}s, validiert{r['certified']}/3.")
recommendations=["POCS: mixed-noise control favors warmup100/PCG100 (28.56s) over PCG350 (37.45s), same69.57% L2. No pure-relative setting certified at40s.",
 "TV-ADMM: relaxation1.8 improves mixed KKT from1.06e-4 to5.89e-5 at20s; no tested ADMM setting is certified. Treat as experimental, not a quality winner.",
 "TV-PD: primal-only/full-dual continuation brings no certified advantage in the paired40s/8000-iteration controls. Same-alpha path already retains dual state.",
 "Tikhonov alpha-continuation: no advantage at equal20-step budget; keep out of recommendations. Hard reference remains uncertified even after one target correction.",
 "A12-decade reference exposed3.211% wrong-target objective error despite tiny normalizedKKT. Additional strict feasible-dual-gap audit rejects it; no tolerance is relaxed.",
 "All47 actual controls/repeats miss at least one joint scientific target. Mixed Tikhonov has18.72% 2D error but GSD errors5.86%/5.34% exceed5%."]
if timing_summary:
 tt={r['setting']:r for r in timing_summary}
 gain=1-tt['beta_1e-3_adaptive']['median']/tt['beta_5e-2_fixed']['median']
 samegain=1-tt['beta_1e-3_adaptive']['median']/tt['beta_1e-3_fixed']['median']
 recommendations.insert(0,f"Tikhonov: beta1e-3 with adaptive LSQR1e-7..1e-13, median{tt['beta_1e-3_adaptive']['median']:.3f}s. Solver-time reduction{100*gain:.1f}% vsbeta.05 baseline and{100*samegain:.1f}% vsfixedbeta1e-3, samecertified distribution. Shared setup adds1.30s. Evidence only for this mixed-noise case.")
lines+=['','EMPFEHLUNG / ERGEBNISSE']+recommendations
lines+=["","INTERPRETATION",
 "Compare time-to-certificate only when the same final objective is independently certified.",
 "Lower error of an uncertified early iterate can reflect accidental early stopping.",
 "Budget failure is not an infeasibility proof. No final tolerance or likelihood weight is relaxed.",
 "Reusing a full TV dual state is already present in the main parameter path, not a new regularizer.",
 "No prior-anisotropy or GP length-scale selection is performed in this numerical-settings study.",
 "SOURCE: https://www.mathworks.com/help/matlab/ref/lsqr.html",
 "SOURCE: https://web.stanford.edu/~boyd/papers/admm_distr_stats.html",
 "SOURCE: https://arxiv.org/abs/1608.08883",
 "START: addpath('"+str(ROOT)+"'); run_v8_parameter_study;"]
(ROOT/"PARAMETER_REPORT.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")
fig,axs=plt.subplots(1,2,figsize=(12,4.8))
colors={"Tikhonov":"#167b96","TV-ADMM":"#d8831f","POCS":"#8a4abf","TV-PD":"#29945b"}
for ax,dataset in zip(axs,("ds00005","ds00002")):
 for family,col in colors.items():
  rr=[r for r in rows if r["Dataset"]==dataset and r["Family"]==family]
  for r in rr:
   cert=flag(r["ObjectiveConverged"])
   ax.scatter(num(r,"SolveSeconds"),max(1e-15,num(r,"KKT")),c=[col] if cert else "none",edgecolors=col,marker="o",s=65)
  ax.plot([],[],color=col,marker="o",linestyle="",label=family)
 ax.axhline(2e-6,color="#333",linestyle="--",linewidth=1,label="KKT-Schwelle")
 ax.set_yscale("log");ax.set_xlabel("Solverzeit inkl. Startarbeit [s]");ax.set_ylabel("KKT-Diagnose")
 ax.set_title("3% relativ +3% absolut" if dataset=="ds00005" else "3% relativ +0% absolut");ax.grid(alpha=.2)
axs[0].legend(fontsize=8);fig.suptitle("Numerische Parameterstudie · gefüllt: vollständiges Optimum-Zertifikat")
fig.text(.5,.01,"KKT-Definitionen unterscheiden sich zwischen Familien; KKT allein genügt nicht als Zertifikat.",ha="center",fontsize=9)
fig.tight_layout(rect=(0,.04,1,.94));fig.savefig(ROOT/"parameter_performance.png",dpi=160);plt.close(fig)
h=["<article id=\"v8-review\"><h2>Solver-Einstellungen: begrenzte Parameterstudie v8</h2>",
 f"<p><strong>{len(rows)} von 38 Kontrollen gespeichert.</strong> Zwei vorhandene Rauschfälle; gleiche Zielfunktion und für alle Varianten dieselben strengen Kriterien. Hauptbenchmark weiterhin pausiert bei 83/297.</p>",
 "<p>Untersucht: Tikhonov-Vorkonditionierung und innere Genauigkeit, ADMM-Überrelaxation und Residuenbalance, POCS-Warmup/PCG sowie vollständige TV-Warmstarts. Startarbeit ist in der Solverzeit enthalten. Gemeinsame Vorbereitung wird zusätzlich ausgewiesen. Im Startvergleich je Einstellung ein Zeitversuch; zusätzliche Tikhonov-Wiederholungen stehen unten.</p>",
 f"<p>Optimum zertifiziert: {sum(flag(r['ObjectiveConverged']) for r in rows)}; vollständig validiert: {sum(flag(r['Validated']) for r in rows)}; alle Genauigkeitsziele und Validierung erfüllt: {sum(flag(r['TargetPass']) for r in rows)}.</p>",
 "<p class=\"note\">Kleinerer 2D-Fehler einer nicht konvergierten Lösung gilt nicht als Solververbesserung. Die datenbasierte α-Auswahl bleibt unverändert; bisher unbestätigte Parameter werden durch diesen Optimiertest nicht bestätigt. Lognormal-fit bleibt aus dieser Bewertung ausgeschlossen.</p>",
 "<p>Tikhonov wird zusätzlich über eine unabhängige Dual-Untergrenze geprüft. Ein Referenztest hatte gezeigt, dass das normalisierte KKT-Kriterium allein nach einem α-Wechsel zu früh erfüllt sein kann. Die zusätzliche Prüfzeit wird mitgezählt.</p>",
 "<p><strong>Bewertung:</strong> Adaptive Tikhonov-Genauigkeit spart im gemischten Fall Rechenzeit bei gleicher zertifizierter Verteilung. POCS100/100 bleibt hier günstiger als100/350; sein Formfehler bleibt hoch. TV1,8 ist ein Kandidat für weitere Konvergenzprüfungen. Kein getesteter Satz erfüllt alle wissenschaftlichen Zielgrenzen.</p>",
 "<img src=\"v8_parameter_performance.png\" alt=\"Konvergenzdiagnose gegen Rechenzeit der getesteten Einstellungen\" style=\"width:100%;max-width:1100px\">",
 "<p><a href=\"V8_PARAMETER_REPORT.txt\">Bericht</a> · <a href=\"v8_parameters.csv\">Alle Parameter und Metriken (CSV)</a> · <a href=\"matlab-parameter-study-v8.zip\">MATLAB-Studie und Herkunft</a></p>"]
if timing_summary:
 h+=['<h3>Zusätzliche Zeitwiederholungen: Tikhonov beim gemischten Rauschfall</h3>',
  '<p>Drei Wiederholungen je Einstellung bei rotierter Reihenfolge. Gleiche feste α und Sollverteilung nur zur anschließenden Fehlerprüfung. Median und Spannweite der Solverzeit einschließlich Zertifikatsprüfung; gemeinsame Vorbereitung separat.</p>',
  '<table><thead><tr><th>Einstellung</th><th>Median</th><th>Spannweite</th><th>Validiert</th></tr></thead><tbody>']
 for r in timing_summary:h.append(f"<tr><td>{html.escape(r['setting'])}</td><td>{r['median']:.2f}s</td><td>{r['minimum']:.2f}–{r['maximum']:.2f}s</td><td>{r['certified']}/3</td></tr>")
 h+=['</tbody></table><p><a href="v8_timing_repeats.csv">Zeitwiederholungen (CSV)</a></p>']
h+=["<details><summary>Alle getesteten Einstellungen und Diagnosen</summary><div style=\"overflow:auto\"><table><thead><tr><th>Fall</th><th>Solver</th><th>Einstellung</th><th>Solver s</th><th>Setup s</th><th>Optimum</th><th>Daten</th><th>α gültig</th><th>2D-Fehler</th><th>Alle Ziele</th></tr></thead><tbody>"]
for r in rows:
 cells=[r["Dataset"],r["Family"],r["Setting"],fmt(num(r,"SolveSeconds")),fmt(num(r,"SetupSeconds"))]+[
  "ja" if flag(r[k]) else "nein" for k in ("ObjectiveConverged","DataCompatible","ParameterSelectionValid")]+[
  f"{100*num(r,'RelativeL2'):.2f}%","ja" if flag(r["TargetPass"]) else "nein"]
 h.append("<tr>"+"".join("<td>"+html.escape(x)+"</td>" for x in cells)+"</tr>")
h+=["</tbody></table></div></details></article>"]
(ROOT/"V8_WEB.html").write_text("\n".join(h),encoding="utf-8")
print(json.dumps({"controls":len(rows),"state":p["state"],"validated":sum(flag(r["Validated"]) for r in rows),"targets":sum(flag(r["TargetPass"]) for r in rows)}))
