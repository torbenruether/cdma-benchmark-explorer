function cert=v8_tikhonov_strict_certificate(p,alpha,x)
% Strict computed dual feasibility: remaining negative C'*q never qualifies.
if isfield(p,'tikhFactor'),L=p.tikhFactor;
elseif isfield(p,'v8SmoothPrepared'),L=p.v8SmoothPrepared.L;
else,L=p.g.L/sqrt(max(norm(p.g.L'*p.g.L,inf),eps));end
C=[p.B;sqrt(alpha)*L];bb=[p.b;zeros(size(L,1),1)];q=C*x-bb;
primal=.5*(q'*q);direction=p.B'*ones(p.m,1);positive=direction>0;
shift=0;fallback=false;corrections=0;
for attempt=1:8
 g=C'*q;
 if all(g>=0),break;end
 if any(g(~positive)<0),fallback=true;break;end
 bad=g<0;needed=max(-g(bad)./direction(bad));
 extra=max(needed*(1+1e-8),64*eps*max(1,norm(q,inf)));
 if ~isfinite(extra),fallback=true;break;end
 q(1:p.m)=q(1:p.m)+extra;shift=shift+extra;corrections=corrections+1;
end
g=C'*q;
if fallback||any(g<0)||any(~isfinite(g)),q=zeros(size(q));g=C'*q;fallback=true;end
dual=-.5*(q'*q)-bb'*q;gap=primal-dual;
roundoff=256*eps*max([1,abs(primal),abs(dual)]);
relativeGap=max(gap,0)/max([1,abs(primal),abs(dual)]);
cert=struct('primalObjective',primal,'dualObjective',dual,'relativeGap',relativeGap, ...
 'dualFeasible',all(g>=0),'gapConsistent',gap>=-roundoff,'dualCorrection',shift, ...
 'certificateFallback',fallback,'corrections',corrections,'dualGradientMinimum',min(g), ...
 'converged',all(g>=0)&&gap>=-roundoff&&relativeGap<=p.c.tolerance);
end
