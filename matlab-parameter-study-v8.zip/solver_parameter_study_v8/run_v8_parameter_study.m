function rows=run_v8_parameter_study
% Bounded study; never resumes or launches a full benchmark.
root=fileparts(mfilename('fullpath'));parent=fileparts(root);
addpath(fullfile(parent,'solver_revision_v7'));addpath(fullfile(parent,'solver_revision_v7','core'));addpath(root);
folder=fullfile(root,'outputs');if ~exist(folder,'dir'),mkdir(folder);end
assert(~exist(fullfile(folder,'study_results.csv'),'file'),'Results already exist; use a new study directory for a rerun.');
datasets={'ds00005','ds00002'};timer=tic;rows=struct([]);
progress=struct('state','running','plannedControls',38,'completedControls',0,'parentBenchmark','paused at83/297', ...
 'startedAt',datestr(now,31),'updatedAt',datestr(now,31));
writeProgress;
for family={'smooth','admm','pocs','tv'}
 fprintf('\nV8 FAMILY %s START %s\n',family{1},datestr(now,31));
 switch family{1}
  case 'smooth'
   v8_smooth_study([],folder,struct('TestsOnly',true));cache=struct([]);
   for di=1:numel(datasets)
    tm=tic;[p,d]=v7_prepare_control(datasets{di});prep=toc(tm);
    idx=find(strcmp(string({d.rows.Method}),'Tikhonov'),1);
    cache=[cache;struct('dataset',datasets{di},'p',p,'d',d,'alpha',d.rows(idx).Parameter, ...
      'selectionValid',d.rows(idx).ParameterSelectionValid,'SetupSeconds',prep)]; %#ok<AGROW>
   end
   newrows=v8_smooth_study(cache,folder,struct);
  case 'admm'
   v8_admm_study(struct('fixtureOnly',true,'Folder',folder));
   newrows=v8_admm_study(datasets,folder);
  case 'pocs',newrows=v8_pocs_study(datasets,folder);
  case 'tv',newrows=v8_tv_study(datasets,folder);
 end
 rows=[rows;newrows]; %#ok<AGROW>
 writetable(struct2table(rows),fullfile(folder,'study_results.csv'));
 progress.completedControls=numel(rows);progress.updatedAt=datestr(now,31);writeProgress;
end
assert(numel(rows)==progress.plannedControls,'Expected all 38 predeclared controls.');
progress.state='complete';progress.elapsedSeconds=toc(timer);writeProgress;
save(fullfile(folder,'study_results.mat'),'rows','progress','-v7');
fprintf('V8 COMPLETE: %d bounded controls in %.1fs. V6 remains paused.\n',numel(rows),toc(timer));
 function writeProgress
  f=fopen(fullfile(folder,'progress.json'),'w');assert(f>0);fprintf(f,'%s',jsonencode(progress));fclose(f);
 end
end
