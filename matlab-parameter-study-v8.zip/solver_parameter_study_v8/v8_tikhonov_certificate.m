function cert=v8_tikhonov_certificate(p,alpha,x)
% Independent feasible Fenchel dual bound for min_x>=0 .5||[B;sqrt(a)L]x-[b;0]||^2.
% It supplements, never replaces/relaxes, the existing original-x KKT tests.
if isfield(p,'tikhFactor'),L=p.tikhFactor;
elseif isfield(p,'v8SmoothPrepared'),L=p.v8SmoothPrepared.L;
else,L=p.g.L/sqrt(max(norm(p.g.L'*p.g.L,inf),eps));end
C=[p.B;sqrt(alpha)*L];bb=[p.b;zeros(size(L,1),1)];
q=C*x-bb;primal=.5*(q'*q);g=C'*q;direction=p.B'*ones(p.m,1);
roundoff=64*eps*max(1,norm(g,inf));positive=direction>0;
fallback=any(g(~positive)<-roundoff);shift=0;
if fallback,q=zeros(size(q));
else
 bad=g<0;
 if any(bad&positive),shift=(1+32*eps)*max(-g(bad&positive)./direction(bad&positive));end
 q(1:p.m)=q(1:p.m)+shift;
end
dualGradient=C'*q;dualFeasible=all(dualGradient>=-64*eps*max(1,norm(dualGradient,inf)));
dual=-.5*(q'*q)-bb'*q;gap=primal-dual;
gapRoundoff=256*eps*max([1,abs(primal),abs(dual)]);
consistent=gap>=-gapRoundoff;relativeGap=max(gap,0)/max([1,abs(primal),abs(dual)]);
cert=struct('primalObjective',primal,'dualObjective',dual,'relativeGap',relativeGap, ...
 'dualFeasible',dualFeasible,'gapConsistent',consistent,'dualCorrection',shift, ...
 'certificateFallback',fallback,'dualGradientMinimum',min(dualGradient), ...
 'converged',dualFeasible&&consistent&&relativeGap<=p.c.tolerance);
end
