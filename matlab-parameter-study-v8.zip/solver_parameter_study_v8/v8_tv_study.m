function rows=v8_tv_study(datasets,folder)
% Same target alpha. Pilot at 3*alpha is data-only; ALL pilot cost is charged.
rows=struct([]);v8_tv_fixture;
for di=1:numel(datasets)
 dataset=datasets{di};tm=tic;[p,d]=v7_prepare_control(dataset);preparation=toc(tm);
 idx=find(strcmp(string({d.rows.Method}),'TV-2D'),1);alpha=d.rows(idx).Parameter;
 selected=d.rows(idx).ParameterSelectionValid;
 tm=tic;t=v7_graph_setup(p);setup=preparation+toc(tm);
 opts=struct('Mode','cold','TotalCapSeconds',40,'TargetIterations',8000,'SetupSeconds',setup,'WarmStartSeconds',0);
 p.c.v7GraphMaxSeconds=40;tm=tic;
 [x,info]=v7_graph_candidate(p,t,alpha,[],8000,'quadratic');
 rows=[rows;v8_record_result(dataset,'TV-PD','cold',x,info,p,d,alpha,selected,toc(tm),opts,folder)]; %#ok<AGROW>
 % Generate one identical stronger-alpha pilot for the two restart modes.
 pp=p;pp.c.v7GraphMaxSeconds=10;tm=tic;
 [pilot,seedInfo,seed]=v7_graph_candidate(pp,t,3*alpha,[],2000,'quadratic');pilotSeconds=toc(tm);
 save(fullfile(folder,[dataset '_TV_PD_pilot.mat']),'pilot','seedInfo','seed','pilotSeconds','alpha','-v7');
 for mode={'primal_only','primal_dual'}
  pp=p;pp.c.v7GraphMaxSeconds=max(.01,40-pilotSeconds);
  if strcmp(mode{1},'primal_only'),pp.revisionWarmStart=pilot;state=[];else,state=seed;end
  opts=struct('Mode',mode{1},'TotalCapSeconds',40,'PilotAlphaMultiplier',3,'PilotIterations',2000, ...
   'TargetIterations',6000,'SetupSeconds',setup,'WarmStartSeconds',pilotSeconds);
  tm=tic;[x,info]=v7_graph_candidate(pp,t,alpha,state,6000,'quadratic');
  seconds=pilotSeconds+toc(tm);info.targetIterations=info.iterations;
  info.iterations=info.iterations+seedInfo.iterations;info.pilotConverged=seedInfo.converged;
  rows=[rows;v8_record_result(dataset,'TV-PD',mode{1},x,info,p,d,alpha,selected,seconds,opts,folder)]; %#ok<AGROW>
 end
end
end
function v8_tv_fixture
% Warm state is projected to a new alpha ball, then independently re-certified.
c=extended_config;c.nBins=3;c.rangeNm=[20 1000];c.tvIterations=12000;c.v7GraphMaxSeconds=Inf;
g=cdma_grid(c);n=numel(g.active);A=sparse(1:n,g.active,1,n,g.n^2);
p=cdma_prepare(A,[1;4;2;6;3;5],ones(n,1),g,c,table);
p.auxC=sparse(0,n);p.auxLo=[];p.auxHi=[];t=v7_graph_setup(p);alpha=.07;
[reference,base]=v7_graph_candidate(p,t,alpha,[],12000,'quadratic');
assert(base.converged);
[pilot,~,state]=v7_graph_candidate(p,t,3*alpha,[],2000,'quadratic');
for mode=1:2
 pp=p;if mode==1,pp.revisionWarmStart=pilot;start=[];else,start=state;end
 [x,info,final]=v7_graph_candidate(pp,t,alpha,start,12000,'quadratic');
 certificate=v7_graph_certificate(pp,t,x,final.y,alpha,'quadratic');
 assert(info.converged&&certificate.converged&&norm(x-reference)/max(1,norm(reference))<5e-5);
end
fprintf('PASS V8 TV warm starts: same target optimum and independently rechecked certificates\n');
end
