function rows=v8_admm_study(options,folder)
% Five OFAT settings x two saved datasets. No alpha/regularizer/truth changes.
% options.fixtureOnly=true: independent small-reference tests only.
if nargin<1,options=struct;end
if iscell(options)
 datasets=options;options=struct('Datasets',{datasets});
 if nargin>=2,options.Folder=folder;end
elseif nargin>=2,options.Folder=folder;
end
root=fileparts(mfilename('fullpath'));parent=fileparts(root);
if ~isfield(options,'V6Source'),options.V6Source=fullfile(parent,'solver_revision_v6');end
if ~isfield(options,'V7Source'),options.V7Source=fullfile(parent,'solver_revision_v7');end
if ~isfield(options,'Folder'),options.Folder=fullfile(root,'outputs','admm');end
if ~isfield(options,'MaxSeconds'),options.MaxSeconds=20;end
if ~isfield(options,'Iterations'),options.Iterations=4000;end
if ~isfield(options,'Datasets'),options.Datasets={'ds00005','ds00002'};end
% The graph helpers are unchanged copies in v7. Do not shadow v7_config's
% extended_config/core by putting the archived v6 source on MATLAB's path.
addpath(options.V7Source);addpath(fullfile(options.V7Source,'core'));addpath(root);
settings=[1.6 10;1.2 10;1.8 10;1.6 5;1.6 20];
if isfield(options,'fixtureOnly')&&options.fixtureOnly,rows=fixture();return;end
assert(exist('v8_record_result','file')==2,'Parent v8_record_result.m is required');
if ~exist(options.Folder,'dir'),mkdir(options.Folder);end
rows=struct([]);
for di=1:numel(options.Datasets)
 dataset=options.Datasets{di};setupTimer=tic;
 [p,d]=v7_prepare_control(dataset);
 idx=find(strcmp(string({d.rows.Method}),'TV-2D'),1);
 assert(~isempty(idx)&&isfinite(d.rows(idx).Parameter)&&d.rows(idx).Parameter>0, ...
  'Stored measurement-selected TV alpha is required for %s',dataset);
 alpha=d.rows(idx).Parameter;selectionValid=d.rows(idx).ParameterSelectionValid;
 t=v6_graph_setup(p,1);setupSeconds=toc(setupTimer);
 for j=1:size(settings,1)
  cfg=options;cfg.Relaxation=settings(j,1);cfg.BalanceThreshold=settings(j,2);cfg.SetupSeconds=setupSeconds;
  label=sprintf('relax_%g_balance_%g',cfg.Relaxation,cfg.BalanceThreshold);
  fprintf('V8 ADMM %s %s alpha %.8g START\n',dataset,label,alpha);
  timer=tic;[x,info,state]=v8_admm_candidate(p,t,alpha,[],options.Iterations,cfg);seconds=toc(timer);
  info.parentMethod='TV-2D';info.parentParameterSelectionValid=selectionValid;
  info.fixedDataSelectedParentAlpha=true;info.setupSeconds=setupSeconds;
  row=v8_record_result(dataset,'TV-ADMM',label,x,info,p,d,alpha,selectionValid,seconds,cfg,options.Folder);
  rows=[rows;row]; %#ok<AGROW>
  % Keep the entire state as a separate optional continuation artifact.
  save(fullfile(options.Folder,[dataset '_' label '_state.mat']),'state','alpha','cfg','-v7');
 end
end
if ~isempty(rows),writetable(struct2table(rows),fullfile(options.Folder,'admm_study.csv'));end
 function result=fixture()
  c=extended_config;c.nBins=3;c.rangeNm=[20 1000];c.tvIterations=12000;
  g=cdma_grid(c);n=numel(g.active);A=sparse(1:n,g.active,1,n,g.n^2);
  p=cdma_prepare(A,[1;4;2;6;3;5],ones(n,1),g,c,table);
  p.auxC=sparse(0,n);p.auxLo=[];p.auxHi=[];t=v6_graph_setup(p,1);alpha=.07;
  [old,oldInfo]=v6_graph_candidate(p,t,alpha,[],12000);
  [current,currentInfo]=v8_admm_candidate(p,t,alpha,[],12000);
  assert(norm(current-old,inf)<1e-12&&currentInfo.iterations==oldInfo.iterations, ...
   'v8 default settings must reproduce the frozen v6 iteration path');
  assert(abs(currentInfo.objective-oldInfo.objective)<1e-12&&currentInfo.converged==oldInfo.converged);
  % Independent SQP epigraph solution; not reused to choose settings/alpha.
  z0=[current;hypot(p.Ga*current,p.Gm*current)+1e-8];
  o=optimoptions('fmincon','Algorithm','sqp','Display','off','OptimalityTolerance',1e-10, ...
   'ConstraintTolerance',1e-10,'MaxIterations',1000);
  [~,fref,flag]=fmincon(@objective,z0,[],[],[],[],zeros(2*n,1),[],@constraints,o);
  assert(flag>0);result=struct([]);
  for jj=1:size(settings,1)
   cfg=struct('Relaxation',settings(jj,1),'BalanceThreshold',settings(jj,2),'MaxSeconds',Inf);
   [x,info]=v8_admm_candidate(p,t,alpha,[],12000,cfg);
   difference=abs(info.objective-fref)/max(1,abs(fref));
   assert(info.converged&&all(x>=0)&&difference<5e-5,'ADMM setting fixture failed');
   q=struct('Relaxation',cfg.Relaxation,'BalanceThreshold',cfg.BalanceThreshold, ...
    'ObjectiveConverged',info.converged,'Iterations',info.iterations,'KKT',info.kkt, ...
    'Complementarity',info.complementarityGap,'ObjectiveDifference',difference);result=[result;q]; %#ok<AGROW>
  end
  [~,short]=v8_admm_candidate(p,t,alpha,[],1);assert(~short.converged);
  [~,budget]=v8_admm_candidate(p,t,alpha,[],12000,struct('MaxSeconds',0));
  assert(budget.budgetStopped&&budget.iterations==0&&~budget.converged);
  if ~exist(options.Folder,'dir'),mkdir(options.Folder);end
  save(fullfile(options.Folder,'admm_fixture.mat'),'result','oldInfo','currentInfo','fref','-v7');
  fprintf('PASS v8 ADMM default-v6 identity, five strict SQP reference settings, short/budget failure guards\n');
  function f=objective(z)
   r=p.B*z(1:n)-p.b;f=.5*(r'*r)+alpha*sum(z(n+1:end));
  end
  function [ineq,eq]=constraints(z)
   ineq=hypot(p.Ga*z(1:n),p.Gm*z(1:n))-z(n+1:end);eq=[];
  end
 end
end
