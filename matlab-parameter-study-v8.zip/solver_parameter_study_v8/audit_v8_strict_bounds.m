function audit_v8_strict_bounds(folder)
% Metadata-only stricter audit of the SAME returned x, alpha and metrics.
root=fileparts(mfilename('fullpath'));parent=fileparts(root);
addpath(fullfile(parent,'solver_revision_v7'));addpath(fullfile(parent,'solver_revision_v7','core'));addpath(root);
if nargin<1,folder=fullfile(root,'outputs');end
assert(exist(fullfile(folder,'study_results.csv'),'file')==2);
progress=jsondecode(fileread(fullfile(folder,'progress.json')));assert(strcmp(progress.state,'complete'));
backup=fullfile(folder,'metadata_before_strict_dual');assert(~exist(backup,'dir'),'Audit already applied');mkdir(backup);
copyfile(fullfile(folder,'study_results.csv'),backup);copyfile(fullfile(folder,'study_results.mat'),backup);
% Analytic reference checks and a data-free zero dual fallback.
c=v7_config;p=struct('B',speye(3),'b',[1;2;3],'n',3,'m',3,'tikhFactor',speye(3),'c',c);
alpha=.2;x=p.b/(1+alpha);z=v8_tikhonov_strict_certificate(p,alpha,x);
ref=.5*alpha/(1+alpha)*(p.b'*p.b);
assert(z.dualFeasible&&z.dualGradientMinimum>=0&&z.dualObjective<=ref+1e-10&&z.converged);
p.B=sparse(2,3);p.b=[1;2];p.m=2;p.tikhFactor=sparse([1 -1 0;0 1 -1]);
z=v8_tikhonov_strict_certificate(p,alpha,[1;0;0]);
assert(z.certificateFallback&&z.dualFeasible&&z.dualGradientMinimum==0&&z.dualObjective==0);
assert(z.dualObjective<=.5*(p.b'*p.b)+1e-10);
for dataset={'ds00005','ds00002'}
 [p,~]=v7_prepare_control(dataset{1});
 files=dir(fullfile(folder,[dataset{1} '_Tikhonov_*.mat']));
 for fi=1:numel(files)
  file=fullfile(files(fi).folder,files(fi).name);data=load(file);
  x=data.x;X=data.X;row=data.row;info=data.info;options=data.options;
  copyfile(file,backup);csv=strrep(file,'.mat','.csv');copyfile(csv,backup);
  tm=tic;cert=v8_tikhonov_strict_certificate(p,row.Parameter,x);extra=toc(tm);
  info.roundoffDualCertificate=info.independentDualCertificate;info.independentDualCertificate=cert;
  info.relativeGap=cert.relativeGap;info.converged=info.originalKKTConverged&&cert.converged;
  row.RelativeGap=cert.relativeGap;row.ObjectiveConverged=info.converged;
  row.Validated=row.ExecutionSuccess&&row.ObjectiveConverged&&row.DataCompatible&&row.ParameterSelectionValid&&row.ConstraintViolation<=1e-9;
  row.TargetPass=row.Validated&&row.QualityTargetsPass;
  row.AuditSeconds=row.AuditSeconds+extra;row.SolveSeconds=row.SolveSeconds+extra;row.ColdTotalSeconds=row.ColdTotalSeconds+extra;
  save(file,'x','X','row','info','options','-v7');writetable(struct2table(row),csv);
  fprintf('STRICT8 %s: objective%d gap%.4g minDualGradient%.4g fallback%d\n',files(fi).name,info.converged,cert.relativeGap,cert.dualGradientMinimum,cert.certificateFallback);
 end
end
files=dir(fullfile(folder,'ds*_*.csv'));rows=struct([]);
for fi=1:numel(files)
 data=load(strrep(fullfile(files(fi).folder,files(fi).name),'.csv','.mat'));
 rows=[rows;data.row]; %#ok<AGROW>
end
assert(numel(rows)==progress.plannedControls);writetable(struct2table(rows),fullfile(folder,'study_results.csv'));
save(fullfile(folder,'study_results.mat'),'rows','progress','-v7');
fprintf('PASS STRICT8 analytic bound references and all Tikhonov metadata audits; x/metrics unchanged.\n');
end
