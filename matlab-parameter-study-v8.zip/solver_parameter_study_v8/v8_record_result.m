function row=v8_record_result(dataset,family,label,x,info,p,d,alpha,selectionValid,seconds,options,folder)
% Truth is used only AFTER optimization. No source or paused output is changed.
assert(all(isfinite(x))&&all(x>=-1e-12),'Invalid returned reconstruction');
auditSeconds=0;
if strcmp(family,'Tikhonov')
 auditTimer=tic;
 info.originalKKTConverged=info.converged;
 info.independentDualCertificate=v8_tikhonov_certificate(p,alpha,x);
 info.relativeGap=info.independentDualCertificate.relativeGap;
 info.converged=info.converged&&info.independentDualCertificate.converged;
 auditSeconds=toc(auditTimer);seconds=seconds+auditSeconds;
end
X=zeros(p.g.n);X(p.g.active)=x*p.scale;
row=large_metrics(X,d.truth,p.g,d.components,p.c.totalN);
row.Dataset=string(dataset);row.Family=string(family);row.Setting=string(label);
row.SolveSeconds=seconds;row.SetupSeconds=get(options,'SetupSeconds',0);
row.AuditSeconds=auditSeconds;
row.ColdTotalSeconds=seconds+row.SetupSeconds;
row.WarmStartSeconds=get(options,'WarmStartSeconds',0);
row.Iterations=get(info,'iterations',NaN);row.InnerIterations=get(info,'innerLSQRIterations',NaN);
row.Objective=get(info,'objective',NaN);row.ObjectiveConverged=logical(info.converged);
row.ExecutionSuccess=~isfield(info,'error')||isempty(info.error);
row.KKT=get(info,'kkt',NaN);
for name={'unscaledKkt','naturalProjectedKKT','naturalOriginalProjectedKKT'}
 if isfield(info,name{1}),row.KKT=max(row.KKT,info.(name{1}));end
end
row.RelativeGap=get(info,'relativeGap',get(info,'complementarityGap',NaN));
row.WeightedResidual=norm(p.B*x-p.b)^2;
row.DataCompatible=row.WeightedResidual<=(1-2/(9*p.m)+1.64485362695147*sqrt(2/(9*p.m)))^3*(1+1e-5);
if strcmp(family,'POCS'),row.DataCompatible=logical(info.BandsSatisfied);end
row.ConstraintViolation=max([0;-x;p.auxLo-p.auxC*x;p.auxC*x-p.auxHi]);
row.Parameter=alpha;row.ParameterSelectionValid=logical(selectionValid);
row.Validated=row.ExecutionSuccess&&row.ObjectiveConverged&&row.DataCompatible&&row.ParameterSelectionValid&&row.ConstraintViolation<=1e-9;
row.QualityTargetsPass=row.RelativeL2<=.2&&abs(row.TotalRelativeError)<=.05&& ...
 abs(row.GMD_dm_RelativeError)<=.05&&abs(row.GMD_dst_RelativeError)<=.05&& ...
 abs(row.GSD_dm_RelativeError)<=.05&&abs(row.GSD_dst_RelativeError)<=.05;
row.TargetPass=row.Validated&&row.QualityTargetsPass;
row.BudgetStopped=logical(get(info,'budgetStopped',false));
row.Options=string(jsonencode(options));row.FitExcluded=true;
if ~exist(folder,'dir'),mkdir(folder);end
file=fullfile(folder,[dataset '_' regexprep([family '_' label],'[^A-Za-z0-9]','_')]);
save([file '.mat'],'x','X','info','options','row','-v7');
writetable(struct2table(row),[file '.csv']);
fprintf('V8 %s %-9s %-28s %.2fs KKT%.4g objective%d data%d alpha%d L2%.4g\n', ...
 dataset,family,label,seconds,row.KKT,row.ObjectiveConverged,row.DataCompatible,row.ParameterSelectionValid,row.RelativeL2);
end
function v=get(s,name,default)
if isfield(s,name),v=s.(name);else,v=default;end
end
