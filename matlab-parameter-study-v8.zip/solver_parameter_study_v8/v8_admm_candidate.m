function [x,info,state]=v8_admm_candidate(p,t,alpha,state,cap,options)
% Isolated settings study of the FROZEN v6 two-block ADMM objective.
% Defaults reproduce v6_graph_candidate, including adaptation and audit.
if nargin<6,options=struct;end
if ~isfield(options,'Relaxation'),options.Relaxation=1.6;end
if ~isfield(options,'BalanceThreshold'),options.BalanceThreshold=10;end
if ~isfield(options,'MaxSeconds'),options.MaxSeconds=Inf;end
relaxation=options.Relaxation;balanceThreshold=options.BalanceThreshold;
assert(relaxation>0&&relaxation<2&&balanceThreshold>1&&cap>=1);
timer=tic;budgetStopped=false;
if t.order==1,tol=p.c.tolerance;else,tol=p.c.tgvTolerance;end
if isempty(state)
 u=zeros(t.nvar,1);if isfield(p,'revisionWarmStart'),u(1:t.n)=max(p.revisionWarmStart,0);end
 z=t.D*u;y=zeros(size(z));rho=max(1,alpha);
else,u=state.u;z=state.z;y=state.y;rho=state.rho;end
converged=false;rhoUpdates=0;
% Retain physical multipliers and project the regularizer dual balls.
offset=0;
for g=1:numel(t.widths)
 rows=offset+(1:t.n*t.widths(g));yy=reshape(y(rows),t.n,t.widths(g));
 radius=alpha*t.coefficients(g)*t.weights;mag=sqrt(sum(yy.^2,2));
 yy=yy./max(1,mag./max(radius,realmin));y(rows)=yy(:);offset=offset+numel(rows);
end
k=0;primal=Inf;dual=Inf;f=Inf;kkt=Inf;complementarity=Inf;clipImpact=Inf;slabViolation=Inf;
for iter=1:cap
 % A soft wallclock budget: an already running linear solve may finish.
 if mod(iter-1,25)==0&&toc(timer)>=options.MaxSeconds,budgetStopped=true;break;end
 k=iter;oldz=z;consensus=t.D'*(z-y/rho);v=t.L\consensus(t.perm);pv=t.V'*v;
 yy=v-t.V*pv+t.V*((t.s.*t.ub+rho*pv)./(t.s.^2+rho));
 u=zeros(t.nvar,1);u(t.perm)=t.L'\yy;du=t.D*u;
 relaxed=relaxation*du+(1-relaxation)*oldz;v=relaxed+y/rho;z=v;offset=0;
 for g=1:numel(t.widths)
  rows=offset+(1:t.n*t.widths(g));vv=reshape(v(rows),t.n,t.widths(g));
  threshold=alpha*t.coefficients(g)*t.weights/rho;mag=sqrt(sum(vv.^2,2));
  vv=vv.*max(0,1-threshold./max(mag,realmin));z(rows)=vv(:);offset=offset+numel(rows);
 end
 z(t.pos)=max(v(t.pos),0);
 if ~isempty(t.slabs),z(t.slabs)=min(t.hi,max(t.lo,v(t.slabs)));end
 y=y+rho*(relaxed-z);
 primalAbs=norm(du-z);dualAbs=norm(rho*t.D'*(z-oldz));
 primal=primalAbs/max([1,norm(du),norm(z)]);dual=dualAbs/max(1,norm(t.D'*y));
 if mod(k,25)==0||k==cap||max(primal,dual)<=tol
  audit();
  if max(primal,dual)<=tol&&kkt<=tol&&complementarity<=tol&& ...
   clipImpact<=.01*sqrt(p.target)&&slabViolation<=tol
   converged=true;break;
  end
 end
 % Same finite-adaptation window/factor/bounds as frozen v6; only threshold
 % and overrelaxation vary. Physical multipliers require no rescaling.
 if mod(k,25)==0&&k<=min(2000,floor(cap/2))
  rp=primalAbs/max([norm(du),norm(z),1e-12]);
  rd=dualAbs/max([norm(t.D'*y),norm(t.rhs),1e-12]);oldrho=rho;
  if rp>balanceThreshold*rd,rho=rho*2;elseif rd>balanceThreshold*rp,rho=rho/2;end
  rho=min(max(rho,1e-12),1e20);rhoUpdates=rhoUpdates+(rho~=oldrho);
 end
end
% Evaluate the actual returned nonnegative consensus copy after a budget stop.
audit();x=z(t.pos);
if k==0,primal=norm(t.D*u-z)/max([1,norm(t.D*u),norm(z)]);dual=0;end
info=struct('iterations',k,'converged',converged,'objective',f, ...
 'primalResidual',primal,'dualResidual',dual,'kkt',kkt,'stationarityResidual',kkt, ...
 'complementarityGap',complementarity,'clippingMeasurementImpact',clipImpact, ...
 'slabViolation',slabViolation,'rho',rho,'rhoUpdates',rhoUpdates,'relaxation',relaxation, ...
 'balanceThreshold',balanceThreshold,'budgetStopped',budgetStopped,'seconds',toc(timer), ...
 'algorithm','Frozen v6 two-block ADMM objective; isolated relaxation/residual-balance study', ...
 'stopping','UNCHANGED original strict primal/dual residuals, objective KKT, Fenchel complementarity and clipping/slab guards');
info.stopReason='iteration_limit';if converged,info.stopReason='original_strict_certificate';
elseif budgetStopped,info.stopReason='explicit_time_budget';end
state=struct('u',u,'z',z,'y',y,'rho',rho);
 function audit()
  auditU=u;auditU(1:t.n)=z(t.pos);xx=auditU(1:t.n);r=p.B*xx-p.b;
  station=t.B'*r+t.D'*y;kkt=norm(station,inf)/t.rhsInf;
  reg=t.Dreg*auditU;regularizer=0;off=0;
  for gg=1:numel(t.widths)
   rr=off+(1:t.n*t.widths(gg));vvv=reshape(reg(rr),t.n,t.widths(gg));
   regularizer=regularizer+alpha*t.coefficients(gg)*sum(t.weights.*sqrt(sum(vvv.^2,2)));off=off+numel(rr);
  end
  f=.5*(r'*r)+regularizer;
  gap=regularizer-y(1:numel(reg))'*reg-y(t.pos)'*xx;slabViolation=0;
  if ~isempty(t.slabs)
   value=t.D(t.slabs,:)*auditU;ys=y(t.slabs);
   gap=gap+max(ys,0)'*t.hi+min(ys,0)'*t.lo-ys'*value;
   slabViolation=max([0;t.lo-value;value-t.hi]);
  end
  complementarity=max(gap,0)/max(1,abs(f));clipImpact=norm(p.B*(xx-u(1:t.n)));
 end
end
