function records=v8_pocs_study(datasets,folder)
% Small OFAT optimizer-settings study; calls unchanged frozen v7 POCS code.
% All candidates start from zero dual multipliers on identical stored data.
here=fileparts(mfilename('fullpath'));
source=fullfile(fileparts(here),'solver_revision_v7');
addpath(here,source,fullfile(source,'core'));
if nargin<1||isempty(datasets),datasets={'ds00005','ds00002'};end
if nargin<2||isempty(folder),folder=fullfile(here,'outputs','pocs');end
if isstring(datasets),datasets=cellstr(datasets);end
if ischar(datasets),datasets={datasets};end
assert(exist(folder,'dir')==7||mkdir(folder),'v8:OutputFolder','Cannot create study output folder.');
% Order is fixed in advance; the measured baseline is candidate 2.
warmups=[0 100 400 100];pcgs=[100 100 100 350];
labels={'warm0_pcg100','warm100_pcg100','warm400_pcg100','warm100_pcg350'};
changed={'warmup','baseline','warmup','pcg'};records=struct([]);
for di=1:numel(datasets)
 dataset=datasets{di};prepareTimer=tic;[p,d]=v7_prepare_control(dataset);
 setupSeconds=toc(prepareTimer);
 for ci=1:numel(labels)
  pp=p;
  pp.c.v7POCSDualWarmup=warmups(ci);pp.c.v7POCSDualPCGIterations=pcgs(ci);
  pp.c.v7POCSDualNewtonIterations=220;pp.c.v7POCSDualLBFGSIterations=0;
  pp.c.v7POCSDualMaxSeconds=40;
  options=struct('WarmupIterations',warmups(ci),'PCGMaxIterations',pcgs(ci), ...
   'NewtonMaxIterations',220,'LBFGSMaxIterations',0,'TimeCapSeconds',40, ...
   'Baseline',ci==2,'ChangedOption',changed{ci},'SetupSeconds',setupSeconds, ...
   'SameStoredData',true,'Start','zero dual multipliers','FrozenSource',source, ...
   'NoiseWeightsChanged',false,'PhysicalConstraintsChanged',false, ...
   'ToleranceChanged',false,'RootTolerance',pp.c.tolerance);
  fprintf('\nSTUDY8 %s POCS %s START %s\n',dataset,labels{ci},datestr(now,31));
  timer=tic;s=v7_pocs_dual(pp);seconds=toc(timer);
  info=s.diagnostics;info.converged=s.converged;info.iterations=s.iterations;
  info.BandsSatisfied=s.diagnostics.bandsSatisfied;
  info.kkt=NaN;info.relativeGap=Inf;info.rawRelativeDualGap=NaN;
  if isfield(info,'certificate')&&isfield(info.certificate,'relativeBoundKKT')
   cert=info.certificate;info.kkt=cert.relativeBoundKKT;
   info.objective=cert.primalObjective;
   info.rawRelativeDualGap=cert.relativeDualGap;
   % An infeasible primal candidate supplies no primal upper bound. Keep its
   % raw diagnostic separately; never use it as a valid optimum gap.
   feasible=info.BandsSatisfied&&cert.normalizedSlabViolation<=1e-9&& ...
    cert.auxiliaryConstraintViolation<=1e-9&&all(isfinite(s.x))&&all(s.x>=0);
   if feasible&&cert.relativeDualGap>=-1e-9,info.relativeGap=max(cert.relativeDualGap,0);end
  end
  info.originalSolver=s;info.options=options;
  row=v8_record_result(dataset,'POCS',labels{ci},s.x,info,pp,d,s.parameter, ...
   s.diagnostics.selectionValid,seconds,options,folder);
  records=[records;row]; %#ok<AGROW>
 end
end
if ~isempty(records)
 writetable(struct2table(records),fullfile(folder,'pocs_settings.csv'));
 save(fullfile(folder,'pocs_settings.mat'),'records','warmups','pcgs','labels','-v7');
end
end
