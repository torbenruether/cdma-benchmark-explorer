function run_v8_timing_repeats
% Nine paired timing repetitions, one mixed-noise case. No truth-based choice.
root=fileparts(mfilename('fullpath'));parent=fileparts(root);
addpath(fullfile(parent,'solver_revision_v7'));addpath(fullfile(parent,'solver_revision_v7','core'));addpath(root);
folder=fullfile(root,'outputs','timing_repeats');assert(~exist(folder,'dir'),'Timing repeats already exist');mkdir(folder);
tm=tic;[p,d]=v7_prepare_control('ds00005');idx=find(strcmp(string({d.rows.Method}),'Tikhonov'),1);alpha=d.rows(idx).Parameter;
L=p.g.L/sqrt(max(norm(p.g.L'*p.g.L,inf),eps));
C=[p.B;sqrt(alpha)*L];b=[p.b;zeros(size(L,1),1)];
col=sqrt(full(sum(C.^2,1)))';S=ones(p.n,1);S(col>0)=1./col(col>0);
p.v8SmoothPrepared=struct('L',L,'C',C,'b',b,'S',S,'alpha',alpha, ...
 'factorError',norm(L'*L-p.R,'fro')/max(norm(p.R,'fro'),eps));setup=toc(tm);
names={'beta_5e-2_fixed','beta_1e-3_fixed','beta_1e-3_adaptive'};
betas=[.05 .001 .001];adapt=[false false true];order=[1 2 3;3 1 2;2 3 1];rows=struct([]);
for rep=1:3
 for j=order(rep,:)
  options=struct('beta',betas(j),'adaptive',adapt(j),'earlyTolerance',1e-7,'finalTolerance',1e-13, ...
   'damping',1e-10,'maxIterations',20,'maxLSQRIterations',300,'qrLimit',64,'maxSeconds',25, ...
   'SetupSeconds',setup,'Repeat',rep,'RotatedOrder',true);
  tm=tic;[x,info]=v8_smooth_candidate(p,alpha,p.zero,options);seconds=toc(tm);
  label=sprintf('%s_repeat%d',names{j},rep);
  rows=[rows;v8_record_result('ds00005','Tikhonov',label,x,info,p,d,alpha,d.rows(idx).ParameterSelectionValid,seconds,options,folder)]; %#ok<AGROW>
 end
end
progress=struct('state','complete','plannedControls',9,'completedControls',9,'mainBenchmark','still paused83/297');
save(fullfile(folder,'study_results.mat'),'rows','progress','-v7');
writetable(struct2table(rows),fullfile(folder,'study_results.csv'));
f=fopen(fullfile(folder,'progress.json'),'w');fprintf(f,'%s',jsonencode(progress));fclose(f);
audit_v8_strict_bounds(folder);
fprintf('V8 completed9 timing repeats; strict dual metadata verified; main benchmark remains paused.\n');
end
