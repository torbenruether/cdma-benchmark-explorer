function [mu,info]=v6_gp_polish(P,x0,d,mu,audit,c)
% Selected GP dual only: projected active-set Newton-PCG, unchanged covariance.
z=max(mu./d,0);Q=@(v)d.*P(d.*v);f=d.*x0;iterations=0;
cap=80;if isfield(c,'gpNewtonIterations'),cap=c.gpNewtonIterations;end
pcgCap=100;if isfield(c,'gpNewtonPCGIterations'),pcgCap=c.gpNewtonPCGIterations;end
lineFailed=false;inner=0;
for k=1:cap
 mu=d.*z;primal=x0+P(mu);[kkt,impact]=audit(mu,primal);
 if kkt<c.tolerance&&impact<.01*sqrt(1),break;end
 grad=d.*primal;free=z>1e-12*max(1,norm(z,inf))|grad<0;pg=grad;pg(~free)=0;
 H=@(v)free.*Q(free.*v)+1e-10*(free.*v)+(~free).*v;
 [direction,flag,~,it]=pcg(H,-pg,min(.03,max(1e-7,.05*sqrt(kkt))),pcgCap);
 inner=inner+it;direction=free.*direction;
 if flag>2||any(~isfinite(direction))||grad'*direction>=0,direction=-pg;end
 step=1;accepted=false;
 for ls=1:45
  zz=max(z+step*direction,0);delta=zz-z;slope=grad'*delta;
  % Exact quadratic objective CHANGE avoids cancellation at a nearly solved dual.
  change=slope+.5*delta'*Q(delta);
  if slope<0&&change<=1e-4*slope,accepted=true;break;end
  step=step/2;
 end
 if ~accepted
  direction=-pg;step=1;
  for ls=1:45
   zz=max(z+step*direction,0);delta=zz-z;slope=grad'*delta;
   if slope<0&&slope+.5*delta'*Q(delta)<=1e-4*slope,accepted=true;break;end
   step=step/2;
  end
 end
 if ~accepted||isequal(zz,z),lineFailed=true;break;end
 z=zz;iterations=k;
end
mu=d.*z;primal=x0+P(mu);[kkt,impact]=audit(mu,primal);
info=struct('iterations',iterations,'innerPCGIterations',inner,'kkt',kkt, ...
 'clippingMeasurementImpact',impact,'lineSearchFailed',lineFailed, ...
 'converged',kkt<c.tolerance&&impact<.01,'algorithm','Active-set projected GP dual Newton-PCG with exact quadratic-change search');
end
