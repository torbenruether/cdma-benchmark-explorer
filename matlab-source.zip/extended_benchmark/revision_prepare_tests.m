function revision_prepare_tests
% Reproduce the existing measurements exactly; prepare real failure fixtures.
c=extended_config;maxNumCompThreads(2);k=load(c.commonFile);[manifest,~]=extended_plan(c);
folder=fullfile(c.root,'test_outputs');if ~exist(folder,'dir'),mkdir(folder);end
baselineRoot=fullfile(fileparts(c.root),'outputs','factorial27');
checks=struct([]);
for idx=[1 2 5]
 row=manifest(idx,:);file=fullfile(baselineRoot,'datasets',char(row.Dataset+".mat"));
 old=load(file);data=extended_noise(old.clean,row.Relative,row.AbsoluteFraction,row.Seed,c);
 fields={'y','raw','sigma','actualSigma','absoluteNoise','relativeNoise','seed'};
 for j=1:numel(fields),assert(isequal(data.(fields{j}),old.data.(fields{j})),'Noise replication mismatch');end
 timer=tic;p=cdma_prepare(k.A,data.y,data.sigma,k.g,c,k.scan);
 [p.auxC,p.auxLo,p.auxHi]=extended_constraints(k.g,c.aux,p.scale);
 truth=old.truth;components=old.components;prepareSeconds=toc(timer);
 check=struct('dataset',char(row.Dataset),'prepareSeconds',prepareSeconds, ...
  'exactMeasurementMatch',true,'svdRelativeReconstruction',p.svdRelativeReconstruction, ...
  'conditionRatio',max(p.svdS)/min(p.svdS),'truthResidual',norm(p.B*(truth(k.g.active)/p.scale)-p.b)^2);
 checks=[checks;check]; %#ok<AGROW>
 save(fullfile(folder,char(row.Dataset+"_problem.mat")),'p','truth','components','data','row','prepareSeconds','-v7.3');
 fprintf('Prepared %s: %.2fs, SVD backward error %.3g, truth residual %.6g\n',row.Dataset,prepareSeconds,p.svdRelativeReconstruction,checks(end).truthResidual);
end
save(fullfile(folder,'preparation_checks.mat'),'checks');
fid=fopen(fullfile(folder,'preparation_checks.json'),'w');fwrite(fid,jsonencode(checks),'char');fclose(fid);
end
