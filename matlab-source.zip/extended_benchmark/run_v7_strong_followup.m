function run_v7_strong_followup
% One bounded linear-conditioning check, separate from ten primary controls.
c=v7_config;[p,d]=v7_prepare_control('ds00002');
folder=fullfile(c.root,'outputs','strong_followup');if ~exist(folder,'dir'),mkdir(folder);end
stored=load(fullfile(c.outputRoot,'ds00002_Tikhonov_LSQR_StrongPrecond.mat'));
p.c.v7StrongIterations=40;p.c.v7StrongLSQRIterations=1200;
p.c.v7StrongQRLimit=64;p.c.v7StrongMaxSeconds=120;
alpha=stored.s.parameter;timer=tic;
[x,info]=v7_strong_candidate(p,alpha,'Tikhonov',stored.s.x);
X=zeros(p.g.n);X(p.g.active)=x*p.scale;
metrics=large_metrics(X,d.truth,p.g,d.components,c.totalN);
warmStartSeconds=stored.row.Seconds;
parentParameterSelectionValid=stored.row.ParameterSelectionValid;
save(fullfile(folder,'ds00002_Tikhonov_LSQR_StrongPrecond.mat'), ...
 'x','X','info','metrics','alpha','warmStartSeconds','parentParameterSelectionValid','-v7');
fprintf('STRONG FOLLOWUP: %.1fs (+warm %.1fs) objective%d KKT%.5g chi2%.5g L2%.4g parentParameter%d\n', ...
 toc(timer),warmStartSeconds,info.converged,info.kkt,norm(p.B*x-p.b)^2,metrics.RelativeL2,parentParameterSelectionValid);
end
