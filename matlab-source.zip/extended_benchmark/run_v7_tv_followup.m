function run_v7_tv_followup
% Two additional bounded checks, kept outside the primary controls table.
% The stored Tikhonov reconstruction is a data-only warm start for Morozov.
% Preserve the full primal/dual state for a possible later continuation.
c=v7_config;[p,d]=v7_prepare_control('ds00005');
folder=fullfile(c.root,'outputs','tv_followup');if ~exist(folder,'dir'),mkdir(folder);end
p.c.pdIterations=25000;p.c.v7GraphMaxSeconds=120;
idx=find(strcmp(string({d.rows.Method}),'TV-2D'),1);alpha=d.rows(idx).Parameter;
t=v7_graph_setup(p);timer=tic;
[x,info,state]=v7_graph_candidate(p,t,alpha,[],25000,'quadratic');
X=zeros(p.g.n);X(p.g.active)=x*p.scale;metrics=large_metrics(X,d.truth,p.g,d.components,c.totalN);
save(fullfile(folder,'ds00005_TV_PD.mat'),'x','X','info','state','metrics','alpha','-v7');
fprintf('TV FOLLOWUP quadratic: %.1fs objective%d gap%.5g KKT%.5g chi2%.5g L2%.4g\n',toc(timer),info.converged,info.relativeGap,info.kkt,info.residual,metrics.RelativeL2);
idx=find(strcmp(string({d.rows.Method}),'Tikhonov'),1);
p.revisionWarmStart=d.solutions{idx}.x;timer=tic;
[x,info,state]=v7_graph_candidate(p,t,1,[],25000,'morozov');
X=zeros(p.g.n);X(p.g.active)=x*p.scale;metrics=large_metrics(X,d.truth,p.g,d.components,c.totalN);
warmStartSource='Stored data-only Tikhonov solution; no true distribution, parameter or moments used.';
save(fullfile(folder,'ds00005_TV_Morozov_PD.mat'),'x','X','info','state','metrics','warmStartSource','-v7');
fprintf('TV FOLLOWUP Morozov: %.1fs objective%d gap%.5g KKT%.5g chi2%.5g L2%.4g\n',toc(timer),info.converged,info.relativeGap,info.kkt,info.residual,metrics.RelativeL2);
end
