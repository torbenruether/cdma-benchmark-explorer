function info=revision_pocs_certificate(x,C,lo,hi,u)
% Certificate for min .5||x||^2, x>=0, lo<=C*x<=hi.
% u is signed: positive upper, negative lower slab multiplier.
% This dual lower bound is valid for any finite u. No exitflag-only success.
w=max(-C'*u,0);support=sum(hi(u>=0).*u(u>=0))+sum(lo(u<0).*u(u<0));
primal=.5*(x'*x);dual=-.5*(w'*w)-support;
info=struct('primalObjective',primal,'dualObjective',dual, ...
 'relativeDualGap',(primal-dual)/max(1,primal), ...
 'relativeStationarity',norm(x-w)/max(1,norm(x)), ...
 'primalViolation',max([0;-x;lo-C*x;C*x-hi]));
end
