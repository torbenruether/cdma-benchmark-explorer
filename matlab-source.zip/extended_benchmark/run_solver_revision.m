function run_solver_revision
% Central entry point for repaired, bounded 27-dataset benchmark.
c=extended_config;
test_revision_optimizers;
revision_gp_tgv_tests;
assert(exist(fullfile(c.root,'revision_constraint_test_results.csv'),'file')==2,'Constraint tests required');
t=readtable(fullfile(c.root,'revision_constraint_test_results.csv'));assert(all(t.passed),'Constraint tests failed');
assert(~exist(fullfile(c.outputRoot,'STOP'),'file'),'Explicit stop marker exists');
run_extended_benchmark('full');
end
