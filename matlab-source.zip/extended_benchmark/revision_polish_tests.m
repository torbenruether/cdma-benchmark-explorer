function revision_polish_tests
c=extended_config;maxNumCompThreads(1);
folder=fullfile(c.root,'test_outputs');
% Analytic positive identity problem: minimum-norm feasible point is radial.
n=9;p=struct('B',speye(n),'b',ones(n,1)*2,'n',n,'m',n,'zero',zeros(n,1), ...
 'c',c,'auxC',sparse(0,n),'auxLo',[],'auxHi',[],'lip',1,'rhs',ones(n,1)*2, ...
 'svdU',eye(n),'svdV',eye(n),'svdS',ones(n,1),'scale',1, ...
 'g',struct('n',3,'active',(1:n)'),'R',speye(n));
limit=(1-2/(9*n)+1.64485362695147*sqrt(2/(9*n)))^3;
expected=(1-sqrt(limit/(p.b'*p.b)))*p.b;
[x,certificate]=revision_pocs_polish(p,p.zero,limit,1);
assert(certificate.converged&&norm(x-expected)/norm(expected)<1e-3,'Minimum-norm dual projection regression');
save(fullfile(folder,'pocs_polish_analytic.mat'),'certificate','x','expected');
fprintf('Analytic minimum-norm projection PASS: relative error %.3g\n',norm(x-expected)/norm(expected));
for idx=[1 2]
 d=load(fullfile(folder,sprintf('ds%05d_problem.mat',idx)));s=extended_solve('POCS-PSS',d.p);
 q=struct('Dataset',char(d.row.Dataset),'Method','POCS-PSS','Success',true,'Converged',s.converged, ...
  'Seconds',s.seconds,'Iterations',s.iterations,'ReducedChi2',s.residual, ...
  'RelativeL2',NaN,'Parameter',s.parameter,'Boundary',false,'Error','');
 met=large_metrics(s.binCounts,d.truth,d.p.g,d.components,c.totalN);q.RelativeL2=met.RelativeL2;
 save(fullfile(folder,sprintf('ds%05d_POCS_PSS_polished.mat',idx)),'s','q','-v7');
 fprintf('Polished PSS %s: converged %d, chi2 %.6g, error %.4g, %.1fs\n',d.row.Dataset,s.converged,s.residual,q.RelativeL2,s.seconds);
end
end
