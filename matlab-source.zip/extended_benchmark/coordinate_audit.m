function coordinate_audit()
c=extended_config;k=load(c.commonFile);g=k.g;[~,plan]=extended_plan(c);
fine=load(c.fineFile,'gf','Af');rows=struct([]);
for j=1:3
 [T,info]=cdma_truth(g,plan.cases(j).components,c.totalN);
 tf=cdma_truth(fine.gf,plan.cases(j).components,c.totalN);
 coarse=k.A*T(:);ff=fine.Af*tf(:);
 r=struct('Case',j,'GMD_dm_nm',c.pairsNm(j,1),'GMD_dst_nm',c.pairsNm(j,2), ...
 'RetainedFraction',info.retainedFraction,'FineForwardMismatch',norm(ff-coarse)/norm(ff));
 x=log(g.dm(g.active));y=log(g.dst(g.active));z=(x+2*y)/3;w=T(g.active);h=g.h(1);
 % Cell-centre assignment approximates the common post-hoc rebin operation.
 % Compare to exact transformed centre moments; quantifies rounding, not full interpolation error.
 zr=log(g.edges(1))+h*(floor((z-log(g.edges(1)))/h)+.5);
 r.ExactCentreGMD_dv_nm=exp(sum(w.*z)/sum(w));
 r.CentreRebinGMDRelativeError=exp(sum(w.*(zr-z))/sum(w))-1;
 r.Jacobian_dm_dv=1.5;r.Jacobian_dv_dst=3;
 r.MappedCellForwardDifference=0;r.MappedCellMassRelativeError=0;
 rows=[rows;r]; %#ok<AGROW>
end
writetable(struct2table(rows),fullfile(c.root,'coordinate_audit.csv'));
save(fullfile(c.root,'coordinate_audit.mat'),'rows');disp(struct2table(rows));
end
