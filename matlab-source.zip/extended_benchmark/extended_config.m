function c=extended_config()
% Three physical shapes x three relative x three peak-referenced absolute levels.
c.root=fileparts(mfilename('fullpath'));addpath(c.root,fullfile(c.root,'core'));
c=merge(c,cdma_config); c.version='9.0-best-settings-1224';
c.binsPerDecade=64;c.rangeNm=10.^([84 192]/64);c.nBins=108;
c.pairsNm=[250 50;315 60;400 75];c.gsd=1.30;c.totalN=1e5;
c.relativeLevels=[0 .03 .05];c.absoluteLevels=[0 .03 .05];
c.replicates=1;c.seed=20261005;c.weightFloorCm3=1e-6;
c.outputRoot=fullfile(c.root,'outputs','factorial27_1224');
c.commonFile=fullfile(c.root,'cache','common.mat');
c.measurementCount=1224;c.positiveVoltageLevels=24;c.positiveRotationLevels=48;
c.fineFile=fullfile(fileparts(fileparts(c.root)),'outputs','mono_first_64bpd_20261005','forward_fine.mat');
c.methods={'POCS-PSS','Twomey-Markowski','Tikhonov','Tikhonov-lsqlin', ...
 'Lognormal-fit','TGV2-ADMM','TV-2D','Maximum Entropy','Bayesian GP-MAP','Huber-TV','POCS-CDMA'};
c.workers=2;c.threadsPerWorker=2;c.notify=true;c.pathMultipliers=[0 logspace(-6,4,17)];
c.maxIterations=4000;c.tgvIterations=12000;c.tgvTolerance=2e-5;
c.revisionNewtonIterations=180;c.revisionPCGIterations=250;
c.revisionPathNewtonIterations=40;c.revisionPathPCGIterations=100;
c.revisionSelectedNewtonIterations=400;c.revisionAlphaRefinements=5;c.revisionTrace=true;
c.pocsIterations=15000;c.legacyIterations=1500;
c.tgvAlpha=logspace(-7,1,13);c.tgvRatio=2;
% No independent total or marginal measurement supplied: never take it from truth.
c.aux=struct('total',[],'dm',[],'dst',[],'tolerance',[]);
% Preserve declared additive Gaussian noise; fitted weights remain observed-signal proxies.
c.clipNegative=false;c.poissonEnabled=false;
c.noisePolicy='Signed additive Gaussian deviations; no negative-measurement clipping; nonnegative reconstruction';
c.exportPython='C:\Program Files\Python38\python.exe';c.exportIntervalSeconds=30;
% v8 settings: same objectives, weights, constraints and strict tolerance.
c.v9SmoothBeta=1e-3;c.v9SmoothEarlyInnerTolerance=1e-7;
c.v9SmoothFinalInnerTolerance=1e-13;c.v9SmoothLSQRIterations=300;
c.v9SmoothQRLimit=64;c.v9SmoothPathIterations=20;
c.v9SmoothSelectedIterations=80;c.v9SmoothPathMaxSeconds=25;
c.v9SmoothSelectedMaxSeconds=120;
c.v7POCSDualWarmup=100;c.v7POCSDualPCGIterations=100;
c.v7POCSDualNewtonIterations=400;c.v7POCSDualMaxSeconds=180;
c.v7POCSDualLBFGSIterations=0;c.v7POCSDualPolishIterations=0;
c.v9TVADMMRelaxation=1.8;
c.assessmentExcludes={'Lognormal-fit'};
end
function c=merge(c,b)
f=fieldnames(b);for i=1:numel(f),c.(f{i})=b.(f{i});end
end
