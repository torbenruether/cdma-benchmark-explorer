function report=v9_smooth_tests()
% Bounded root-run tests; returns passed=true only after required assertions.
% Independent exhaustive rectangular QR and Optimization Toolbox references.
% No benchmark, process launch, output deletion, or truth-based selection.
c=extended_config;c.revisionTrace=false;results=struct([]);
settings=struct('beta',1e-3,'adaptive',true,'earlyTolerance',1e-7, ...
 'finalTolerance',1e-13,'damping',1e-10,'maxIterations',80, ...
 'maxLSQRIterations',300,'qrLimit',64,'maxSeconds',5);

% Weak data columns: objective and solution are known analytically.
diagonal=[1;1e-12;1e-6;1e6];B=diag(diagonal);b=B*[1;2;3;4];
p=fixture(B,b,eye(4),c);alpha=1e-24;
reference=(diagonal.*b)./(diagonal.^2+alpha);
[x,info]=v9_smooth_candidate(p,alpha,p.zero,settings);
assert(info.converged&&norm(x-reference,inf)<1e-6,'Weak-column reference failed.');
check(p,alpha,x,info);results=[results;row('weak-column analytic',x,reference,info)]; %#ok<AGROW>

% Bound-active, moderately weighted system: both rectangular routes must
% match independent exhaustive QR and the small Optimization Toolbox solve.
A=[eye(6);.3 .5 .8 .1 .2 .9;.9 .1 .4 .8 .5 .2;.1 .9 .3 .2 .8 .5; ...
 .7 .2 .1 .9 .3 .4;.4 .6 .9 .3 .1 .7;.8 .4 .2 .5 .7 .1];
weights=logspace(-2,2,size(A,1))';B=diag(weights)*A;
b=B*[1;0;.3;0;.8;0]+.02*sin((1:size(A,1))');
L=[diff(eye(6),2);.01*eye(6)];p=fixture(B,b,L,c);alpha=.25;
C=[p.B;sqrt(alpha)*L];bb=[p.b;zeros(size(L,1),1)];
[reference,referenceObjective]=enumerate(C,bb);
opts=optimset('Display','off','TolX',1e-12,'MaxIter',2000);
toolboxReference=lsqnonneg(full(C),bb,opts);
assert(norm(toolboxReference-reference,inf)<1e-7,'Independent small NNLS references disagree.');
for qrLimit=[64 0]
 current=settings;current.qrLimit=qrLimit;
 [x,info]=v9_smooth_candidate(p,alpha,p.zero,current);
 assert(info.converged&&norm(x-reference,inf)<2e-5,'Moderate QR/LSQR reference failed.');
 assert(abs(info.objective-referenceObjective)<=1e-8*max(1,referenceObjective));
 check(p,alpha,x,info);
 assert(info.strictCertificate.dualObjective<=referenceObjective+1e-9*max(1,referenceObjective));
 if qrLimit==0
  assert(info.qrSolves==0&&info.innerLSQRIterations>0,'Iterative route was not tested.');
  assert(all(info.toleranceHistory>=1e-13*(1-1e-12))&&all(info.toleranceHistory<=1e-7*(1+1e-12)));
  assert(abs(info.toleranceHistory(1)/1e-7-1)<1e-12,'Adaptive initial tolerance changed.');
 end
 results=[results;row(sprintf('moderate QR limit %d',qrLimit),x,reference,info)]; %#ok<AGROW>
end

% Alpha=0 is an NNLS reference, with the same strict objective certificate.
[reference,referenceObjective]=enumerate(p.B,p.b);
[x,zeroInfo]=v9_smooth_candidate(p,0,p.zero,settings);
assert(zeroInfo.converged&&norm(x-reference,inf)<2e-5,'Alpha=0 NNLS reference failed.');
assert(abs(zeroInfo.objective-referenceObjective)<=1e-8*max(1,referenceObjective));
check(p,0,x,zeroInfo);results=[results;row('alpha=0 reference',x,reference,zeroInfo)]; %#ok<AGROW>

% A huge global RHS makes every legacy/natural normalized KKT pass at the
% wrong point, although its weak-coordinate objective error is 0.25. A zero
% budget must fail; a nonzero budget must attempt correction instead of exit.
bad=fixture(diag([1e6 1]),[1e6;1],eye(2),c);wrong=[1;0];
limited=settings;limited.maxIterations=0;
[~,rejected]=v9_smooth_candidate(bad,1,wrong,limited);
assert(rejected.kktConverged&&~rejected.strictCertificate.converged&&~rejected.converged, ...
 'Wrong-objective normalized KKT was falsely certified.');
assert(rejected.strictCertificate.relativeGap>c.tolerance);
one=limited;one.maxIterations=1;
[corrected,attempt]=v9_smooth_candidate(bad,1,wrong,one);
assert(attempt.attemptedIterations==1&&attempt.objective<rejected.objective-.1, ...
 'Strict gap did not force a correction at the wrong KKT-qualified point.');
check(bad,1,corrected,attempt);
% The strict bound can remain conservative in this conditioning. Record its
% actual qualification; do not claim convergence from a point-error check.
conditioning=struct('wrongPointKKT',rejected.kkt,'wrongPointGap',rejected.relativeDualGap, ...
 'wrongPointRejected',~rejected.converged,'correctionAttempted',attempt.attemptedIterations, ...
 'correctedObjective',attempt.objective,'correctedGap',attempt.relativeDualGap, ...
 'correctedObjectiveConverged',attempt.converged);

% No computed negative dual gradient, even tiny, qualifies. With signed
% columns that cannot be shifted in the data-ones direction, q=0 is a valid
% conservative fallback and cannot certify this nonoptimal primal point.
signed=fixture([1;-1],[1;0],1,c);
fallback=v9_tikhonov_strict_certificate(signed,0,0);
assert(fallback.certificateFallback&&fallback.dualFeasible&&~fallback.converged);
infeasible=v9_tikhonov_strict_certificate(signed,0,-1);
assert(~infeasible.primalFeasible&&~infeasible.converged);

% Measurement-only path: the callback must not be invoked for Tikhonov.
pathConfig=c;pathConfig.pathMultipliers=[0 .001 .01 .1 1 10];
pathConfig.revisionAlphaRefinements=8;pathConfig.revisionAlphaExtensions=2;
pathConfig.v9SmoothPathIterations=20;pathConfig.v9SmoothSelectedIterations=80;
pathConfig.v9SmoothPathMaxSeconds=5;pathConfig.v9SmoothSelectedMaxSeconds=5;
pathProblem=fixture(eye(3),[3;2;1],eye(3),pathConfig);
s=v6_smooth_path('Tikhonov',pathProblem,@unexpected);
assert(s.converged&&s.parameter>0&&s.diagnostics.selectionValid&&s.diagnostics.targetBracketed, ...
 'Data-only positive-alpha discrepancy path failed.');
selected=v9_tikhonov_strict_certificate(pathProblem,s.parameter,s.x);
assert(selected.converged&&s.diagnostics.selectedSolver.strictCertificate.converged);
assert(s.diagnostics.parameterSelectionUsesConvergedCandidates);
% Uncertified candidates, including alpha=0, must never establish a bracket.
pathProblem.c.v9SmoothPathIterations=0;pathProblem.c.v9SmoothSelectedIterations=0;
failed=v6_smooth_path('Tikhonov',pathProblem,@unexpected);
assert(~failed.converged&&~failed.diagnostics.selectionValid&&~failed.diagnostics.targetBracketed);
assert(~any(failed.diagnostics.candidateConverged),'Uncertified candidate entered the bracket.');
report=struct('passed',true,'cases',results,'zeroAlpha',zeroInfo, ...
 'conditioning',conditioning,'dataOnlyPath',s.diagnostics,'zeroBudgetPath',failed.diagnostics, ...
 'scope','Independent bounded implementation checks; conditioning diagnostics retain actual strict qualification.');
fprintf('PASS V9 smooth: objective/gradient, independent QR+toolbox references, QR/LSQR, alpha=0, strict wrong-KKT rejection, certified data-only path.\n');
fprintf('V9 conditioning diagnostic: corrected strict convergence %d; relative gap %.5g.\n', ...
 conditioning.correctedObjectiveConverged,conditioning.correctedGap);

 function p=fixture(B,b,L,c)
  p=struct('B',sparse(B),'b',b,'R',sparse(L'*L),'tikhFactor',sparse(L), ...
   'rhs',B'*b,'diagQ',sum(B.^2,1)','n',size(B,2),'m',size(B,1), ...
   'lip',norm(B,2)^2,'zero',zeros(size(B,2),1),'target',1,'sigma',ones(size(b)), ...
   'c',c,'auxC',[]);
 end
 function check(p,a,x,info)
  r=p.B*x-p.b;f=.5*(r'*r)+.5*a*(x'*(p.R*x));g=p.B'*r+a*(p.R*x);
  assert(abs(info.objective-f)<=1e-11*max(1,abs(f)),'Original Tikhonov objective changed.');
  assert(norm(info.originalGradient-g,inf)<=1e-12*max(1,norm(g,inf)),'Original gradient changed.');
  D=1./sqrt(max(full(sum(p.B.^2,1))'+a*full(diag(p.R)),realmin));
  free=x>1e-13*max(1,norm(x,inf))|g<0;pg=g;pg(~free)=0;
  legacy=norm(D.*pg,inf)/max(1,norm(D.*(p.B'*p.b),inf));
  assert(abs(info.kkt-legacy)<1e-12&&~info.changedMeasurementWeights);
  assert(info.strictCertificate.dualFeasible&&info.strictCertificate.dualGradientMinimum>=0);
  assert(~info.converged||(info.kktConverged&&info.strictCertificate.converged));
 end
 function [best,objective]=enumerate(C,b)
  n=size(C,2);best=zeros(n,1);objective=.5*norm(b)^2;
  for mask=1:2^n-1
   active=find(bitget(mask,1:n));[Q,T]=qr(full(C(:,active)),0);
   if any(diag(T)==0),continue;end
   value=T\(Q'*b);if any(value<-1e-10*max(1,norm(value,inf))),continue;end
   trial=zeros(n,1);trial(active)=max(value,0);f=.5*norm(C*trial-b)^2;
   if f<objective,objective=f;best=trial;end
  end
 end
 function r=row(name,x,reference,info)
  r=struct('caseName',name,'solutionInfinityError',norm(x-reference,inf), ...
   'kkt',info.kkt,'relativeDualGap',info.relativeDualGap,'iterations',info.iterations, ...
   'innerLSQR',info.innerLSQRIterations,'qrSolves',info.qrSolves,'objectiveConverged',info.converged);
 end
 function [x,info]=unexpected(varargin) %#ok<STOUT,INUSD>
  error('V9:TikhonovDispatch','Tikhonov unexpectedly called the legacy solver.');
 end
end
