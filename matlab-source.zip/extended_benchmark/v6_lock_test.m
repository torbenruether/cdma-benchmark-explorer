function v6_lock_test
[guard,q]=v6_heavy_qp_lock;assert(q>=0);clear guard;
[guard,q]=v6_heavy_qp_lock;assert(q>=0);clear guard;
fprintf('PASS: run-scoped memory mutex acquisition, release and reacquisition.\n');
end
