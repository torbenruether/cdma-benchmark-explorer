function [manifest,plan]=extended_plan(c)
manifest=table;plan=struct('cases',[]);id=0;
for k=1:3
 a=struct('gmdDm',c.pairsNm(k,1),'gmdDst',c.pairsNm(k,2), ...
  'gsdDm',c.gsd,'gsdDst',c.gsd,'rho',0,'weight',1);
 plan.cases(k).id=sprintf('M%d',k);plan.cases(k).components=a;
 plan.cases(k).gsdDm=c.gsd;plan.cases(k).gsdDst=c.gsd;
 for ar=c.absoluteLevels
  for rr=c.relativeLevels
   id=id+1;r=struct('Dataset',string(sprintf('ds%05d',id)),'CaseId',string(sprintf('M%d',k)), ...
    'CaseIndex',k,'Modes',1,'N',c.totalN,'SigmaAbs',NaN,'AbsoluteFraction',ar, ...
    'Relative',rr,'Rho',0,'Offset',0,'Drift',0,'Forward',"coarse", ...
    'Panel',"27-factorial",'Replicate',1,'Seed',c.seed+k);
   manifest=[manifest;struct2table(r)]; %#ok<AGROW>
  end
 end
end
end
