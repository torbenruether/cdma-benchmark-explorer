function v7_graph_tests()
% Small independent analytic/epigraph fixtures. Parent starts MATLAB.
c=extended_config;c.nBins=3;c.rangeNm=[20 1000];c.tvIterations=12000;
g=cdma_grid(c);n=numel(g.active);A=sparse(1:n,g.active,1,n,g.n^2);
y=[1;4;2;6;3;5];p=cdma_prepare(A,y,ones(n,1),g,c,table);
p.auxC=sparse(0,n);p.auxLo=[];p.auxHi=[];t=v7_graph_setup(p);
% Adjoint and group-step checks, independent of any inverse solution.
u=(1:n)'/n;v=(1:size(t.K,1))'/size(t.K,1);
assert(abs(v'*(t.K*u)-(t.K'*v)'*u)<1e-11);
assert(isequal(t.sy(p.m+(1:n)),t.sy(p.m+n+(1:n))));
% Full dense spectral norm validates the small fixture's diagonal bound.
Kh=diag(t.sqrtSy)*full(t.K)*diag(t.sqrtTx);
assert(norm(Kh,2)<1,'Diagonal preconditioning bound failed');
alpha=.07;rows=struct([]);
for mode={'quadratic','morozov'}
 formulation=mode{1};pp=p;tt=t;aa=alpha;
 if strcmp(formulation,'morozov'),pp.target=.08;aa=1;end
 [x,info]=v7_graph_candidate(pp,tt,aa,[],12000,formulation);
 assert(all(isfinite(x))&&all(x>=0));
 assert(info.converged,'TV-PD strict fixture failed: %s, gap %g KKT %g',formulation,info.relativeGap,info.kkt);
 assert(info.dualFeasible&&info.primalFeasible&&info.gapConsistent);
 % A separate dense epigraph formulation uses SQP, not PD's dual state.
 z0=[x;hypot(pp.Ga*x,pp.Gm*x)+1e-8];
 options=optimoptions('fmincon','Algorithm','sqp','Display','off', ...
  'OptimalityTolerance',1e-10,'ConstraintTolerance',1e-10,'MaxIterations',1000);
 [z,fref,flag]=fmincon(@obj,z0,[],[],[],[],zeros(2*n,1),[],@constraints,options); %#ok<ASGLU>
 difference=abs(info.objective-fref)/max(1,abs(fref));
 assert(flag>0&&difference<5e-5,'Independent epigraph reference failed');
 assert(info.dualObjective<=fref+5e-8,'Claimed dual lower bound exceeds independent optimum');
 [~,short]=v7_graph_candidate(pp,tt,aa,[],1,formulation);
 assert(~short.converged,'One iteration must not be falsely certified');
 row=struct('formulation',formulation,'objective',info.objective, ...
  'referenceObjective',fref,'objectiveDifference',difference,'relativeGap',info.relativeGap, ...
  'kkt',info.kkt,'iterations',info.iterations,'converged',info.converged);rows=[rows;row]; %#ok<AGROW>
 fprintf('PASS TV-PD %s: independent objective %.3g, gap %.3g, KKT %.3g, iter %d\n', ...
  formulation,difference,info.relativeGap,info.kkt,info.iterations);
end
% Exactly constant DENSITY includes half-bin diagonal mass, not constant x.
x0=g.area(g.active)/g.h(1)^2;p0=p;p0.b=p.B*x0;p0.revisionWarmStart=x0;
t0=v7_graph_setup(p0);[~,constant]=v7_graph_candidate(p0,t0,alpha,[],50);
assert(constant.converged&&constant.objective<1e-13);
% Independent proximal validation with UNEQUAL measurement metric steps.
w=[2;-1;3];sigma=[.05;.5;2];radius=.7;
q=v7_graph_normprox(w,sigma,radius);
opts=optimoptions('fminunc','Algorithm','quasi-newton','Display','off','OptimalityTolerance',1e-10);
[qr,fr,flag]=fminunc(@(z).5*sum((z-w).^2./sigma)+radius*norm(z),q,opts);
assert(flag>0&&abs(.5*sum((q-w).^2./sigma)+radius*norm(q)-fr)<1e-9);
assert(norm(q-qr)<1e-6);
assert(all(v7_graph_normprox([.001;.001;.001],sigma,1)==0));
% Slab prox is independently checked via Moreau: interval projection.
pa=p;pa.auxC=sparse(ones(1,n));pa.auxLo=2;pa.auxHi=5;ta=v7_graph_setup(pa);
vv=zeros(size(ta.K,1),1);vv(ta.slabs)=3;step=ta.sy;
actual=v7_graph_dualprox(pa,ta,vv,step,alpha,'quadratic');
expected=vv(ta.slabs)-step(ta.slabs).*min(max(vv(ta.slabs)./step(ta.slabs),2),5);
assert(norm(actual(ta.slabs)-expected)<1e-12);
% A feasible-dual fallback is honest for a column outside kernel coverage.
pf=p;pf.B(:,1)=0;tf=v7_graph_setup(pf);yf=zeros(size(tf.K,1),1);
probe=tf.K(:,1);[~,bad]=max(abs(probe));yf(bad)=-sign(probe(bad))*.001;
z=v7_graph_certificate(pf,tf,zeros(n,1),yf,alpha,'quadratic');
assert(z.certificateFallback&&z.dualFeasible&&~z.converged);
save(fullfile(fileparts(mfilename('fullpath')),'v7_graph_tests.mat'),'rows');
fprintf('PASS adjoint, diagonal metric, half-bin density, unequal metric norm prox, slabs, fallback, no false short convergence\n');
 function f=obj(z)
  r=pp.B*z(1:n)-pp.b;
  if strcmp(formulation,'quadratic'),f=.5*(r'*r)+aa*sum(z(n+1:end));else,f=sum(z(n+1:end));end
 end
 function [ineq,equality]=constraints(z)
  ineq=hypot(pp.Ga*z(1:n),pp.Gm*z(1:n))-z(n+1:end);
  if strcmp(formulation,'morozov'),r=pp.B*z(1:n)-pp.b;ineq=[ineq;r'*r-pp.target];end
  equality=[];
 end
end
