function [x,info]=v9_smooth_candidate(p,alpha,x,settings)
% SAME nonnegative Tikhonov objective, solved through its augmented LS system.
% No data row rescaling, changed noise floor, eig cutoff, or implicit ridge.
% V8 beta=1e-3/adaptive LSQR is integrated; strict feasible-dual gap is mandatory.
solverTimer=tic;
if nargin<3||isempty(x),x=zeros(p.n,1);end
if nargin<4,settings=struct;end
assert(isfinite(alpha)&&alpha>=0);
if isfield(p,'auxC')
 assert(isempty(p.auxC),'Tikhonov requires no auxiliary measurements in this solver.');
elseif isfield(p,'g')&&isfield(p.c,'aux')
 aux=extended_constraints(p.g,p.c.aux,p.scale);
 assert(isempty(aux),'Tikhonov requires no auxiliary measurements in this solver.');
end
prepared=[];if isfield(p,'v9SmoothPrepared'),prepared=p.v9SmoothPrepared;end
if ~isempty(prepared),L=prepared.L;
elseif isfield(p,'tikhFactor'),L=p.tikhFactor;
else,L=p.g.L/sqrt(max(norm(p.g.L'*p.g.L,inf),eps));end
if ~isempty(prepared),factorError=prepared.factorError;
else,factorError=norm(L'*L-p.R,'fro')/max(norm(p.R,'fro'),eps);end
assert(factorError<1e-10,'Augmented penalty factor does not match the existing Tikhonov objective.');
if ~isempty(prepared)&&prepared.alpha==alpha
 C=prepared.C;b=prepared.b;S=prepared.S;
else
 C=[p.B;sqrt(alpha)*L];b=[p.b;zeros(size(L,1),1)];
 columnNorm=sqrt(full(sum(C.^2,1)))';S=ones(p.n,1);
 positive=columnNorm>0;S(positive)=1./columnNorm(positive);
end
assert(all(isfinite(S)),'Augmented column norm cannot be represented.');
rhs=p.B'*p.b;x=max(x,0);[value,gradient,residual]=evaluate(x);
legacyDiagonal=full(sum(p.B.^2,1))'+alpha*full(diag(p.R));
legacyScale=1./sqrt(max(legacyDiagonal,realmin));
cap=get('maxIterations',20);innerCap=get('maxLSQRIterations',300);
wallLimit=get('maxSeconds',25);budgetStopped=false;
qrLimit=get('qrLimit',64);finalTolerance=get('finalTolerance',1e-13);
earlyTolerance=get('earlyTolerance',1e-7);adaptive=get('adaptive',true);
beta=get('beta',1e-3);damping=get('damping',1e-10);
minimumAttempts=get('minIterations',0);attemptedIterations=0;
assert(isfinite(beta)&&beta>0&&isfinite(damping)&&damping>=0);
assert(earlyTolerance>=finalTolerance&&finalTolerance>0);
toleranceHistory=[];initialKKT=[];
inner=0;qrSolves=0;lineFailed=false;lsqrFlags=[];iterations=0;
for k=1:cap
 [scaledKKT,originalKKT,legacyKKT,legacyOriginal]=audit(x,gradient);
 if max([scaledKKT,originalKKT,legacyKKT,legacyOriginal])<=p.c.tolerance&&attemptedIterations>=minimumAttempts
  % Global data-RHS normalization can hide a wrong-alpha warm start. A
  % feasible dual objective bound must qualify before any early exit.
  certificate=v9_tikhonov_strict_certificate(p,alpha,x);
  if certificate.converged,break;end
 end
 if toc(solverTimer)>=wallLimit,budgetStopped=true;break;end
 attemptedIterations=attemptedIterations+1;
 currentKKT=max([scaledKKT,originalKKT,legacyKKT,legacyOriginal]);
 if isempty(initialKKT),initialKKT=currentKKT;end
 lsqrTol=finalTolerance;
 if adaptive
  % V8 inexact solve schedule. It tightens as outer work or KKT
  % progress accumulates, and uses the exact fixed final tolerance once near
  % the required certificate. The final original-x audit is never relaxed.
  byIteration=(k-1)/max(1,ceil(.75*cap)-1);
  byGradient=log10(max(initialKKT,realmin)/max(currentKKT,realmin))/4;
  progress=min(1,max([0,byIteration,byGradient]));
  lsqrTol=10^(log10(earlyTolerance)+progress*(log10(finalTolerance)-log10(earlyTolerance)));
  if currentKKT<=100*p.c.tolerance,lsqrTol=finalTolerance;end
 end
 toleranceHistory(end+1)=lsqrTol; %#ok<AGROW>
 free=(x>1e-15*max(1,norm(x,inf)))|gradient<0;
 if ~any(free),break;end
 cf=C(:,free)*spdiags(S(free),0,nnz(free),nnz(free));
 % Solve the correction using rectangular LS, not C'*C. Sparse regularizer
 % Cholesky is only a right preconditioner; it does not alter the objective.
 if nnz(free)<=qrLimit&&size(cf,1)>=nnz(free)
  [Q,T]=qr(full(cf),0);
  if all(diag(T)~=0)
   q=T\(-Q'*residual);qrSolves=qrSolves+1;flag=0;it=1;
  else,[q,flag,~,it]=lsqr(cf,-residual,lsqrTol,innerCap);end
 else
  diagonalData=full(sum(p.B(:,free).^2,1))'.*S(free).^2;
  cfReg=sqrt(alpha)*L(:,free)*spdiags(S(free),0,nnz(free),nnz(free));
  M=cfReg'*cfReg+spdiags(beta*diagonalData+damping,0,nnz(free),nnz(free));
  [T,bad]=chol(M);
  if bad==0,[q,flag,~,it]=lsqr(cf,-residual,lsqrTol,innerCap,T);
  else,[q,flag,~,it]=lsqr(cf,-residual,lsqrTol,innerCap);end
 end
 inner=inner+it;lsqrFlags(end+1)=flag; %#ok<AGROW>
 direction=zeros(p.n,1);direction(free)=S(free).*q;
 if any(~isfinite(direction))||gradient'*direction>=0
  direction=-S.^2.*gradient;direction(~free)=0;
 end
 accepted=false;step=1;
 for attempt=1:50
  candidate=max(x+step*direction,0);delta=candidate-x;slope=gradient'*delta;
  % Exact quadratic CHANGE avoids subtracting large almost equal objectives.
  Cdelta=C*delta;change=slope+.5*(Cdelta'*Cdelta);
  if slope<0&&change<=1e-4*slope,accepted=true;break;end
  step=step/2;
 end
 if ~accepted
  direction=-S.^2.*gradient;direction(~free)=0;step=1;
  for attempt=1:50
   candidate=max(x+step*direction,0);delta=candidate-x;slope=gradient'*delta;
   Cdelta=C*delta;change=slope+.5*(Cdelta'*Cdelta);
   if slope<0&&change<=1e-4*slope,accepted=true;break;end
   step=step/2;
  end
 end
 if ~accepted||isequal(candidate,x),lineFailed=true;break;end
 x=candidate;[value,gradient,residual]=evaluate(x);iterations=k;
end
[scaledKKT,originalKKT,legacyKKT,legacyOriginal]=audit(x,gradient);
certificate=v9_tikhonov_strict_certificate(p,alpha,x);
kktConverged=max([scaledKKT,originalKKT,legacyKKT,legacyOriginal])<=p.c.tolerance;
info=struct('success',true,'iterations',iterations,'attemptedIterations',attemptedIterations, ...
 'minimumRequiredIterations',minimumAttempts, ...
 'converged',kktConverged&&certificate.converged&&attemptedIterations>=minimumAttempts, ...
 'kktConverged',kktConverged,'strictCertificate',certificate,'relativeDualGap',certificate.relativeGap, ...
 'kkt',legacyKKT,'unscaledKkt',legacyOriginal,'objective',value, ...
 'naturalProjectedKKT',scaledKKT,'naturalOriginalProjectedKKT',originalKKT, ...
 'innerLSQRIterations',inner,'qrSolves',qrSolves,'lsqrFlags',lsqrFlags, ...
 'lineSearchFailed',lineFailed,'budgetStopped',budgetStopped,'seconds',toc(solverTimer), ...
 'penaltyFactorRelativeError',factorError, ...
 'columnScaleRange',[min(S),max(S)],'changedMeasurementWeights',false,'preconditionerDataFraction',beta,'preconditionerDamping',damping, ...
 'adaptiveInnerTolerance',adaptive,'toleranceHistory',toleranceHistory,'originalGradient',gradient, ...
 'algorithm','Projected active-set augmented LSQR; consistent column variables; small-system QR refinement', ...
 'stopping','Legacy-v6 masked KKT AND natural projected mappings AND strict feasible dual relative gap, all at configured tolerance');
 function [f,g,r]=evaluate(u)
  dataResidual=p.B*u-p.b;penalty=L*u;r=[dataResidual;sqrt(alpha)*penalty];
  f=.5*(dataResidual'*dataResidual)+.5*alpha*(penalty'*penalty);
  % p.R provides an independent check of the augmented factor convention.
  g=p.B'*dataResidual+alpha*(p.R*u);
 end
 function [scaled,original,legacy,legacyUnscaled]=audit(u,g)
  % Natural residual for a positive diagonal variable transform. It treats
  % near-bound positive variables continuously rather than classifying
  % every tiny interior-point coordinate as an unconstrained direction.
  mapped=min(u./S,S.*g);
  scaled=norm(mapped,inf)/max(1,norm(S.*rhs,inf));
  original=norm(min(u,g),inf)/max(1,norm(rhs,inf));
  % EXACT v6 Tikhonov masked-gradient certificate, mandatory in addition.
  free=u>1e-13*max(1,norm(u,inf))|g<0;pg=g;pg(~free)=0;
  legacy=norm(legacyScale.*pg,inf)/max(1,norm(legacyScale.*rhs,inf));
  legacyUnscaled=norm(pg,inf)/max(1,norm(rhs,inf));
 end
 function v=get(name,default)
  if isfield(settings,name),v=settings.(name);else,v=default;end
 end
end
