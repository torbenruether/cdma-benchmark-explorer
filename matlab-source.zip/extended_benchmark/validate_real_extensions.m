function validate_real_extensions()
c=extended_config;maxNumCompThreads(1);k=load(c.commonFile);
d=load(fullfile(c.root,'outputs','pilot','datasets','ds00005.mat'));
p=cdma_prepare(k.A,d.data.y,d.data.sigma,k.g,c,k.scan);
s=extended_solve('TGV2-PDHG',p);
r=large_metrics(s.binCounts,d.truth,k.g,d.components,c.totalN);
save(fullfile(c.root,'tgv_real_validation.mat'),'s','r');
fprintf('TGV real-grid: converged=%d, L2=%.5g, chi2=%.5g, seconds=%.1f\n',s.converged,r.RelativeL2,s.residual,s.seconds);
assert(all(isfinite(s.x))&&all(s.x>=0));
end
