function s=revision_optimizers(method,p,baseline)
%REVISION_OPTIMIZERS Convex objectives with scaling and independently checked exits.
% Likelihood weights and regularizers are unchanged. No normal-equation rank test.
% Called by the isolated revision dispatcher, never by the frozen baseline.
if nargin<3,baseline=[];end
t=tic; p.diagQ=full(sum(p.B.^2,1))';
if ~isfield(p,'auxC'),[p.auxC,p.auxLo,p.auxHi]=extended_constraints(p.g,p.c.aux,p.scale);end
assert(isempty(p.auxC) || strcmp(method,'Tikhonov-lsqlin'), ...
 'These optimizer arms require no auxiliary measurements; use the constrained arms when auxiliary data are enabled.');
if strcmp(method,'POCS-fixed-ridge')
 assert(~isempty(baseline)&&isfield(baseline,'alpha')&&isfield(baseline,'x'), ...
  'Fixed ridge primitive requires alpha and x.');
 p.R=speye(p.n);[x,info]=newton(p,baseline.alpha,'Tikhonov',baseline.x);
 s=struct('x',x,'converged',info.converged,'parameter',baseline.alpha, ...
  'iterations',info.iterations,'boundary',false, ...
  'selection','Fixed dual ridge multiplier for Euclidean POCS projection', ...
  'diagnostics',info);
elseif strcmp(method,'Twomey-Markowski')
 s=twomey_scaled(p);
elseif strcmp(method,'Tikhonov-lsqlin')
 assert(~isempty(baseline),'Optimizer verification requires Tikhonov alpha.');
 [x,info]=verify_lsqlin(p,baseline.parameter,baseline.x);
 s=struct('x',x,'converged',info.converged,'parameter',baseline.parameter, ...
  'iterations',info.iterations,'boundary',baseline.boundary, ...
  'selection','Same alpha as Tikhonov; independently scaled lsqlin optimizer check', ...
  'diagnostics',info);
elseif strcmp(method,'TV-2D')
 s=v6_tv_solver(p);
else
 if strcmp(method,'TV-2D'),p.tvStable=stable_tv_setup(p);end
 s=v6_smooth_path(method,p,@newton);
end
s.residual=norm(p.B*s.x-p.b)^2;s.seconds=toc(t);
s.binCounts=zeros(p.g.n);s.binCounts(p.g.active)=s.x*p.scale;
assert(all(isfinite(s.x))&&all(s.x>=-1e-12),'Invalid optimizer solution');
end

function s=twomey_scaled(p)
% Column normalization changes an early-stopped inverse's prior: nearly
% invisible bins formerly received enormous mass. Retain the bin-mass metric.
S=ones(p.n,1);C=p.B;lip=p.lip;
lip=max(lip,eps);z=zeros(p.n,1);q=z;a=1;f=.5*norm(p.b)^2;reached=false;
for k=1:p.c.maxIterations
 grad=C'*(C*q-p.b);accepted=false;
 for ls=1:35
  trial=max(q-grad/lip,0);r=C*trial-p.b;ft=.5*(r'*r);
  if ft<=f+16*eps*max(1,f),accepted=true;break;end
  if ls==1,q=z;a=1;grad=C'*(C*q-p.b);else,lip=lip*2;end
 end
 if ~accepted,break;end
 an=(1+sqrt(1+4*a*a))/2;q=trial+(a-1)/an*(trial-z);z=trial;a=an;f=ft;
 if 2*f<=1,reached=true;break;end
end
x=S.*z;passes=0;
% Column-stochastic diffusion: positivity and bin-mass preservation, including
% the half-area diagonal cells, are checked by the step size, not later clipping.
H=(p.g.D'*p.g.D)*p.g.densityScale;
rate=min(.2*p.g.h(1)^2,.9/max(full(diag(H))));P=speye(p.n)-rate*H;
if reached
 for j=1:200
  trial=P*x;
  if norm(p.B*trial-p.b)^2>1
   lo=0;hi=1;
   for l=1:40,mid=(lo+hi)/2;if norm(p.B*(x+mid*(trial-x))-p.b)^2<=1,lo=mid;else,hi=mid;end;end
   x=x+lo*(trial-x);break;
  end
  x=trial;passes=j;
 end
end
s=struct('x',max(x,0),'iterations',k+passes,'converged',reached, ...
 'parameter',k,'boundary',false, ...
 'selection','Bin-mass-metric accelerated Landweber discrepancy stop, conservative 2D diffusion', ...
 'diagnostics',struct('dataFitReached',reached,'smoothingPasses',passes,'equilibratedLipschitz',lip, ...
 'diffusionStep',rate,'stopping','Measurement discrepancy <= 1; stationarity is not required for iterative regularization', ...
 'priorNote','Column preconditioning removed to avoid huge weakly observed-bin concentrations. Acceleration changes the iteration filter; Euclidean bin-mass metric is retained.'));
end

function s=path(method,p)
if strcmp(method,'Tikhonov'),scale=p.lip;
elseif strcmp(method,'Maximum Entropy'),scale=p.lip/p.n;
elseif strcmp(method,'Huber-TV'),scale=p.lip/.03;
else,scale=sqrt(p.lip)/max(sqrt(norm([p.Ga;p.Gm],1)*norm([p.Ga;p.Gm],inf)),eps);end
params=scale*p.c.pathMultipliers;xs={};infos={};residual=[];total=0;x=p.zero;state=[];
if isfield(p,'revisionWarmStart')&&numel(p.revisionWarmStart)==p.n,x=max(p.revisionWarmStart,0);end
coarse=p;coarse.c.revisionNewtonIterations=getcfg(p.c,'revisionPathNewtonIterations',40);
coarse.c.revisionPCGIterations=getcfg(p.c,'revisionPathPCGIterations',100);
coarse.c.tvIterations=min(p.c.tvIterations,getcfg(p.c,'revisionPathTVIterations',2500));
for k=1:numel(params)
 candidateTimer=tic;
 if params(k)==0,[x,info]=newton(coarse,0,'Tikhonov',x);
 elseif strcmp(method,'TV-2D'),[x,info,state]=tv_admm(coarse,params(k),x,state);
 else,[x,info]=newton(coarse,params(k),method,x);end
 xs{k}=x;infos{k}=info;residual(k)=norm(p.B*x-p.b)^2;total=total+info.iterations;
 trace(k,params(k),info,residual(k),toc(candidateTimer));
 if k>2&&residual(k-1)>1&&residual(k)>1,break;end
end
params=params(1:numel(residual));
% Refine a data-discrepancy crossing using measurements alone. The coarse
% logarithmic scan used to leave even well-solved candidates far from target.
below=find(residual<=1,1,'last');above=find(residual>1&params>0,1,'first');
if ~isempty(below)&&~isempty(above)&&below<above
 lo=params(below);hi=params(above);xlo=xs{below};
 if lo==0
  % Zero cannot be a logarithmic endpoint; establish a positive lower end.
  lo=hi/10;
  for retry=1:8
   [xm,im]=candidate(lo,xlo);rm=norm(p.B*xm-p.b)^2;
   append(lo,xm,im,rm);if rm<=1,xlo=xm;break;end
   hi=lo;lo=lo/10;
  end
 end
 if residual(end)<=1 || params(below)>0
  for retry=1:getcfg(p.c,'revisionAlphaRefinements',5)
   mid=sqrt(lo*hi);[xm,im]=candidate(mid,xlo);rm=norm(p.B*xm-p.b)^2;
   append(mid,xm,im,rm);
   if rm<=1,lo=mid;xlo=xm;else,hi=mid;end
   if abs(log(max(rm,realmin)))<.03,break;end
  end
 end
end
[~,order]=sort(params);params=params(order);xs=xs(order);infos=infos(order);residual=residual(order);
eligible=1:numel(params);
if ismember(method,{'Maximum Entropy','Huber-TV','TV-2D'}),eligible=find(params>0);end
assert(~isempty(eligible),'This regularizer requires a positive parameter candidate.');
[~,best]=min(abs(log(max(residual(eligible),realmin))));j=eligible(best);
qualified=intersect(eligible,find(cellfun(@(v)v.converged,infos)));
% Selected solution gets additional work, keeping its regularizer and alpha.
if ~infos{j}.converged
 refined=p;refined.c.revisionNewtonIterations=getcfg(p.c,'revisionSelectedNewtonIterations',400);
 refined.c.tvIterations=max(p.c.tvIterations,12000);
 if strcmp(method,'TV-2D')&&params(j)>0,[xx,ii]=tv_admm(refined,params(j),xs{j},[]);
 else,[xx,ii]=newton(refined,params(j),method,xs{j});end
 if ii.objective<=infos{j}.objective+1e-10*max(1,abs(infos{j}.objective))
  xs{j}=xx;infos{j}=ii;residual(j)=norm(p.B*xx-p.b)^2;
 end
 total=total+ii.iterations;
end
% Polishing can move a candidate away from the discrepancy target; choose
% again using the final residuals rather than retaining an obsolete choice.
qualified=intersect(eligible,find(cellfun(@(v)v.converged,infos)));
if ~isempty(qualified),[~,best]=min(abs(log(max(residual(qualified),realmin))));j=qualified(best);
else,[~,best]=min(abs(log(max(residual(eligible),realmin))));j=eligible(best);end
certified=find(cellfun(@(v)v.converged,infos));
s=struct('x',xs{j},'converged',infos{j}.converged,'iterations',total, ...
 'parameter',params(j),'boundary',j==eligible(1)||j==eligible(end),'selection','Morozov; scaled Newton/ADMM and selected-parameter refinement', ...
 'diagnostics',struct('parameters',params,'residuals',residual,'selectedIndex',j, ...
 'selectableParameters',params(eligible), ...
 'candidateConverged',cellfun(@(v)v.converged,infos),'parameterSelectionUsesConvergedCandidates',~isempty(qualified), ...
 'selectedSolver',infos{j},'targetBracketed',~isempty(certified)&&min(residual(certified))<=1&&max(residual(certified))>=1, ...
 'targetBracketedBeforeCertification',min(residual)<=1&&max(residual)>=1));
 function [z,info]=candidate(a,start)
  candidateTimer=tic;
  if strcmp(method,'TV-2D'),[z,info]=tv_admm(coarse,a,start,[]);
  else,[z,info]=newton(coarse,a,method,start);end
  trace(numel(params)+1,a,info,norm(p.B*z-p.b)^2,toc(candidateTimer));
 end
 function append(a,z,info,r)
  params(end+1)=a;xs{end+1}=z;infos{end+1}=info;residual(end+1)=r;total=total+info.iterations;
 end
 function trace(index,a,info,r,seconds)
  if getcfg(p.c,'revisionTrace',false)
   rest=NaN;if isfield(info,'kkt'),rest=info.kkt;elseif isfield(info,'dualResidual'),rest=max(info.primalResidual,info.dualResidual);end
   fprintf('PATH %s #%d alpha=%.5g chi2=%.5g KKT/rest=%.3g iter=%d conv=%d %.2fs\n', ...
    method,index,a,r,rest,info.iterations,info.converged,seconds);
  end
 end
end

function [x,info]=newton(p,alpha,method,x)
floorX=0;if strcmp(method,'Maximum Entropy'),floorX=1e-15;
 x=max(x,1e-8*max(sum(x),1)*p.priorMass);end
x=max(x,floorX);[f,grad,diagH]=objective(p,x,alpha,method);
converged=false;inner=0;lsFailed=false;
cap=getcfg(p.c,'revisionNewtonIterations',180);
for k=1:cap
 free=(x>floorX+1e-13*max(1,norm(x,inf)))|grad<0;
 S=1./sqrt(max(diagH,realmin));
 pg=grad;pg(~free)=0;scaled=norm(S.*pg,inf)/max(1,norm(S.*p.rhs,inf));
 if scaled<=p.c.tolerance,converged=true;break;end
 % Right and left diagonal equilibration is a variable transformation only.
 Sf=S.*free;damp=1e-10;
 H=@(v)Sf.*hessian(p,x,alpha,method,Sf.*v)+damp*(free.*v)+(~free).*v;
 forcing=min(.05,max(1e-7,.1*sqrt(scaled)));
 % A sparse regularizer-based Cholesky preconditioner resolves correlations
 % missed by a diagonal preconditioner, without forming B'*B.
 M=regularizer_preconditioner(p,x,alpha,method,Sf,free,damp);
 if isempty(M),[q,flag,~,iters]=pcg(H,-Sf.*grad,forcing,getcfg(p.c,'revisionPCGIterations',250));
 else,[q,flag,~,iters]=pcg(H,-Sf.*grad,forcing,getcfg(p.c,'revisionPCGIterations',250),M,M');end
 inner=inner+iters;direction=Sf.*q;
 if any(~isfinite(direction))||flag>2||grad'*direction>=0,direction=-pg./max(diagH,realmin);end
 step=1;accepted=false;
 for ls=1:50
  z=max(x+step*direction,floorX);change=z-x;slope=grad'*change;
  [fz,gz,dz]=objective(p,z,alpha,method);
  if slope<0&&fz<=f+1e-4*slope+8*eps*max(1,abs(f)),accepted=true;break;end
  step=step/2;
 end
 if ~accepted
  direction=-pg./max(diagH,realmin);step=1;
  for ls=1:50
   z=max(x+step*direction,floorX);[fz,gz,dz]=objective(p,z,alpha,method);
   if fz<=f+1e-4*grad'*(z-x)+8*eps*max(1,abs(f)),accepted=true;break;end
   step=step/2;
  end
 end
 if ~accepted||isequal(x,z),lsFailed=true;break;end
 x=z;f=fz;grad=gz;diagH=dz;
end

free=x>floorX+1e-13*max(1,norm(x,inf))|grad<0;pg=grad;pg(~free)=0;
S=1./sqrt(max(diagH,realmin));scaled=norm(S.*pg,inf)/max(1,norm(S.*p.rhs,inf));
converged=scaled<=p.c.tolerance;
info=struct('iterations',k,'converged',converged,'kkt',scaled, ...
 'unscaledKkt',norm(pg,inf)/max(1,norm(p.rhs,inf)), ...
 'objective',f,'innerPCGIterations',inner,'lineSearchFailed',lsFailed, ...
 'algorithm','Projected Newton/Huber IRLS-PCG with sparse preconditioning and residual-form objective', ...
 'stopping','Projected stationarity in equilibrated variables, normalized by equilibrated data RHS');
end

function L=regularizer_preconditioner(p,x,a,method,Sf,free,damp)
L=[];if a==0||strcmp(method,'Maximum Entropy'),return;end
if strcmp(method,'Tikhonov'),R=a*p.R;
elseif strcmp(method,'Huber-TV')
 w=1./hypot(1,p.D*x/(.03/p.n));R=a*(p.D'*spdiags(w,0,numel(w),numel(w))*p.D);
else,return;end
S=spdiags(Sf,0,p.n,p.n);
M=S*R*S+spdiags(.05*p.diagQ.*Sf.^2+damp*free+~free,0,p.n,p.n);
[L,flag]=chol(M,'lower');
if flag>0,[L,flag]=chol(M+1e-7*speye(p.n),'lower');end
if flag>0,L=[];end
end

function [f,grad,diagonal]=objective(p,x,a,method)
r=p.B*x-p.b;f=.5*(r'*r);grad=p.B'*r;diagonal=p.diagQ;
if a==0,return;end
switch method
 case 'Tikhonov'
  Rx=p.R*x;f=f+.5*a*(x'*Rx);grad=grad+a*Rx;diagonal=diagonal+a*full(diag(p.R));
 case 'Maximum Entropy'
  u=max(x,1e-15);total=sum(u);lr=log(u./(p.priorMass*total));
  f=f+a*sum(u.*lr);grad=grad+a*lr;diagonal=diagonal+a*(1./u-1/total);
 case 'Huber-TV'
  delta=.03/p.n;dx=p.D*x;root=hypot(1,dx/delta);
  % sqrt(1+t^2)-1 = t^2/(sqrt(1+t^2)+1), avoiding cancellation.
  f=f+a*sum(dx.^2./(root+1));grad=grad+a*(p.D'*(dx./root));
  % IRLS tangent majorizer: positive curvature instead of the nearly zero
  % Newton curvature in the linear tails. Objective/gradient stay exact.
  diagonal=diagonal+a*full((p.D.^2)'*(1./root));
 otherwise,error('Unknown convex objective %s',method);
end
end

function z=hessian(p,x,a,method,v)
z=p.B'*(p.B*v);if a==0,return;end
switch method
 case 'Tikhonov',z=z+a*(p.R*v);
 case 'Maximum Entropy',z=z+a*(v./max(x,1e-15)-sum(v)/sum(x));
 case 'Huber-TV'
  root=hypot(1,p.D*x/(.03/p.n));z=z+a*(p.D'*((p.D*v)./root));
end
end

function t=stable_tv_setup(p)
R=p.Ga'*p.Ga+p.Gm'*p.Gm+speye(p.n);t.perm=symamd(R);
t.L=chol(R(t.perm,t.perm),'lower');C=full(p.B(:,t.perm)/t.L');
% Direct SVD, never eig(C*C'). No singular direction is removed by a cutoff.
[t.U,S,t.V]=svd(C,'econ');t.s=diag(S);t.ub=t.U'*p.b;
end

function [x,info,state]=tv_admm(p,alpha,x,state)
Ga=p.Ga;Gm=p.Gm;t=p.tvStable;
if isempty(state)
 rho=max(1,alpha/max(1,norm([Ga*x;Gm*x],inf)));
 za=Ga*x;zm=Gm*x;w=x;ua=zeros(p.n,1);um=ua;uw=ua;
else,rho=state.rho;za=state.za;zm=state.zm;w=state.w;ua=state.ua;um=state.um;uw=state.uw;end
converged=false;cap=p.c.tvIterations;tol=p.c.tolerance;
for k=1:cap
 oz=za;om=zm;ow=w;
 consensus=Ga'*(za-ua)+Gm'*(zm-um)+w-uw;
 v=t.L\consensus(t.perm);pv=t.V'*v;
 % Range and null-space parts treated separately: no huge Woodbury subtraction.
 yy=v-t.V*pv+t.V*((t.s.*t.ub+rho*pv)./(t.s.^2+rho));
 x=zeros(p.n,1);x(t.perm)=t.L'\yy;
 ax=Ga*x;mx=Gm*x;va=ax+ua;vm=mx+um;
 shrink=max(0,1-alpha./max(rho*hypot(va,vm),realmin));
 za=shrink.*va;zm=shrink.*vm;w=max(x+uw,0);
 ua=ua+ax-za;um=um+mx-zm;uw=uw+x-w;
 primalAbs=norm([ax-za;mx-zm;x-w]);
 dualVector=rho*(Ga'*(za-oz)+Gm'*(zm-om)+w-ow);
 dualAbs=norm(dualVector);
 % Boyd et al. section 3.3: separately scaled primal and dual feasibility.
 primal=primalAbs/max([1,norm([ax;mx;x]),norm([za;zm;w])]);
 dual=dualAbs/max(1,norm(rho*(Ga'*ua+Gm'*um+uw)));
 if max(primal,dual)<=tol,converged=true;break;end
 if mod(k,50)==0
  oldrho=rho;if primal>10*dual,rho=2*rho;elseif dual>10*primal,rho=rho/2;end
  rho=min(max(rho,1e-12),1e20);
  if rho~=oldrho,ua=ua*oldrho/rho;um=um*oldrho/rho;uw=uw*oldrho/rho;end
 end
end
x=w;r=p.B*x-p.b;f=.5*(r'*r)+alpha*sum(hypot(Ga*x,Gm*x));
station=p.B'*r+rho*(Ga'*ua+Gm'*um+uw);
info=struct('iterations',k,'converged',converged,'objective',f, ...
 'primalResidual',primal,'dualResidual',dual,'rho',rho, ...
 'stationarityResidual',norm(station)/max(1,norm(p.B'*r)), ...
 'algorithm','ADMM, sparse Cholesky and direct rectangular SVD; full configured iteration cap', ...
 'stopping','Both separately normalized primal and dual residuals');
state=struct('rho',rho,'za',za,'zm',zm,'w',w,'ua',ua,'um',um,'uw',uw);
end

function [x,info]=verify_lsqlin(p,a,x0)
L=p.g.L/sqrt(max(norm(p.g.L'*p.g.L,inf),eps));
C=[p.B;sqrt(a)*L];b=[p.b;zeros(size(L,1),1)];
S=1./sqrt(max(full(sum(C.^2,1))',realmin));CS=C*spdiags(S,0,p.n,p.n);
globalScale=max(1,norm(CS,inf));CS=CS/globalScale;bs=b/globalScale;
options=optimoptions('lsqlin','Display','off','Algorithm','trust-region-reflective', ...
 'OptimalityTolerance',min(1e-9,p.c.tolerance/10),'FunctionTolerance',1e-14, ...
 'StepTolerance',1e-14,'MaxIterations',1000,'PrecondBandWidth',0, ...
 'TolPCG',1e-6,'MaxPCGIter',300);
Aineq=[];bineq=[];
if ~isempty(p.auxC),Aineq=[p.auxC;-p.auxC]*spdiags(S,0,p.n,p.n);bineq=[p.auxHi;-p.auxLo];options.Algorithm='interior-point';end
[z,~,~,flag,out,lambda]=lsqlin(CS,bs,Aineq,bineq,[],[],zeros(p.n,1),[],x0./S,options);
x=max(S.*z,0);r=C*x-b;grad=C'*r;
if ~isempty(Aineq),grad=grad+(Aineq'*lambda.ineqlin)./S*globalScale^2;end
pg=grad;pg(x<=1e-13*max(1,norm(x,inf))&grad>0)=0;
kkt=norm(S.*pg,inf)/max(1,norm(S.*(C'*b),inf));
info=struct('iterations',out.iterations,'converged',flag>0&&kkt<=p.c.tolerance, ...
 'exitflag',flag,'kkt',kkt,'objective',.5*(r'*r), ...
 'baselineObjective',.5*norm(C*x0-b)^2,'algorithm','lsqlin TRR with explicit column equilibration', ...
 'stopping','MATLAB exitflag plus independently evaluated original-objective projected KKT');
end
function v=getcfg(c,name,default)
if isfield(c,name),v=c.(name);else,v=default;end
end
