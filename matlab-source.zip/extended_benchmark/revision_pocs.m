function s=revision_pocs(method,p)
% Convex Dykstra POCS in bin concentrations. Optional external total/marginals.
% PSS: joint weighted 95% chi-square ball. CDMA: pointwise simultaneous bands.
% Unknown physical bins are absent from p.B; reconstruction keeps them at zero.
if ~isfield(p,'auxC'),[p.auxC,p.auxLo,p.auxHi]=extended_constraints(p.g,p.c.aux,p.scale);end
x=p.zero;converged=false;projectionFailures=0;change=Inf;
limit=(1-2/(9*p.m)+1.64485362695147*sqrt(2/(9*p.m)))^3;
if strcmp(method,'POCS-PSS')
 c1=x;c2=x;lastProjection=struct('verified',true,'status','initial');
 cap=p.c.pocsIterations;if isempty(p.auxC),cap=min(cap,120);end
 if isfield(p.c,'pocsBallWarmupIterations'),cap=min(p.c.pocsIterations,p.c.pocsBallWarmupIterations);end
 cap=max(1,cap);
 for k=1:cap
  previous=x;v=x+c1;[z,lastProjection]=revision_ball_project(v,p,limit);c1=v-z;
  if ~lastProjection.verified,projectionFailures=projectionFailures+1;end
  v=z+c2;x=extended_project(v,p.auxC,p.auxLo,p.auxHi);c2=v-x;
  fit=norm(p.B*x-p.b)^2;change=norm(x-previous)/max(1,norm(x));
  if fit<=limit*(1+1e-5)&&change<=p.c.tolerance&&lastProjection.verified
   converged=true;break;
  end
  if projectionFailures>=3,break;end
 end
 diagnostics=struct('limit',limit,'projectionFailures',projectionFailures, ...
  'projection',lastProjection,'relativeChange',change,'feasible',fit<=limit*(1+1e-5));
 if ~converged&&isempty(p.auxC)&&projectionFailures==0
  % Same nearest-to-zero Euclidean projection; polish its bound-dual ridge
  % equation rather than changing the bin-mass prior or loosening the limit.
  [xx,polish]=revision_pocs_polish(p,x,limit,lastProjection.lambda);
  polishedFit=norm(p.B*xx-p.b)^2;
  % A certificate belongs to its own candidate. Do not accept polish's
  % certificate while retaining a different previous point with lower fit.
  if polish.converged||polishedFit<fit,x=xx;fit=polishedFit;end
  converged=polish.converged&&fit<=limit*(1+1e-5);
  polish.returnedResidual=fit;
  diagnostics.polish=polish;k=k+polish.iterations;
  diagnostics.feasible=fit<=limit*(1+1e-5);
 end
 parameter=limit*p.m;
 selection='95% chi-square ball; Dykstra projection from zero, bin-mass metric';
else
 % Gaussian Bonferroni family-wise 95% calibration, includes zero channels.
 % Plug-in variances make its coverage approximate, as documented.
 multiplier=sqrt(2)*erfcinv(.05/p.m);
 C=p.B;center=p.b;band=repmat(multiplier/sqrt(p.m),p.m,1);
 norms=full(sum(C.^2,2));zero=norms==0;
 assert(all(abs(center(zero))<=band(zero)),'Zero sensitivity measurement incompatible');
 C=[C(~zero,:);p.auxC];lo=[center(~zero)-band(~zero);p.auxLo];
 hi=[center(~zero)+band(~zero);p.auxHi];norms=full(sum(C.^2,2));
 empty=norms==0;
 assert(all(lo(empty)<=0&hi(empty)>=0),'Incompatible zero-row auxiliary condition');
 C=C(~empty,:);lo=lo(~empty);hi=hi(~empty);norms=norms(~empty);
 % Unit row normals improve conditioning without changing physical bands.
 rowScale=sqrt(norms);C=spdiags(1./rowScale,0,numel(rowScale),numel(rowScale))*C;
 lo=lo./rowScale;hi=hi./rowScale;norms=full(sum(C.^2,2));
 pos=zeros(p.n,1);cor=zeros(size(C,1),1);gram=full(C*C');
 cap=p.c.legacyIterations;
 if exist('quadprog','file')==2,cap=min(cap,120);end
 if isfield(p.c,'pocsSlabWarmupIterations'),cap=min(p.c.legacyIterations,p.c.pocsSlabWarmupIterations);end
 cap=max(1,cap);certificate=struct;
 for k=1:cap
  previous=x;v=x+pos;x=max(v,0);pos=v-x;
  predictionVector=C*x;deltaVector=zeros(size(cor));
  for j=1:size(C,1)
   prediction=predictionVector(j)+cor(j)*norms(j);
   correction=(prediction-min(max(prediction,lo(j)),hi(j)))/norms(j);
   deltaVector(j)=cor(j)-correction;
   predictionVector=predictionVector+deltaVector(j)*gram(:,j);cor(j)=correction;
  end
  % Exactly the same cyclic slab sweep: accumulate sparse row corrections,
  % then update x once. Gram is only a dot-product cache, never rank-inverted.
  x=x+C'*deltaVector;
  violation=max([0;-x;lo-C*x;C*x-hi]);change=norm(x-previous)/max(1,norm(x));
  checked=max(x,0);standardized=max(abs(sqrt(p.m)*(p.B*checked-p.b)));
  aux=max([0;p.auxLo-p.auxC*checked;p.auxC*checked-p.auxHi]);
  if change<=p.c.tolerance&&min(x)>=-1e-9&&aux<=1e-9&&standardized<=multiplier*(1+1e-5)
   certificate=revision_pocs_certificate(checked,C,lo,hi,cor);
   if certificate.relativeDualGap>=-1e-9&&certificate.relativeDualGap<=p.c.tolerance&& ...
     certificate.relativeStationarity<=p.c.tolerance
    x=checked;converged=true;break;
   end
  end
 end
 polish=struct('converged',false,'iterations',0,'status','Not needed');
 if ~converged
  [xx,polish]=revision_pocs_slabs_polish(p,max(x,0),C,lo,hi);
  rawBefore=max(abs(sqrt(p.m)*(p.B*max(x,0)-p.b)));
  rawAfter=max(abs(sqrt(p.m)*(p.B*xx-p.b)));
  auxAfter=max([0;-xx;p.auxLo-p.auxC*xx;p.auxC*xx-p.auxHi]);
  if polish.converged||rawAfter<rawBefore,x=xx;end
  converged=polish.converged&&rawAfter<=multiplier*(1+1e-5)&&auxAfter<=1e-9;
  k=k+polish.iterations;
  if isfield(polish,'certificate'),certificate=polish.certificate;end
 end
 x=max(x,0);fit=norm(p.B*x-p.b)^2;
 violation=max([0;-x;lo-C*x;C*x-hi]);
 normalized=max(abs(sqrt(p.m)*(p.B*x-p.b)));
 diagnostics=struct('bandMultiplier',multiplier,'bandsSatisfied',normalized<=multiplier*(1+1e-5), ...
  'maxStandardizedResidual',normalized,'relativeChange',change,'constraintViolation',violation, ...
  'polish',polish,'certificate',certificate,'infeasibleCertified',false, ...
  'legacyNote','Repaired convex paper constraint families; replaces historical NNLS-pilot, threshold and renormalization heuristics. External marginals/total are optional and inactive in the main comparison.');
 converged=converged&&diagnostics.bandsSatisfied;parameter=multiplier;
 selection='Simultaneous 95% Gaussian pointwise bands; positivity/support and external auxiliary slabs';
end
auxViolation=max([0;p.auxLo-p.auxC*x;p.auxC*x-p.auxHi]);
converged=converged&&auxViolation<=1e-9;
s=struct('x',x,'iterations',k,'converged',converged,'parameter',parameter, ...
 'selection',selection,'boundary',false,'residual',fit,'diagnostics',diagnostics);
s.diagnostics.auxiliaryConstraintViolation=auxViolation;
s.diagnostics.physicalSupport='Only dst<=dm active bins; no nonconvex support threshold';
s.diagnostics.regularizingPrior='Euclidean nearest-to-zero bin concentrations';
end
