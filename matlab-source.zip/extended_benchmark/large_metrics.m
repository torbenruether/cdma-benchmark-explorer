function r=large_metrics(X,T,g,comps,N)
r=struct; ix=g.active; ar=g.area(ix);
r.RelativeL2=sqrt(sum((X(ix)-T(ix)).^2./ar)/sum(T(ix).^2./ar));
r.TotalN_cm3=sum(X(:)); r.TotalRelativeError=(r.TotalN_cm3-N)/N;
r.ForbiddenN_cm3=sum(abs(X(~g.allowed)));
[m,s]=moments(X); [mt,st]=moments(T);
r.GMD_dm_nm=m(1); r.GMD_dst_nm=m(2); r.GSD_dm=s(1); r.GSD_dst=s(2);
r.GMD_dm_RelativeError=m(1)/mt(1)-1; r.GMD_dst_RelativeError=m(2)/mt(2)-1;
r.GSD_dm_RelativeError=s(1)/st(1)-1; r.GSD_dst_RelativeError=s(2)/st(2)-1;
r.TrueGMD_dm_nm=mt(1); r.TrueGMD_dst_nm=mt(2); r.TrueGSD_dm=st(1); r.TrueGSD_dst=st(2);
    function [m,s]=moments(Z)
        if any(~isfinite(Z(:))) || sum(Z(:))<=0, m=[NaN NaN]; s=m; return; end
        w=Z(ix)/sum(Z(:)); means=[g.meanLogDm(ix) g.meanLogDst(ix)];
        mu=w'*means; v=w'*(means.^2+g.varLog(ix))-mu.^2;
        m=exp(mu); s=exp(sqrt(max(v,0)));
    end
end
