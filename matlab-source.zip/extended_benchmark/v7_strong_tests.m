function v7_strong_tests()
% Root-run bounded fixtures. No MATLAB process or benchmark is started here.
c=extended_config;c.revisionTrace=false;c.v7StrongIterations=200;
c.v7StrongLSQRIterations=1000;c.v7StrongQRLimit=192;
results=struct([]);
% Exact diagonal solution: positive data columns spanning18 decades in Q.
diagonal=[1;1e-12;1e-6;1e6];B=diag(diagonal);b=B*[1;2;3;4];
L=eye(4);p=fixture(B,b,L,c,ones(4,1));alpha=1e-24;
reference=(diagonal.*b)./(diagonal.^2+alpha);
[x,info]=v7_strong_candidate(p,alpha,'Tikhonov',zeros(4,1));
assert(info.converged&&norm(x-reference,inf)<1e-6,'Weak-column diagonal solution mismatch');
assert(info.penaltyFactorRelativeError<1e-12&&~info.changedMeasurementWeights);
assert(info.preconditionerDataFraction==1e-6);
results=[results;row('weak columns',x,reference,info)]; %#ok<AGROW>
%12-decade measurement variances, with bound-active original-coordinate optimum.
A=[eye(6);.3 .5 .8 .1 .2 .9;.9 .1 .4 .8 .5 .2;.1 .9 .3 .2 .8 .5; ...
 .7 .2 .1 .9 .3 .4;.4 .6 .9 .3 .1 .7;.8 .4 .2 .5 .7 .1];
weights=logspace(-6,6,size(A,1))';W=diag(weights);
b=W*A*[1;0;.3;0;.8;0]+.02*sin((1:size(A,1))');
L=[diff(eye(6),2);.01*eye(6)];p=fixture(W*A,b,L,c,1./weights);alpha=.25;
[reference,referenceObjective]=enumerate([p.B;sqrt(alpha)*L],[b;zeros(size(L,1),1)]);
[x,info]=v7_strong_candidate(p,alpha,'Tikhonov',zeros(6,1));
assert(info.converged,'12-decade augmented LS objective stationarity not certified');
assert(norm(x-reference,inf)<2e-4,'12-decade independent active-set QR reference mismatch');
assert(abs(info.objective-referenceObjective)<=1e-6*max(1,referenceObjective));
d=v7_weight_diagnostics(p);assert(abs(d.sigmaDynamicRange/1e12-1)<1e-12&&~d.weightsModified);
results=[results;row('12-decade weights',x,reference,info)]; %#ok<AGROW>
% Force the iterative rectangular route, so tests do not cover QR alone.
iterative=p;iterative.c.v7StrongQRLimit=0;iterative.c.v7StrongIterations=250;
[xi,ii]=v7_strong_candidate(iterative,alpha,'Tikhonov',zeros(6,1));
assert(ii.converged&&norm(xi-reference,inf)<5e-4,'LSQR-only independent reference mismatch');
results=[results;row('12-decade LSQR',xi,reference,ii)]; %#ok<AGROW>
% A bounded failure must stay a failure; no exit flag is substituted for KKT.
limited=p;limited.c.v7StrongIterations=0;
[~,failure]=v7_strong_candidate(limited,alpha,'Tikhonov',zeros(6,1));
assert(~failure.converged,'Zero-budget partial result was falsely certified');
negative=p;negative.b=-2*ones(size(b));negative.target=1;
bad=v7_weight_diagnostics(negative);assert(bad.targetProvablyIncompatible);
% Measurement-only parameter selection on an independent small physical grid.
cc=c;cc.nBins=6;cc.pathMultipliers=[0 logspace(-5,3,9)];cc.revisionAlphaRefinements=8;
cc.v7StrongPathIterations=100;cc.v7StrongSelectedIterations=200;
g=cdma_grid(cc);n=numel(g.active);AA=sparse(1:n,g.active,ones(n,1),n,g.n^2);
y=500*exp(-((1:n)'-n*.55).^2/(n*.15)^2)+4;
pp=cdma_prepare(AA,y,4*ones(n,1),g,cc,table);
s=v7_strong_tikhonov(pp);
assert(s.converged&&s.diagnostics.selectionValid&&s.parameter>0,'Positive-alpha discrepancy path not certified');
save(fullfile(c.root,'v7_strong_fixture_results.mat'),'results','s','failure','bad','-v7');
fprintf('PASS v7 strong: weak columns,12-decade independent active-set QR/LSQR, honest bounded failure, positive-alpha discrepancy path.\n');
 function p=fixture(B,b,L,c,sigma)
  p=struct('B',sparse(B),'b',b,'R',sparse(L'*L),'tikhFactor',sparse(L), ...
   'rhs',B'*b,'diagQ',sum(B.^2,1)','n',size(B,2),'m',size(B,1), ...
   'lip',norm(B,2)^2,'zero',zeros(size(B,2),1),'target',1,'sigma',sigma,'c',c,'auxC',[]);
 end
 function [best,objective]=enumerate(C,b)
  % Every feasible active set is examined by rectangular QR, never normal
  % equations or the candidate optimizer. n<=6 keeps this independent audit tiny.
  n=size(C,2);best=zeros(n,1);objective=.5*norm(b)^2;
  for mask=1:2^n-1
   active=find(bitget(mask,1:n));[Q,T]=qr(full(C(:,active)),0);
   if any(diag(T)==0),continue;end
   v=T\(Q'*b);if any(v<-1e-10*max(1,norm(v,inf))),continue;end
   candidate=zeros(n,1);candidate(active)=max(v,0);f=.5*norm(C*candidate-b)^2;
   if f<objective,objective=f;best=candidate;end
  end
 end
 function r=row(name,x,reference,info)
  r=struct('caseName',name,'solutionInfinityError',norm(x-reference,inf), ...
   'kkt',info.kkt,'originalKKT',info.unscaledKkt,'iterations',info.iterations, ...
   'innerLSQR',info.innerLSQRIterations,'qrSolves',info.qrSolves,'objectiveConverged',info.converged);
 end
end
