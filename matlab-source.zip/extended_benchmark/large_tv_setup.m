function t=large_tv_setup(p)
R=p.Ga'*p.Ga+p.Gm'*p.Gm+speye(p.n);
permutation=symamd(R); L=chol(R(permutation,permutation),'lower');
t.solveR=@solveR;
W=solveR(full(p.B')); C=full(p.B*W); [U,ev]=eig((C+C')/2,'vector');
t.ev=max(ev,0);t.V=W*U;
    function v=solveR(rhs)
        v=zeros(size(rhs));v(permutation,:)=L'\(L\rhs(permutation,:));
    end
end
