function q=v7_graph_normprox(w,sigma,radius)
% prox_{Sigma*radius*||.||_2}: nonuniform Sigma needs a scalar root.
% The zero test follows the Euclidean dual-ball subgradient at q=0.
if radius==0,q=w;return;end
if norm(w./sigma)<=radius,q=zeros(size(w));return;end
lo=0;hi=1/max(sigma);
for j=1:100
 if hi*norm(w./(1+hi*sigma))>=radius,break;end
 hi=2*hi;
end
assert(isfinite(hi)&&hi*norm(w./(1+hi*sigma))>=radius, ...
 'TV-Morozov-PD: weighted data proximal root could not be bracketed.');
for j=1:55
 mid=(lo+hi)/2;
 if mid*norm(w./(1+mid*sigma))>radius,hi=mid;else,lo=mid;end
end
q=w./(1+((lo+hi)/2)*sigma);
end
