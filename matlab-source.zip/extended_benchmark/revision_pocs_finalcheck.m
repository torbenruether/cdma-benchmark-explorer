function revision_pocs_finalcheck
c=extended_config;maxNumCompThreads(1);folder=fullfile(c.root,'test_outputs');
d=load(fullfile(folder,'ds00001_problem.mat'));d.p.c=c;
s=extended_solve('POCS-PSS',d.p);
met=large_metrics(s.binCounts,d.truth,d.p.g,d.components,c.totalN);
q=struct('Dataset',char(d.row.Dataset),'Method','POCS-PSS','Success',true,'Converged',s.converged, ...
 'Seconds',s.seconds,'Iterations',s.iterations,'ReducedChi2',s.residual, ...
 'RelativeL2',met.RelativeL2,'Parameter',s.parameter,'Boundary',false,'Error','');
save(fullfile(folder,'final','ds00001_POCS_PSS_final.mat'),'s','q','-v7');
fprintf('Final POCS-PSS: conv=%d, chi2=%.6g, L2=%.4g, %.1fs\n',s.converged,s.residual,q.RelativeL2,s.seconds);
assert(s.dataCompatible,'POCS data boundary not reached on noiseless real fixture');
end
