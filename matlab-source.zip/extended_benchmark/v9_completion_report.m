function v9_completion_report(c,state)
% Report actual execution and scientific certificates separately.
files=dir(fullfile(c.outputRoot,'metrics','ds*.csv'));rows=table;
for k=1:numel(files),rows=[rows;readtable(fullfile(files(k).folder,files(k).name))];end %#ok<AGROW>
if ~isempty(rows),writetable(rows,fullfile(c.outputRoot,'results.csv'));save(fullfile(c.outputRoot,'summary.mat'),'rows','c','state');end
fid=fopen(fullfile(c.root,'RUN_RESULTS_REPORT.txt'),'w');assert(fid>=0);guard=onCleanup(@()fclose(fid)); %#ok<NASGU>
fprintf(fid,'CDMA v9 -- %s -- %s\n',state,datestr(now,31));
fprintf(fid,'Saved %d / 297 solver runs; Lognormal-fit excluded from assessment.\n',height(rows));
if isempty(rows),return;end
fprintf(fid,'Execution errors: %d. Objective converged: %d. Data compatible: %d. Parameter selection valid: %d.\n', ...
 sum(~rows.Success),sum(rows.ObjectiveConverged),sum(rows.DataCompatible),sum(rows.ParameterSelectionValid));
fprintf(fid,'Validated excluding fit: %d. All accuracy targets AND validation excluding fit: %d.\n', ...
 sum(rows.Validated & rows.AssessmentIncluded),sum(rows.TargetPass));
fprintf(fid,'Accuracy goals: N, both GMD and both GSD relative errors <=5%%; area-weighted 2D relative L2 <=20%%.\n');
fprintf(fid,'Identical forward/inverse grid is an idealised consistency test; fine-forward audit is separate.\n');
for k=1:numel(c.methods)
 select=strcmp(rows.Method,c.methods{k});q=rows(select,:);
 fprintf(fid,'%s: saved=%d, executionErrors=%d, optimum=%d, data=%d, parameter=%d, validated=%d, targetPass=%d, boundary=%d\n', ...
  c.methods{k},height(q),sum(~q.Success),sum(q.ObjectiveConverged),sum(q.DataCompatible), ...
  sum(q.ParameterSelectionValid),sum(q.Validated & q.AssessmentIncluded),sum(q.TargetPass),sum(q.Boundary));
end
fprintf(fid,'Do not treat numerical convergence, data compatibility or a fitted monomodal shape as proof of scientific accuracy.\n');
end
