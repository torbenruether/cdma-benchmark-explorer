function v6_real_pocs_smoke
c=extended_config;k=load(c.commonFile);[manifest,~]=extended_plan(c);maxNumCompThreads(1);
folder=fullfile(c.root,'pocs_smoke_outputs');if ~exist(folder,'dir'),mkdir(folder);end
results=struct([]);
for index=[1 5]
 row=manifest(index,:);a=struct('gmdDm',c.pairsNm(1,1),'gmdDst',c.pairsNm(1,2), ...
  'gsdDm',c.gsd,'gsdDst',c.gsd,'rho',0,'weight',1);
 truth=cdma_truth(k.g,a,c.totalN);clean=k.A*truth(:);data=extended_noise(clean,row.Relative,row.AbsoluteFraction,row.Seed,c);
 p=cdma_prepare(k.A,data.y,data.sigma,k.g,c,k.scan);
 for method={'POCS-PSS','POCS-CDMA'}
  s=extended_solve(method{1},p);r=large_metrics(s.binCounts,truth,k.g,a,c.totalN);
  r.Dataset=char(row.Dataset);r.Method=method{1};r.Validated=s.benchmarkValid;
  r.ObjectiveConverged=s.objectiveConverged;r.DataCompatible=s.dataCompatible;
  r.ParameterSelectionValid=s.parameterSelectionValid;r.ConstraintViolation=s.constraintViolation;
  r.Seconds=s.seconds;r.Iterations=s.iterations;r.Status=s.status;
  results=[results;r];filename=[char(row.Dataset) '_' regexprep(method{1},'[^a-zA-Z0-9]','_') '.mat'];
  save(fullfile(folder,filename),'s','r','data','row','truth','-v7');
  writetable(struct2table(results),fullfile(folder,'results.csv'));
  assert(all(isfinite(s.x))&&min(s.x)>=0&&s.constraintViolation<=1e-9);
  fprintf('Real1224 %s %s: objective%d data%d parameter%d validated%d L2%.4g %.1fs\n', ...
   row.Dataset,method{1},s.objectiveConverged,s.dataCompatible,s.parameterSelectionValid,s.benchmarkValid,r.RelativeL2,s.seconds);
 end
end
end
