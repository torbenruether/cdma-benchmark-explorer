function v6_export_test
% Bounded integration check: export the currently selected run without solving.
c=extended_config;
c.outputRoot=fullfile(c.root,'export_test');
if ~exist(c.outputRoot,'dir'),mkdir(c.outputRoot);end
v6_export_checkpoint(c);
logtext=fileread(fullfile(c.outputRoot,'web_export.log'));
assert(numel(strfind(logtext,'exit=0'))>=3,'Website export integration failed');
assert(isempty(regexp(logtext,'exit=[1-9]','once')),'Website export returned an error');
fprintf('V6 website export integration PASS\n');
end
