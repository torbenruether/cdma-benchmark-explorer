function x=extended_project(v,C,lo,hi)
% Euclidean Dykstra projection onto positivity and linear measurement slabs.
assert(all(isfinite(v)),'Nonfinite projection input');
if isempty(C),x=max(v,0);return;end
assert(size(C,2)==numel(v)&&size(C,1)==numel(lo)&&numel(lo)==numel(hi), ...
 'Invalid projection dimensions');
assert(all(isfinite(nonzeros(C)))&&all(isfinite(lo))&&all(isfinite(hi))&&all(lo<=hi), ...
 'Invalid projection bands');
x=v;pos=zeros(size(v));cor=zeros(size(C,1),1);norms=full(sum(C.^2,2));
empty=norms==0;assert(all(lo(empty)<=0 & hi(empty)>=0),'Infeasible zero-row constraint');
C=C(~empty,:);lo=lo(~empty);hi=hi(~empty);norms=norms(~empty);cor=cor(~empty);
for iter=1:5000
 old=x;z=x+pos;x=max(z,0);pos=z-x;
 for j=1:size(C,1)
  row=C(j,:)';z=x+cor(j)*row;t=C(j,:)*z;
  correction=(t-min(max(t,lo(j)),hi(j)))/norms(j);
  x=z-correction*row;cor(j)=correction;
 end
 violation=max([0;-x;lo-C*x;C*x-hi]);
 if norm(x-old)<1e-10*max(1,norm(x))&&violation<1e-9,return;end
end
error('Auxiliary constraints inconsistent or projection did not converge');
end
