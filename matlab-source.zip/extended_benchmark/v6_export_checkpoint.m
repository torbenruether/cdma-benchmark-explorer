function v6_export_checkpoint(c)
% Run-scoped website update only; no scheduled automation or extra MATLAB process.
parent=fileparts(c.root);logfile=fullfile(c.outputRoot,'web_export.log');
for script={'audit_convergence.py','build_web.py','validate_export.py'}
 command=sprintf('"%s" "%s"',c.exportPython,fullfile(parent,script{1}));
 [status,text]=system(command);fid=fopen(logfile,'a');
 fprintf(fid,'\n%s | %s | exit=%d\n%s',datestr(now,31),script{1},status,text);fclose(fid);
 if status~=0,warning('CDMA:WebExport','Checkpoint export failed: %s; saved MATLAB results retained.',script{1});return;end
end
end
