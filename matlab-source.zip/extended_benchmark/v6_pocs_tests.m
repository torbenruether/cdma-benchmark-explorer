function results=v6_pocs_tests()
% Isolated constraint/projection regressions. Does not launch factorial jobs.
% Truth in these fixtures is used only to construct/prove test feasibility.
root=fileparts(mfilename('fullpath'));addpath(root,fullfile(root,'core'));
c=struct('nBins',3,'rangeNm',[20 1000],'pocsIterations',8000, ...
 'legacyIterations',2000,'tolerance',2e-6,'revisionNewtonIterations',300, ...
 'revisionPCGIterations',300,'maxIterations',4000);
c.aux=struct('total',[],'dm',[],'dst',[],'tolerance',[]);
g=cdma_grid(c);n=numel(g.active);
fixtures={@positivityAndSupport,@simplexAndSlabs,@jointMarginals, ...
 @invalidAuxiliary,@inconsistentSlabs,@ballStationarity,@exactNullDirections,@illConditionedPocs,@pocsWithAuxiliary, ...
 @analyticalSlabMinimum,@analyticalBallMinimum,@dualCertificate,@finiteBudget};
labels={'positivity_and_physical_support','simplex_slab_and_idempotence', ...
 'simultaneous_total_and_marginals','invalid_auxiliary_inputs', ...
 'inconsistent_slab_detection','ball_projection_stationarity','exact_null_and_incompatible_measurement', ...
 'ill_conditioned_feasible_pocs', ...
 'both_pocs_arms_with_active_auxiliary','analytical_slab_minimum_norm', ...
 'analytical_ball_minimum_norm','primal_dual_certificate','bounded_failure_is_not_infeasibility'};
results=struct('name',{},'passed',{},'seconds',{},'message',{});
for k=1:numel(fixtures)
 timer=tic;
 try
  fixtures{k}();passed=true;message='PASS';
 catch exception
  passed=false;message=[exception.identifier ': ' exception.message];
 end
 results(k)=struct('name',labels{k},'passed',passed,'seconds',toc(timer),'message',message); %#ok<AGROW>
 fprintf('%s: %s (%.3fs)\n',labels{k},message,results(k).seconds);
end
save(fullfile(root,'v6_pocs_test_results.mat'),'results');
writetable(struct2table(results),fullfile(root,'v6_pocs_test_results.csv'));
assert(all([results.passed]),'revision:ConstraintTestsFailed', ...
 '%d of %d isolated constraint fixtures failed; inspect CSV.',sum(~[results.passed]),numel(results));

 function positivityAndSupport()
  v=(-n/2:n/2-1)';assert(numel(v)==n);
  x=extended_project(v,sparse(0,n),[],[]);
  assert(isequal(x,max(v,0)),'Positivity projection differs from clipping.');
  full=zeros(g.n);full(g.active)=x;
  assert(all(full(~g.allowed)==0),'Unphysical bins received concentration.');
  assert(all(g.dst(g.active)<=g.dm(g.active)), 'active includes unphysical cells.');
  dv=(g.dst(g.active).^2.*g.dm(g.active)).^(1/3);
  assert(all(dv>=g.dst(g.active)*(1-1e-13)) && ...
    all(dv<=g.dm(g.active)*(1+1e-13)), 'dv support relation violated.');
 end

 function simplexAndSlabs()
  v=[-1;2;3];C=sparse(ones(1,3));x=extended_project(v,C,1,1);
  assert(norm(x-[0;0;1],inf)<1e-8,'Incorrect simplex closest point.');
  assert(norm(extended_project(x,C,1,1)-x,inf)<1e-9,'Projection is not idempotent.');
  C=sparse([1 1 0]);lo=1;hi=2;
  probes={[0;0;3],[.5;.8;3],[2;2;3]};
  expected={[.5;.5;3],[.5;.8;3],[1;1;3]};
  for j=1:3
   z=extended_project(probes{j},C,lo,hi);
   assert(norm(z-expected{j},inf)<1e-9,'Incorrect below/inside/above band projection.');
  end
 end

 function jointMarginals()
  known=(1:n)';N=zeros(g.n);N(g.active)=known;
  aux=measurementAuxiliary(N,0);
  [C,lo,hi]=extended_constraints(g,aux,1);
  assert(size(C,1)==1+2*g.n,'Not all external conditions represented.');
  z=extended_project(linspace(-20,10,n)',C,lo,hi);
  assert(all(z>=-1e-9),'Negative concentration after joint projection.');
  assert(max([lo-C*z;C*z-hi])<1e-8,'Not all marginals/total simultaneously satisfied.');
  assert(norm(extended_project(z,C,lo,hi)-z,inf)<1e-8,'Joint projection is not idempotent.');
  reconstructed=zeros(g.n);reconstructed(g.active)=z;
  assert(norm(sum(reconstructed,1)'-sum(N,1)',inf)<1e-8,'dm axis/column sum swapped.');
  assert(norm(sum(reconstructed,2)-sum(N,2),inf)<1e-8,'dst axis/row sum swapped.');
  assert(all(reconstructed(~g.allowed)==0),'Marginal projection escaped physical support.');
 end

 function invalidAuxiliary()
  aux=measurementAuxiliary(eye(g.n),1);
  bad=aux;bad.total=rmfield(bad.total,'source');mustError(@()extended_constraints(g,bad,1),'missing source');
  bad=aux;bad.total.sigma=-1;mustError(@()extended_constraints(g,bad,1),'negative uncertainty');
  bad=aux;bad.total.sigma=Inf;mustError(@()extended_constraints(g,bad,1),'infinite uncertainty');
  bad=aux;bad.total.sigma=NaN;mustError(@()extended_constraints(g,bad,1),'NaN uncertainty');
  bad=aux;bad.dm.value(1)=NaN;mustError(@()extended_constraints(g,bad,1),'NaN value');
  bad=aux;bad.total.sigma=[1 2];mustError(@()extended_constraints(g,bad,1),'uncertainty size mismatch');
  mustError(@()extended_constraints(g,aux,0),'zero scale');
  mustError(@()extended_constraints(g,aux,-1),'negative scale');
  mustError(@()extended_constraints(g,aux,Inf),'infinite scale');
 end

 function inconsistentSlabs()
  mustError(@()extended_project([1;2],sparse([1 1]),3,2),'lo greater than hi');
  mustError(@()extended_project([1;2],sparse([0 0]),1,2),'unattainable zero-row band');
  mustError(@()extended_project([1;2],sparse([1 1;1 1]),[1;3],[1;3]),'contradictory totals');
 end

 function illConditionedPocs()
  % Dense, positive, rectangular full-row-rank operator: avoids a diagonal
  % artificial easy special case while proving the old Gram rank bug.
  B=[1e8*ones(1,n);1 .1 1 .1 1 .1;.01 .02 .03 .04 .05 .06];
  known=[1;80;2;70;3;60];p=syntheticProblem(B,known);
  gram=full(B*B');[oldU,oldEv]=eig((gram+gram')/2,'vector');
  oldNull=oldEv<=max(oldEv)*1e-13;
  oldUnavoidable=sum((oldU(:,oldNull)'*p.b).^2);
  limit=(1-2/(9*p.m)+1.64485362695147*sqrt(2/(9*p.m)))^3;
  assert(norm(B*known-p.b)==0,'Fixture not feasible.');
  assert(oldUnavoidable>100*limit,'Fixture does not expose old false rank diagnosis.');
  assert(p.svdS(end)>0 && p.svdS(1)/p.svdS(end)>1e9,'Fixture not sufficiently ill-conditioned.');
  [projected,pi]=revision_ball_project(p.zero,p,limit);
  assert(pi.verified && norm(B*projected-p.b)^2<=limit*(1+1e-5), ...
   'Direct SVD projection failed the known feasible ill-conditioned ball.');
  for method={'POCS-PSS','POCS-CDMA'}
   s=revision_pocs(method{1},p);
   if ~s.converged
    fprintf('  %s diagnostic before rejection: iterations=%d residual=%.9g\n',method{1},s.iterations,s.residual);
    disp(s.diagnostics);
   end
   assert(all(isfinite(s.x)) && all(s.x>=-1e-8),'POCS returned invalid concentrations.');
   % Numerical nonconvergence is permissible for this extremely conditioned
   % diagnostic; a FALSE mathematical infeasibility assertion is not.
   assert(~isfield(s.diagnostics,'infeasibleCertified')||~s.diagnostics.infeasibleCertified, ...
    'Known feasible data were declared mathematically infeasible.');
   direct=norm(B*s.x-p.b)^2;
   if strcmp(method{1},'POCS-PSS')&&s.converged
    assert(direct<=limit*(1+1e-5),'Converged POCS-PSS violates direct ball.');
   end
   fprintf('  %s: direct weighted squared residual %.7g, iterations %d; old false minimum %.7g\n', ...
     method{1},direct,s.iterations,oldUnavoidable);
  end
 end

 function ballStationarity()
  B=[1 .4 .2 .5 .3 .1;.2 1 .5 .1 .4 .6];
  p=syntheticProblem(B,(1:n)');v=-ones(n,1);limit=.5;
  [z,info]=revision_ball_project(v,p,limit);
  assert(info.verified && info.lambda>0,'Ball projection was not verified.');
  r=B*z-p.b;
  assert(abs(norm(r)^2-limit)<1e-7,'Projected point not on ball boundary.');
  stationarity=z-v+info.lambda*B'*r;
  assert(norm(stationarity)/max(1,norm(z-v))<1e-8,'Ball closest-point KKT condition failed.');
  [again,~]=revision_ball_project(z,p,limit);
  assert(norm(again-z)<1e-7,'Ball projection is not idempotent.');
 end

 function exactNullDirections()
  B=zeros(2,n);p=syntheticProblem(B,ones(n,1));
  for method={'POCS-PSS','POCS-CDMA'}
   s=revision_pocs(method{1},p);
   assert(s.converged && all(s.x==0),'Compatible zero operator mishandled.');
  end
  p.b=[10;0];p.y=p.b/sqrt(p.m); % Same statistical scale as sigma=1/sqrt(m).
  s=revision_pocs('POCS-PSS',p);
  assert(~s.converged && s.diagnostics.projectionFailures>0, ...
   'Incompatible exact-null data incorrectly accepted.');
  mustError(@()revision_pocs('POCS-CDMA',p),'zero sensitivity incompatible measurement');
 end

 function pocsWithAuxiliary()
  known=(1:n)';p=syntheticProblem(eye(n),known);
  N=zeros(g.n);N(g.active)=known;
  [p.auxC,p.auxLo,p.auxHi]=extended_constraints(g,measurementAuxiliary(N,.03),1);
  for method={'POCS-PSS','POCS-CDMA'}
   s=revision_pocs(method{1},p);
   assert(s.converged,'%s did not converge with feasible external conditions.',method{1});
   assert(max([0;-s.x;p.auxLo-p.auxC*s.x;p.auxC*s.x-p.auxHi])<1e-6, ...
    '%s missed active positivity/total/marginal conditions.',method{1});
  end
 end

 function p=syntheticProblem(B,known)
  % Deliberately does not load the 1224-row main cache or call core prepare.
  m=size(B,1);AA=sparse(m,g.n^2);AA(:,g.active)=B;
  p=struct('B',sparse(B),'b',B*known,'A',sparse(B),'fullA',AA, ...
   'y',B*known,'sigma',ones(m,1)/sqrt(m),'g',g,'c',c,'scale',1, ...
   'm',m,'n',n,'zero',zeros(n,1),'rhs',B'*(B*known), ...
   'diagQ',sum(B.^2,1)','auxC',sparse(0,n),'auxLo',[],'auxHi',[]);
  [p.svdV,S,p.svdU]=svd(full(p.B'),'econ');p.svdS=diag(S);
  p.lip=p.svdS(1)^2;p.e=p.svdS.^2;p.V=p.svdU;
 end

 function analyticalSlabMinimum()
  known=[.1;3;5;1;7;.2];p=syntheticProblem(eye(n),known);
  kappa=sqrt(2)*erfcinv(.05/n);expected=max(known-kappa/sqrt(n),0);
  s=revision_pocs('POCS-CDMA',p);
  assert(s.converged && s.diagnostics.bandsSatisfied,'Analytical slab point not certified.');
  assert(norm(s.x-expected)/max(1,norm(expected))<1e-6,'Wrong closest point of positive coordinate slabs.');
  assert(isfield(s.diagnostics,'certificate'),'Missing minimum-norm certificate.');
  assert(s.diagnostics.certificate.relativeDualGap<=c.tolerance,'Primal/dual gap too large.');
  % Exercise the new QP path explicitly, preserving the same exact bands.
  if exist('quadprog','file')==2
   [xx,info]=revision_pocs_slabs_polish(p,p.zero,speye(n), ...
    known-kappa/sqrt(n),known+kappa/sqrt(n));
   save(fullfile(root,'v6_pocs_qp_fixture_diagnostics.mat'),'xx','info','expected');
   if isfield(info,'certificate')
    fprintf('  QP direct fixture: flag %.0f, violation %.3g, gap %.3g, stationarity %.3g, solution error %.3g\n', ...
     info.exitflag,info.certificate.primalViolation,info.certificate.relativeDualGap, ...
     info.certificate.relativeStationarity,norm(xx-expected)/max(1,norm(expected)));
   else
    fprintf('  QP direct fixture: %s\n',info.status);
   end
   assert(info.converged,'QP fixture did not obtain independent certificate.');
   assert(norm(xx-expected)/max(1,norm(expected))<1e-6,'QP changed the CDMA regularization prior.');
  end
 end

 function analyticalBallMinimum()
  known=(1:n)';p=syntheticProblem(eye(n),known);
  limit=(1-2/(9*n)+1.64485362695147*sqrt(2/(9*n)))^3;
  expected=(1-sqrt(limit)/norm(known))*known;
  s=revision_pocs('POCS-PSS',p);
  assert(s.converged && norm(s.x-expected)/norm(expected)<1e-7,'Ball nearest-to-zero solution incorrect.');
  if isfield(s.diagnostics,'polish') && s.diagnostics.polish.converged
   assert(abs(s.diagnostics.polish.returnedResidual-s.residual)<1e-12, ...
    'Accepted polish certificate does not belong to returned point.');
  end
 end

 function dualCertificate()
  C=speye(3);lo=[1;0;2];hi=[3;4;5];x=lo;u=-lo;
  info=revision_pocs_certificate(x,C,lo,hi,u);
  assert(abs(info.relativeDualGap)<1e-12 && info.relativeStationarity<1e-12, ...
   'Exact projection primal/dual certificate is wrong.');
  wrong=revision_pocs_certificate([2;1;3],C,lo,hi,u);
  assert(wrong.relativeDualGap>.01 && wrong.relativeStationarity>.01, ...
   'Wrong feasible point was accepted as minimum norm.');
 end

 function finiteBudget()
  p=syntheticProblem([1 .4 .2 .5 .3 .1;.2 1 .5 .1 .4 .6],(1:n)');
  p.c.legacyIterations=1;p.c.pocsSlabWarmupIterations=1;p.c.pocsSlabQPIterations=1;
  s=revision_pocs('POCS-CDMA',p);
  assert(all(isfinite(s.x)) && all(s.x>=0),'Bounded run returned invalid concentrations.');
  assert(~s.diagnostics.infeasibleCertified,'Iteration limit was called physical infeasibility.');
  assert(~s.diagnostics.polish.infeasibleCertified,'QP exit flag was promoted to an infeasibility proof.');
  if s.converged
   assert(s.diagnostics.bandsSatisfied,'Bounded numerical success is outside original data bands.');
  end
 end

 function aux=measurementAuxiliary(N,sigma)
  aux=struct('total',[],'dm',[],'dst',[],'tolerance',[]);
  src='isolated test fixture; not main benchmark information';
  aux.total=struct('value',sum(N(:)),'sigma',sigma,'source',src);
  aux.dm=struct('value',sum(N,1)','sigma',sigma,'source',src);
  aux.dst=struct('value',sum(N,2),'sigma',sigma,'source',src);
 end

 function mustError(fun,label)
  caught=false;
  try,fun();catch,caught=true;end
  assert(caught,'revision:ExpectedInputRejection','Invalid input accepted: %s.',label);
 end
end
