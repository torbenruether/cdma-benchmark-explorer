function [x,info]=revision_pocs_slabs_polish(p,x,C,lo,hi)
% Bounded sparse convex QP for exactly the same POCS-CDMA projection.
% C rows have unit norm; this preserves all sets and the bin-mass metric.
info=struct('converged',false,'iterations',0,'exitflag',NaN, ...
 'infeasibleCertified',false,'status','quadprog unavailable', ...
 'algorithm','Sparse interior-point-convex minimum-norm projection');
if exist('quadprog','file')~=2,return;end
[memoryGuard,info.queueSeconds]=v6_heavy_qp_lock; %#ok<NASGU>
cap=160;if isfield(p.c,'pocsSlabQPIterations'),cap=p.c.pocsSlabQPIterations;end
eq=lo==hi;neq=~eq;A=[C(neq,:);-C(neq,:)];b=[hi(neq);-lo(neq)];
options=optimoptions('quadprog','Algorithm','interior-point-convex', ...
 'Display','off','MaxIterations',cap,'OptimalityTolerance',1e-12, ...
 'ConstraintTolerance',1e-12);
try
 [xx,~,flag,out,multipliers]=quadprog(speye(p.n),zeros(p.n,1), ...
  A,b,C(eq,:),lo(eq),zeros(p.n,1),[],max(x,0),options);
catch err
 info.status=['quadprog numerical exception: ' err.identifier];
 info.message=err.message;return;
end
info.exitflag=flag;info.iterations=out.iterations;info.message=out.message;
% flag=-2 is a solver diagnosis, not a physical infeasibility proof.
if isempty(xx)||any(~isfinite(xx))
 info.status='quadprog returned no finite candidate';return;
end
x=max(xx,0);u=zeros(size(C,1),1);q=nnz(neq);
u(neq)=multipliers.ineqlin(1:q)-multipliers.ineqlin(q+1:2*q);
u(eq)=multipliers.eqlin;
certificate=revision_pocs_certificate(x,C,lo,hi,u);info.certificate=certificate;
tol=p.c.tolerance;
info.converged=flag>0&&certificate.primalViolation<=1e-9&& ...
 certificate.relativeStationarity<=tol&&certificate.relativeDualGap>=-1e-9&& ...
 certificate.relativeDualGap<=tol;
info.status='QP optimum not independently certified';
if info.converged,info.status='QP primal and dual independently certified';end
info.tolerances=struct('optimality',1e-12,'constraint',1e-12, ...
 'maxIterations',cap,'independentCertificate',tol);
end
