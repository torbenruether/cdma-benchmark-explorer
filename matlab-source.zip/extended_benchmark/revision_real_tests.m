function revision_real_tests(group)
% Small real-grid regression tests on existing datasets, not new noise draws.
if nargin<1,group='pocs';end
c=extended_config;maxNumCompThreads(2);folder=fullfile(c.root,'test_outputs');rows=struct([]);
resultFolder=folder;if contains(group,'final'),resultFolder=fullfile(folder,'final');if ~exist(resultFolder,'dir'),mkdir(resultFolder);end;end
if startsWith(group,'pocs'),indices=[1 2 5];methods={'POCS-PSS','POCS-CDMA'};
else,indices=5;methods={'Twomey-Markowski','Tikhonov','Tikhonov-lsqlin','TV-2D','Lognormal-fit'};end
for idx=indices
 file=fullfile(folder,sprintf('ds%05d_problem.mat',idx));d=load(file);p=d.p;p.c=c;
 solutions=cell(size(methods));
 for mi=1:numel(methods)
  method=methods{mi};fprintf('Test %s | %s started\n',d.row.Dataset,method);
  saved=fullfile(resultFolder,sprintf('%s_%s.mat',char(d.row.Dataset),matlab.lang.makeValidName(method)));
  if exist(saved,'file')
   previous=load(saved);solutions{mi}=previous.s;rows=[rows;previous.q]; %#ok<AGROW>
   writetable(struct2table(rows,'AsArray',true),fullfile(resultFolder,[group '_real_metrics.csv']));continue;
  end
  baseline=[];if strcmp(method,'Tikhonov-lsqlin'),baseline=solutions{find(strcmp(methods,'Tikhonov'))};end
  timer=tic;
  try
   s=extended_solve(method,p,baseline);solutions{mi}=s;
   met=large_metrics(s.binCounts,d.truth,p.g,d.components,c.totalN);
   q=struct('Dataset',char(d.row.Dataset),'Method',method,'Success',true,'Converged',s.converged, ...
    'Seconds',toc(timer),'Iterations',s.iterations,'ReducedChi2',s.residual, ...
    'RelativeL2',met.RelativeL2,'Parameter',s.parameter,'Boundary',s.boundary,'Error','');
   save(saved,'s','q','-v7');
  catch err
   q=struct('Dataset',char(d.row.Dataset),'Method',method,'Success',false,'Converged',false, ...
    'Seconds',toc(timer),'Iterations',0,'ReducedChi2',NaN,'RelativeL2',NaN, ...
    'Parameter',NaN,'Boundary',false,'Error',err.message);
   fprintf('%s\n',getReport(err,'extended','hyperlinks','off'));
  end
  rows=[rows;q]; %#ok<AGROW>
  writetable(struct2table(rows,'AsArray',true),fullfile(resultFolder,[group '_real_metrics.csv']));
  fprintf('Test finished: converged %d, chi2 %.6g, error %.4g, %.1fs\n',q.Converged,q.ReducedChi2,q.RelativeL2,q.Seconds);
 end
end
save(fullfile(folder,[group '_real_results.mat']),'rows');
end
