function v6_test_suite
% Reproducible implementation checks before any factorial jobs are submitted.
c=extended_config;addpath(c.root,fullfile(c.root,'core'));maxNumCompThreads(1);
v6_noise_tests;
revision_constraint_tests;
test_revision_optimizers;
revision_gp_tgv_tests;
v6_pocs_tests;
v6_optimizer_tests;
v6_tv_tgv_tests;
result=struct('passed',true,'finished',datestr(now,31),'version',c.version, ...
 'scope','Small independent implementation fixtures; full-grid reconstruction quality is separate');
fid=fopen(fullfile(c.root,'V6_PREFLIGHT_PASS.json'),'w');fwrite(fid,jsonencode(result),'char');fclose(fid);
fprintf('PASS: all v6 preflight implementation suites completed.\n');
end
