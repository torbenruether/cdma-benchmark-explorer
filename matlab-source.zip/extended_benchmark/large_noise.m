function d=large_noise(clean,row,c)
% Absolute and relative random terms are INDEPENDENT, paired across solvers.
stream=RandStream('mt19937ar','Seed',row.Seed);
za=randn(stream,numel(clean),1); zr=randn(stream,numel(clean),1);
drift=row.Drift*(linspace(-.5,.5,numel(clean)))';
absolute=row.SigmaAbs*za; relative=row.Relative*clean.*zr;
raw=clean+row.Offset+absolute+relative+drift.*clean;
y=max(raw,0);
% No exact clean signal, offset or drift realization enters solver weights.
sigma=sqrt(row.SigmaAbs^2+(row.Relative*max(y,0)).^2);
if row.SigmaAbs==0 && row.Relative==0
    sigma=sqrt((c.noiselessRelative*max(y,0)).^2+(c.noiselessFloor*max(y))^2);
end
sigma=max(sigma,c.weightFloorCm3);
d=struct('y',y,'sigma',sigma,'raw',raw,'absoluteNoise',absolute, ...
    'relativeNoise',relative,'drift',drift,'clipped',raw<0, ...
    'actualSigma',sqrt(row.SigmaAbs^2+(row.Relative*clean).^2));
end
