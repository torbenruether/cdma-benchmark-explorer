function row=v7_record_control(dataset,method,s,p,d,seconds,description)
% Truth is consulted only after the solution was returned, for error metrics.
c=v7_config;folder=c.outputRoot;if ~exist(folder,'dir'),mkdir(folder);end
assert(all(isfinite(s.x))&&all(s.x>=-1e-10));
X=zeros(p.g.n);X(p.g.active)=max(s.x,0)*p.scale;
row=large_metrics(X,d.truth,p.g,d.components,c.totalN);
row.Dataset=string(dataset);row.Method=string(method);row.Seconds=seconds;
row.Iterations=s.iterations;row.ObjectiveConverged=s.converged;
row.WeightedResidual=norm(p.B*s.x-p.b)^2;
row.Description=string(description);row.Experimental=true;
row.DataCompatible=row.WeightedResidual<=(1-2/(9*p.m)+1.64485362695147*sqrt(2/(9*p.m)))^3*(1+1e-5);
row.ConstraintViolation=max([0;-s.x;p.auxLo-p.auxC*s.x;p.auxC*s.x-p.auxHi]);
row.Parameter=s.parameter;row.ParameterSelectionValid=false;
if isfield(s.diagnostics,'selectionValid'),row.ParameterSelectionValid=s.diagnostics.selectionValid;end
if strcmp(method,'POCS-CDMA-Dual')
 row.ParameterSelectionValid=true;row.DataCompatible=s.diagnostics.bandsSatisfied;
end
if strcmp(method,'TV-Morozov-PD')
 row.DataCompatible=sqrt(row.WeightedResidual)<=sqrt(p.target)+64*eps*max(1,sqrt(p.target));
end
row.Validated=row.ObjectiveConverged&&row.DataCompatible&&row.ParameterSelectionValid&&row.ConstraintViolation<=1e-9;
row.QualityTargetsPass=row.RelativeL2<=.2&&abs(row.TotalRelativeError)<=.05&& ...
 abs(row.GMD_dm_RelativeError)<=.05&&abs(row.GMD_dst_RelativeError)<=.05&& ...
 abs(row.GSD_dm_RelativeError)<=.05&&abs(row.GSD_dst_RelativeError)<=.05;
row.TargetPass=row.Validated&&row.QualityTargetsPass;
s.binCounts=X;
label=regexprep(method,'[^A-Za-z0-9]','_');
save(fullfile(folder,[dataset '_' label '.mat']),'s','row','description','-v7');
csv=fullfile(folder,[dataset '_' label '.csv']);writetable(struct2table(row),csv);
fprintf('V7 %s %s: objective%d data%d parameter%d L2%.4g %.1fs\n', ...
 dataset,method,row.ObjectiveConverged,row.DataCompatible,row.ParameterSelectionValid,row.RelativeL2,seconds);
end
