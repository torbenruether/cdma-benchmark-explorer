function rows=run_v7_solver_controls(methods,datasets)
% Separate bounded controls on stored data. V6 stays suspended and unchanged.
% Parameters for optimizer controls come from the stored DATA-ONLY path.
c=v7_config;if nargin<1,methods=c.addedMethods;end
if nargin<2,datasets=c.controlDatasets;end
assert(exist(c.outputRoot,'dir')==7||mkdir(c.outputRoot));
rows=struct([]);
for di=1:numel(datasets)
 dataset=datasets{di};[p,d]=v7_prepare_control(dataset);
 p.c.v7SmoothIterations=20;p.c.v7SmoothLSQRIterations=300;
 p.c.v7SmoothQRLimit=64;p.c.v7SmoothMaxSeconds=120;
 p.c.v7StrongIterations=20;p.c.v7StrongLSQRIterations=300;
 p.c.v7StrongQRLimit=64;p.c.v7StrongMaxSeconds=120;
 p.c.v7POCSDualWarmup=100;p.c.v7POCSDualNewtonIterations=100;
 p.c.v7POCSDualPCGIterations=100;p.c.v7POCSDualLBFGSIterations=0;
 p.c.v7POCSDualMaxSeconds=120;
 p.c.v7GraphMaxSeconds=120;p.c.pdIterations=6000;
 for mi=1:numel(methods)
  method=methods{mi};fprintf('\nCONTROL7 %s %s START %s\n',dataset,method,datestr(now,31));
  timer=tic;description='';
  try
   switch method
    case {'Tikhonov-Scaled','Tikhonov-LSQR-StrongPrecond'}
     idx=find(strcmp(string({d.rows.Method}),'Tikhonov'),1);
     assert(~isempty(idx),'A stored data-selected Tikhonov parameter is required.');
     alpha=d.rows(idx).Parameter;
     if strcmp(method,'Tikhonov-Scaled')
      [x,info]=v7_smooth_candidate(p,alpha,'Tikhonov',p.zero);
     else
      [x,info]=v7_strong_candidate(p,alpha,'Tikhonov',p.zero);
     end
     s=struct('x',x,'iterations',info.iterations,'converged',info.converged, ...
      'parameter',alpha,'boundary',false,'diagnostics',struct('selectedSolver',info, ...
      'selectionValid',d.rows(idx).ParameterSelectionValid,'targetBracketed',d.rows(idx).ParameterSelectionValid, ...
      'fixedDataSelectedParentAlpha',true),'selection','Optimizer control: identical stored data-only alpha, start zero');
     description='Same Tikhonov objective and stored measurement-only alpha; optimizer control, not a new regularizer.';
    case 'POCS-CDMA-Dual'
     s=v7_pocs_dual(p);
     description='Same nonnegative minimum bin-mass norm and simultaneous 95% CDMA bands; dual optimizer control.';
    case 'TV-PD'
     idx=find(strcmp(string({d.rows.Method}),'TV-2D'),1);
     assert(~isempty(idx),'A stored TV alpha is required for the optimizer control.');
     s=v7_tv_candidate(p,d.rows(idx).Parameter,p.zero,'penalized');
     s.diagnostics.selectionValid=d.rows(idx).ParameterSelectionValid;
     s.diagnostics.fixedDataSelectedParentAlpha=true;
     description='Same weighted-LS isotropic TV objective and stored data-only alpha; independent optimizer control, not a new regularizer.';
    case 'TV-Morozov-PD'
     s=v7_tv_solve(method,p);
     description='Minimize isotropic TV subject to declared weighted measurement-error radius and nonnegativity; distinct discrepancy formulation.';
    otherwise,error('Unknown experimental method %s',method);
   end
   seconds=toc(timer);row=v7_record_control(dataset,method,s,p,d,seconds,description);
   rows=[rows;row]; %#ok<AGROW>
  catch err
   failure=struct('dataset',dataset,'method',method,'message',getReport(err,'extended','hyperlinks','off'),'seconds',toc(timer));
   fprintf(2,'%s\n',failure.message);label=regexprep(method,'[^A-Za-z0-9]','_');
   save(fullfile(c.outputRoot,[dataset '_' label '_ERROR.mat']),'failure','-v7');
  end
 end
end
if ~isempty(rows),writetable(struct2table(rows),fullfile(c.outputRoot,'controls_latest.csv'));end
fprintf('V7 bounded controls finished. Original V6 benchmark remains paused.\n');
end
