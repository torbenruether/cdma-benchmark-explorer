function results=v7_pocs_tests()
% Isolated tests only. Root executes this; no factorial process or cache load.
root=fileparts(mfilename('fullpath'));addpath(root,fullfile(root,'core'));
c=struct('nBins',3,'rangeNm',[20 1000],'tolerance',2e-6, ...
 'v7POCSDualWarmup',150,'v7POCSDualNewtonIterations',350, ...
 'v7POCSDualPolishIterations',150,'v7POCSDualPCGIterations',500, ...
 'v7POCSDualLBFGSIterations',400);
c.aux=struct('total',[],'dm',[],'dst',[],'tolerance',[]);g=cdma_grid(c);n=numel(g.active);
tests={@analytic,@coupled,@duplicates,@zeroCompatible,@zeroIncompatible, ...
 @coupledAuxiliary,@inconsistentNotProof,@finiteBudget,@gradient};
names={'analytical_minimum_norm','coupled_dense_QP_crosscheck','duplicate_and_zero_rows', ...
 'compatible_zero_operator','incompatible_zero_row_proof','simultaneous_total_and_marginals', ...
 'inconsistent_iteration_limit_not_false_proof','finite_budget_honest_status','analytic_dual_gradient'};
results=struct('name',{},'passed',{},'seconds',{},'message',{});
for k=1:numel(tests)
 timer=tic;try,tests{k}();passed=true;message='PASS';
 catch err,passed=false;message=[err.identifier ': ' err.message];end
 results(k)=struct('name',names{k},'passed',passed,'seconds',toc(timer),'message',message); %#ok<AGROW>
 fprintf('%s: %s (%.3fs)\n',names{k},message,results(k).seconds);
end
save(fullfile(root,'v7_pocs_test_results.mat'),'results');
writetable(struct2table(results),fullfile(root,'v7_pocs_test_results.csv'));
assert(all([results.passed]),'v7:POCSTestsFailed','%d of %d dual POCS tests failed.',sum(~[results.passed]),numel(tests));

 function analytic()
  known=[.1;3;5;1;7;.2];p=problem(eye(n),known);s=v7_pocs_dual(p);
  width=sqrt(2)*erfcinv(.05/n)/sqrt(n);expected=max(known-width,0);
  check(s,p);assert(norm(s.x-expected)/max(1,norm(expected))<5e-6,'Analytical solution differs.');
  full=zeros(g.n);full(g.active)=s.x;
  assert(all(full(~g.allowed)==0),'Physical support escaped.');compareQP(s,p);
 end

 function coupled()
  B=[1 .4 .2 .5 .3 .1;.2 1 .5 .1 .4 .6;.6 .3 1 .4 .2 .7];
  p=problem(B,[1;3;2;4;5;2]);s=v7_pocs_dual(p);check(s,p);compareQP(s,p);
 end

 function duplicates()
  B=[1 .2 .4 .3 .6 .1;1 .2 .4 .3 .6 .1;zeros(1,n);.2 .7 .1 1 .3 .5];
  p=problem(B,(1:n)');s=v7_pocs_dual(p);check(s,p);compareQP(s,p);
  assert(~s.diagnostics.infeasibleCertified,'Duplicate rows declared infeasible.');
 end

 function zeroCompatible()
  p=problem(zeros(3,n),ones(n,1));s=v7_pocs_dual(p);
  check(s,p);assert(all(s.x==0),'Compatible zero kernel needs zero solution.');
 end

 function zeroIncompatible()
  p=problem(zeros(2,n),ones(n,1));p.b(1)=10;s=v7_pocs_dual(p);
  assert(~s.converged&&s.diagnostics.infeasibleCertified,'Exact zero-row contradiction not certified.');
  assert(all(isfinite(s.x)),'Contradiction produced nonfinite solution.');
 end

 function coupledAuxiliary()
  p=problem(eye(n),(1:n)');N=zeros(g.n);N(g.active)=p.b;
  src='independently generated isolated fixture, not benchmark truth input';
  aux=struct('total',struct('value',sum(N(:)),'sigma',0,'source',src), ...
   'dm',struct('value',sum(N,1)','sigma',0,'source',src), ...
   'dst',struct('value',sum(N,2),'sigma',0,'source',src),'tolerance',[]);
  [p.auxC,p.auxLo,p.auxHi]=extended_constraints(g,aux,1);
  s=v7_pocs_dual(p);check(s,p);compareQP(s,p);
  F=zeros(g.n);F(g.active)=s.x;
  assert(norm(sum(F,1)'-sum(N,1)',inf)<1e-8&&norm(sum(F,2)-sum(N,2),inf)<1e-8, ...
   'Axes or simultaneous marginals wrong.');
 end

 function inconsistentNotProof()
  p=problem([ones(1,n);ones(1,n)],ones(n,1));p.b=[1;10];
  p.c.v7POCSDualWarmup=5;p.c.v7POCSDualNewtonIterations=5;
  p.c.v7POCSDualLBFGSIterations=0;s=v7_pocs_dual(p);
  assert(~s.converged&&~s.diagnostics.infeasibleCertified, ...
   'Numerical stopping was used as an unimplemented mathematical infeasibility certificate.');
  assert(all(isfinite(s.x))&&all(s.x>=0),'Inconsistent diagnostic returned invalid x.');
 end

 function finiteBudget()
  p=problem([1 .4 .2 .5 .3 .1;.2 1 .5 .1 .4 .6],(1:n)');
  p.c.v7POCSDualWarmup=0;p.c.v7POCSDualNewtonIterations=1;p.c.v7POCSDualLBFGSIterations=0;
  s=v7_pocs_dual(p);assert(~s.diagnostics.infeasibleCertified,'Tiny budget proved false infeasibility.');
  if s.converged,check(s,p);end
  p.c.v7POCSDualMaxSeconds=0;s=v7_pocs_dual(p);
  assert(s.diagnostics.budgetStopped&&~s.converged&&~s.diagnostics.infeasibleCertified, ...
   'Immediate time-budget stop was not recorded honestly.');
 end

 function gradient()
  C=[1 .4 .2;.2 1 .5];lo=[1;2];hi=[2;3];w=[.2;.1;2;3];
  [~,grad]=v7_pocs_objective(w,C,lo,hi);fd=zeros(4,1);h=1e-6;
  for j=1:4,e=zeros(4,1);e(j)=h;fd(j)=(v7_pocs_objective(w+e,C,lo,hi)-v7_pocs_objective(w-e,C,lo,hi))/(2*h);end
  assert(norm(grad-fd)/max(1,norm(grad))<1e-7,'Dual gradient sign/index incorrect.');
 end

 function p=problem(B,known)
  p=struct('B',sparse(B),'b',B*known,'m',size(B,1),'n',n,'zero',zeros(n,1), ...
   'c',c,'g',g,'scale',1,'auxC',sparse(0,n),'auxLo',[],'auxHi',[]);
 end

 function check(s,p)
  if ~s.converged,disp(s.diagnostics);end
  assert(s.converged,'Dual optimizer did not independently certify known feasible test.');
  assert(s.diagnostics.bandsSatisfied&&s.diagnostics.auxiliaryConstraintViolation<=1e-9,'Original constraints violated.');
  assert(s.diagnostics.certificate.relativeDualGap<=c.tolerance&& ...
   s.diagnostics.certificate.relativeBoundKKT<=c.tolerance,'Gap/KKT certificate failed.');
  assert(all(isfinite(s.x))&&all(s.x>=0),'Nonfinite or negative concentrations.');
  fprintf('  dual: chi2 %.6g, gap %.3g, KKT %.3g, maxZ %.6g, it%d\n', ...
   norm(p.B*s.x-p.b)^2,s.diagnostics.certificate.relativeDualGap, ...
   s.diagnostics.certificate.relativeBoundKKT,s.diagnostics.maxStandardizedResidual,s.iterations);
 end

 function compareQP(s,p)
  assert(exist('quadprog','file')==2,'Dense reference needs Optimization Toolbox quadprog.');
  width=sqrt(2)*erfcinv(.05/p.m)/sqrt(p.m);
  C=[p.B;p.auxC];lo=[p.b-width;p.auxLo];hi=[p.b+width;p.auxHi];
  zero=~any(C~=0,2);C=C(~zero,:);lo=lo(~zero);hi=hi(~zero);eq=lo==hi;
  opts=optimoptions('quadprog','Algorithm','interior-point-convex','Display','off', ...
   'MaxIterations',300,'OptimalityTolerance',1e-12,'ConstraintTolerance',1e-12);
  [xq,~,flag]=quadprog(eye(n),zeros(n,1),full([C(~eq,:);-C(~eq,:)]), ...
   [hi(~eq);-lo(~eq)],full(C(eq,:)),lo(eq),zeros(n,1),[],[],opts);
  assert(flag>0,'Dense reference QP did not solve.');
  discrepancy=norm(s.x-xq)/max(1,norm(xq));
  fprintf('  dense-QP difference %.3g\n',discrepancy);
  assert(discrepancy<1e-5,'Dual result differs from same unique primal norm projector.');
 end
end
