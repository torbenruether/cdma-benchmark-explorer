function apply=large_gp_kernel(g,lengthScale)
% Exact stationary Matern-3/2 product by zero-padded 2D convolution.
% Uses log-bin centres; half-area diagonal cells are scaled consistently.
n=g.n;u=[0:n -n+1:-1]/n;[U,V]=meshgrid(u,u);
r=sqrt(3)*sqrt(U.^2+V.^2)/lengthScale;
F=fft2((1+r).*exp(-r));a=g.area(g.active)/g.h(1)^2;
apply=@multiply;
    function Y=multiply(X)
        Y=zeros(size(X));
        for first=1:16:size(X,2)
            cols=first:min(first+15,size(X,2)); z=a.*X(:,cols);
            Z=zeros(n*n,numel(cols));Z(g.active,:)=z;Z=reshape(Z,n,n,[]);
            C=real(ifft2(fft2(Z,2*n,2*n).*F));C=reshape(C(1:n,1:n,:),n*n,[]);
            Y(:,cols)=a.*(C(g.active,:)+1e4*sum(z,1)+1e-8*z);
        end
    end
end
