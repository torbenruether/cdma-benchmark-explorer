function y=v7_graph_dualprox(p,t,v,sigma,alpha,formulation)
% Exact conjugate proximal maps in the fixed diagonal metric.
y=v;
if strcmp(formulation,'quadratic')
 y(t.data)=(v(t.data)-sigma(t.data).*p.b)./(1+sigma(t.data));
else
 y(t.data)=v7_graph_normprox(v(t.data)-sigma(t.data).*p.b, ...
  sigma(t.data),sqrt(p.target));
end
q=reshape(v(t.reg),t.n,2);magnitudes=hypot(q(:,1),q(:,2));
q=q./max(1,magnitudes/max(alpha,realmin));y(t.reg)=q(:);
if ~isempty(t.slabs)
 z=v(t.slabs)./sigma(t.slabs);
 y(t.slabs)=v(t.slabs)-sigma(t.slabs).*min(max(z,t.lo),t.hi);
end
end
