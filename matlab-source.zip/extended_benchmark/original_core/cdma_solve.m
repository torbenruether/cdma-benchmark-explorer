function s = cdma_solve(method,p)
% The six PSS regularizers, adapted to 2D cell concentrations, plus CDMA
% historical POCS and one additional regularizer (isotropic TV).
t=tic; s=struct('x',[],'iterations',0,'converged',false,'parameter',NaN, ...
    'selection','none','boundary',false,'residual',NaN,'diagnostics',struct);
switch method
    case {'Tikhonov','Maximum Entropy','Huber-TV','TV-2D'}
        if strcmp(method,'TV-2D'), p.tv=large_tv_setup(p); end
        s=regularizationPath(method,p,s);
    case 'Twomey-Markowski'
        s=twomey(p,s);
    case 'Bayesian GP-MAP'
        s=bayes(p,s);
    case 'POCS-PSS'
        s=pocsPss(p,s);
    case 'POCS-CDMA'
        s=pocsLegacy(p,s);
    otherwise, error('Unknown method');
end
s.residual=norm(p.B*s.x-p.b)^2;
s.seconds=toc(t); s.binCounts=zeros(p.g.n); s.binCounts(p.g.active)=s.x*p.scale;
assert(all(s.binCounts(~p.g.allowed)==0),'Physical support violated');
assert(all(isfinite(s.x)) && all(s.x>=-1e-10),'Invalid solution');
end

function s=regularizationPath(method,p,s)
if strcmp(method,'Tikhonov'), scale=p.lip;
elseif strcmp(method,'Maximum Entropy'), scale=p.lip/p.n;
elseif strcmp(method,'Huber-TV'), scale=p.lip*0.03/p.n;
else, scale=sqrt(p.lip)/max(sqrt(norm([p.Ga;p.Gm],1)*norm([p.Ga;p.Gm],inf)),eps); end
params=scale*p.c.pathMultipliers;
xs={}; infos={}; residual=[]; total=0; x=p.zero;
for k=1:numel(params)
    if params(k)==0
        [x,infok]=quadratic(@(z)qmul(p,z),p.rhs,x,p.c,p.lip);
    elseif strcmp(method,'Tikhonov')
        [x,infok]=quadratic(@(z)qmul(p,z)+params(k)*(p.R*z),p.rhs,x,p.c,p.lip+params(k)*norm(p.R,inf));
    elseif strcmp(method,'TV-2D')
        [x,infok]=tv(p,params(k),x);
    elseif strcmp(method,'Maximum Entropy')
        [x,infok]=entropyNewton(p,params(k),x);
    else
        [x,infok]=smoothSolve(p,params(k),method,x);
    end
    xs{k}=x; infos{k}=infok; residual(k)=norm(p.B*x-p.b)^2; total=total+infok.iterations;
    % Once bracketed, continue one candidate beyond the crossing.
    if k>2 && residual(k-1)>1 && residual(k)>1, break; end
end
params=params(1:numel(residual));
eligible=1:numel(residual); % Never silently turn a TV arm into NNLS by discarding its path.
[~,j]=min(abs(log(max(residual(eligible),realmin)))); j=eligible(j);
s.x=xs{j}; s.converged=infos{j}.converged; s.iterations=total;
s.parameter=params(j); s.boundary=(j==numel(params) || j==1);
s.selection='Morozov';
s.diagnostics=struct('parameters',params,'residuals',residual,'selectedIndex',j, ...
    'candidateConverged',cellfun(@(v)v.converged,infos), ...
    'selectedSolver',infos{j},'targetBracketed',min(residual)<=1 && max(residual)>=1);
end

function [x,info]=entropyNewton(p,alpha,x)
floorX=1e-14;x=max(x,floorX);converged=false;
for k=1:150
    total=sum(x);logr=log(x./(p.priorMass*total));grad=qmul(p,x)-p.rhs+alpha*logr;
    free=x>floorX*1.01 | grad<0;pg=grad;pg(~free)=0;
    kkt=norm(pg,inf)/max(1,norm(p.rhs,inf));
    if kkt<p.c.tolerance,converged=true;break;end
    damp=1e-12*max(1,p.lip);
    h=@(v)free.*(qmul(p,free.*v)+alpha*(free.*v./x-sum(free.*v)/total)+damp*(free.*v))+(~free).*v;
    diagH=max(p.diagQ+alpha*(1./x-1/total)+damp,eps);diagH(~free)=1;
    [direction,flag]=pcg(h,-pg,1e-3,200,@(z)z./diagH);
    if flag>1 || grad'*direction>=0,direction=-pg./diagH;end
    step=1;ix=direction<0;
    if any(ix),step=min(step,.99*min((x(ix)-floorX)./(-direction(ix))));end
    step=max(step,1e-8);f=.5*norm(p.B*x)^2-p.rhs'*x+alpha*sum(x.*logr);
    for ls=1:50
        z=max(x+step*direction,floorX);
        fz=.5*norm(p.B*z)^2-p.rhs'*z+alpha*sum(z.*log(z./(p.priorMass*sum(z))));
        if fz<=f+1e-4*grad'*(z-x)+1e-13*max(1,abs(f)),break;end
        step=step/2;
    end
    x=z;
end
info=struct('iterations',k,'converged',converged,'kkt',kkt,'algorithm','Newton-PCG');
end

function [x,info]=quadratic(H,r,x,c,L)
% Monotone accelerated projected gradient; scale-free projected KKT check.
L=max(L,eps);
y=x; a=1; old=0.5*x'*H(x)-r'*x; converged=false;
for k=1:c.maxIterations
    z=max(y-(H(y)-r)/L,0); f=0.5*z'*H(z)-r'*z;
    if f>old+1e-12*max(1,abs(old))
        y=x; a=1; z=max(y-(H(y)-r)/L,0); f=0.5*z'*H(z)-r'*z;
    end
    if mod(k,20)==0
        grad=H(z)-r; pg=grad; pg(z<=1e-12 & grad>0)=0;
        kkt=norm(pg,inf)/max(1,norm(r,inf));
        if kkt<c.tolerance, x=z; converged=true; break; end
    end
    an=(1+sqrt(1+4*a*a))/2; y=z+(a-1)/an*(z-x); x=z; a=an; old=f;
end
grad=H(x)-r; pg=grad; pg(x<=1e-12 & grad>0)=0;
info=struct('iterations',k,'converged',converged, ...
    'kkt',norm(pg,inf)/max(1,norm(r,inf)));
end

function [x,info]=smoothSolve(p,alpha,method,x)
% Projected spectral gradient with Armijo search for the convex objectives.
floorX=0; if strcmp(method,'Maximum Entropy'), floorX=1e-13; end
x=max(x,floorX); step=1/max(p.lip,eps); converged=false;
[f,grad]=objective(x);
for k=1:p.c.maxIterations
    dir=max(x-step*grad,floorX)-x; slope=grad'*dir;
    eta=1;
    for ls=1:45
        z=x+eta*dir; [fz,gz]=objective(z);
        if fz<=f+1e-4*eta*slope+1e-13*max(1,abs(f)), break; end
        eta=eta/2;
    end
    dx=z-x; dg=gz-grad;
    step=min(1e8/max(p.lip,eps),max(1e-10/max(p.lip,eps),dot(dx,dx)/max(dot(dx,dg),realmin)));
    x=z; f=fz; grad=gz;
    pg=grad; pg(x<=floorX*1.01+1e-14 & grad>0)=0;
    kkt=norm(pg,inf)/max(1,norm(p.rhs,inf));
    if kkt<p.c.tolerance, converged=true; break; end
end
info=struct('iterations',k,'converged',converged,'kkt',kkt);
    function [v,h]=objective(z)
        v=0.5*norm(p.B*z)^2-p.rhs'*z; h=qmul(p,z)-p.rhs;
        if strcmp(method,'Maximum Entropy')
            u=max(z,1e-14); total=sum(u); logratio=log(u*p.n/total);
            v=v+alpha*sum(u.*logratio); h=h+alpha*logratio;
        else
            delta=0.03/p.n; dz=p.D*z; root=sqrt(1+(dz/delta).^2);
            % Same pseudo-Huber definition as PSS, with both 2D directions.
            v=v+alpha*sum(delta^2*(root-1));
            h=h+alpha*(p.D'*(dz./root));
        end
    end
end

function s=twomey(p,s)
x=p.zero; step=1.8/p.lip; reached=false;
for k=1:p.c.maxIterations
    x=max(x+step*(p.rhs-qmul(p,x)),0);
    if norm(p.B*x-p.b)^2<=1, reached=true; break; end
end
fallback=false;
if ~reached
    [x,info]=quadratic(@(z)qmul(p,z),p.rhs,x,p.c,p.lip); k=k+info.iterations;
    reached=norm(p.B*x-p.b)^2<=1; fallback=true;
end
% Graph diffusion preserves total concentration; no row-wrap neighbours.
D=p.g.D; S=speye(p.n)-0.2*p.g.h(1)^2*(D'*D)*p.g.densityScale;
passes=0;
if reached
    for j=1:200
        z=S*x;
        if norm(p.B*z-p.b)^2>1
            lo=0; hi=1;
            for l=1:35
                mid=(lo+hi)/2;
                if norm(p.B*(x+mid*(z-x))-p.b)^2<=1, lo=mid; else, hi=mid; end
            end
            x=x+lo*(z-x); break;
        end
        x=z; passes=j;
    end
end
s.x=max(x,0); s.iterations=k+passes; s.converged=reached;
s.parameter=k; s.selection='discrepancy stopping and conservative 2D smoothing';
s.diagnostics=struct('dataFitFallback',fallback,'smoothingPasses',passes);
end

function s=bayes(p,s)
s=large_gp(p,s);
end

function s=pocsPss(p,s)
limit=(1-2/(9*p.m)+1.64485362695147*sqrt(2/(9*p.m)))^3;
U=p.V;ev=p.e;null=ev<=max(p.lip,eps)*1e-13;
ub=U'*p.b;perp=sum(ub(null).^2);
x=p.zero;corr1=x;corr2=x;converged=false;
if perp>limit*(1+1e-8)
    [x,info]=quadratic(@(z)qmul(p,z),p.rhs,x,p.c,p.lip);k=info.iterations;
else
    for k=1:p.c.pocsIterations
        previous=x;v=x+corr1;res=p.B*v-p.b;ur=U'*res;
        if norm(res)^2>limit
            lo=0;hi=1;
            while sum((ur./(1+hi*ev)).^2)>limit && hi<1e20,hi=hi*10;end
            for j=1:50
                mid=(lo+hi)/2;
                if sum((ur./(1+mid*ev)).^2)>limit,lo=mid;else,hi=mid;end
            end
            z=v-p.B'*(U*((hi./(1+hi*ev)).*ur));
        else,z=v;end
        corr1=v-z;v=z+corr2;x=max(v,0);corr2=v-x;
        if norm(p.B*x-p.b)^2<=limit*(1+1e-5) && norm(x-previous)/max(1,norm(x))<p.c.tolerance
            converged=true;break;
        end
    end
end
s.x=x;s.iterations=k;s.converged=converged;s.parameter=limit*p.m;
s.selection='95% chi-square set; nonnegative policy';
s.diagnostics=struct('limit',limit,'unconstrainedMinimumResidual',perp,'feasible',norm(p.B*x-p.b)^2<=limit*(1+1e-5));
end

function s=pocsLegacy(p,s)
% Historical CDMA heuristic, adapted to named axes and bin concentrations.
% Marginals come ONLY from measured pure-DMA/pure-centrifugal slices.
n=p.g.n;
% Unlike true-dae coordinates, the pure centrifugal scan depends on dm via Cc.
% No separable 1D dst marginal exists. Use a joint nonnegative data-only pilot.
% Its marginals are a recycled-data heuristic, not independent measurements.
[pilot,pilotInfo]=quadratic(@(z)qmul(p,z),p.rhs,p.zero,p.c,p.lip);pilotExitflag=double(pilotInfo.converged); joint=zeros(n); joint(p.g.active)=pilot;
ma=sum(joint,2); mm=sum(joint,1)'; N=sum(pilot);
x=ma*mm'/max(N,eps); x(~p.g.allowed)=0;
if sum(x(:))>0, x=x*N/sum(x(:)); end
weight=(ma/max(max(ma),eps))*(mm/max(max(mm),eps))';
A=p.fullA; y=p.y/p.scale; band=(max(y)/50+y/500);
rowNorm=full(sum(A.^2,2)); logArea=(p.g.h(1)/log(10))^2;
errA=max(ma)+ma/10; errM=max(mm)+mm/10; converged=false;
for k=1:p.c.legacyIterations
    old=x;
    % Same one-percent support and broad marginal tolerances as original.
    for j=1:n
        if ma(j)<max(ma)/100, x(j,:)=0;
        else
            delta=ma(j)-sum(x(j,:)); excess=sign(delta)*max(abs(delta)-errA(j),0);
            support=(mm'>0) & p.g.allowed(j,:); x(j,:)=x(j,:)+excess*support/max(sum(support),1);
        end
    end
    for j=1:n
        if mm(j)<max(mm)/100, x(:,j)=0;
        else
            delta=mm(j)-sum(x(:,j)); excess=sign(delta)*max(abs(delta)-errM(j),0);
            support=(ma>0) & p.g.allowed(:,j); x(:,j)=x(:,j)+excess*support/max(sum(support),1);
        end
    end
    x(~p.g.allowed)=0; x(x<max(x(:))/1e4)=0; support=x>0; v=x(:);
    for r=1:p.m
        pred=A(r,:)*v; delta=y(r)-pred;
        if abs(delta)>band(r) && y(r)>0 && rowNorm(r)>0
            excess=delta-sign(delta)*band(r);
            v=v+excess*full(A(r,:))'.*support(:).*weight(:)*logArea/rowNorm(r);
            v(v<max(v)/1e4)=0;
            if sum(v)>0, v=v*N/sum(v); end
        end
    end
    x=reshape(v,n,n);
    feasible=all(abs(A*v-y)<=band+1e-10);
    if norm(x(:)-old(:))/max(1,norm(x(:)))<p.c.tolerance
        converged=feasible; break;
    end
end
s.x=x(p.g.active); s.converged=converged && pilotExitflag>0; s.iterations=k; s.parameter=NaN;
s.selection='historical CDMA bands; joint NNLS pilot marginals';
s.diagnostics=struct('estimatedTotal',N*p.scale,'marginalDm',mm*p.scale, ...
    'marginalDst',ma*p.scale,'bandsSatisfied',feasible,'pilotExitflag',pilotExitflag, ...
    'legacyNote','Adapted heuristic: NNLS pilot marginals reuse same data; no independent marginal information');
end

function [x,info]=tv(p,alpha,x)
% Same isotropic-TV ADMM objective; sparse/measurement-space Woodbury solves.
Ga=p.Ga;Gm=p.Gm;rho=max(sqrt(p.lip),1);
za=Ga*x;zm=Gm*x;w=max(x,0);ua=zeros(p.n,1);um=ua;uw=ua;converged=false;
for k=1:min(p.c.tvIterations,4000)
    oz=za;om=zm;ow=w;
    rhs=p.rhs+rho*(Ga'*(za-ua)+Gm'*(zm-um)+w-uw);
    v=p.tv.solveR(rhs);
    x=v/rho-p.tv.V*((p.tv.V'*rhs)./(rho*(rho+p.tv.ev)));
    ax=Ga*x;mx=Gm*x;va=ax+ua;vm=mx+um;
    shrink=max(0,1-alpha./max(rho*sqrt(va.^2+vm.^2),realmin));
    za=shrink.*va;zm=shrink.*vm;w=max(x+uw,0);
    ua=ua+ax-za;um=um+mx-zm;uw=uw+x-w;
    primal=norm([ax-za;mx-zm;x-w])/max(1,norm([ax;mx;x]));
    dual=rho*norm(Ga'*(za-oz)+Gm'*(zm-om)+w-ow)/max(1,norm(p.rhs));
    if max(primal,dual)<p.c.tolerance,converged=true;break;end
    if mod(k,50)==0
        oldrho=rho;if primal>10*dual,rho=rho*2;elseif dual>10*primal,rho=rho/2;end
        if rho~=oldrho,ua=ua*oldrho/rho;um=um*oldrho/rho;uw=uw*oldrho/rho;end
    end
end
x=w;info=struct('iterations',k,'converged',converged,'primalResidual',primal,'dualResidual',dual,'algorithm','ADMM, sparse Woodbury');
end
function v=qmul(p,x)
v=p.B'*(p.B*x);
end
