function c=v7_config
% Separate exploratory revision. Does not resume the paused v6 benchmark.
c=extended_config;
c.version='7.0-experimental-solvers';
c.outputRoot=fullfile(c.root,'outputs','solver_controls');
c.notify=false;c.workers=1;c.threadsPerWorker=2;
c.parentSource=fullfile(fileparts(c.root),'solver_revision_v6');
c.parentResults=fullfile(c.parentSource,'outputs','factorial27_1224');
c.addedMethods={'Tikhonov-Scaled','Tikhonov-LSQR-StrongPrecond','POCS-CDMA-Dual','TV-PD','TV-Morozov-PD'};
c.methods=unique([c.methods c.addedMethods],'stable');
c.experimental=true;
c.controlDatasets={'ds00005','ds00002'};
c.controlPurpose='Bounded saved-data controls; one mixed-noise and one relative-only case. Not a factorial benchmark.';
end
