function d=extended_noise(mu,relative,absoluteFraction,seed,c)
% Absolute sigma is calibration input relative to clean peak, as requested.
% No clean distribution is used for hyperparameter selection or fitting weights.
% Signed measurements preserve the declared additive Gaussian error model.
st=RandStream('mt19937ar','Seed',seed);
za=randn(st,numel(mu),1);zr=randn(st,numel(mu),1);
sa=absoluteFraction*max(mu);a=sa*za;r=relative*mu.*zr;
raw=mu+a+r;y=raw;if c.clipNegative,y=max(y,0);end
sigma=hypot(sa,relative*max(y,0));
if relative==0 && absoluteFraction==0
 sigma=hypot(c.noiselessRelative*y,c.noiselessFloor*max(y));
end
d=struct('y',y,'raw',raw,'sigma',max(sigma,c.weightFloorCm3), ...
 'actualSigma',hypot(sa,relative*mu),'absoluteNoise',a,'relativeNoise',r, ...
 'clipped',c.clipNegative & raw<0,'negativeRaw',raw<0,'sigmaAbs',sa,'absoluteFraction',absoluteFraction, ...
 'relativeFraction',relative,'seed',seed,'poissonEnabled',false);
end
