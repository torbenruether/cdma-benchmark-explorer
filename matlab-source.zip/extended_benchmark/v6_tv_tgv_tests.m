function v6_tv_tgv_tests()
% Small analytical/reference fixtures only. Root executes; no process launch.
maxNumCompThreads(1);c=extended_config;c.nBins=3;c.rangeNm=[20 1000];
c.tvIterations=12000;c.tgvIterations=12000;c.tgvRatio=2;
g=cdma_grid(c);n=numel(g.active);A=sparse(1:n,g.active,1,n,g.n^2);
y=[1;4;2;6;3;5];p=cdma_prepare(A,y,ones(n,1),g,c,table);p.auxC=sparse(0,n);p.auxLo=[];p.auxHi=[];
rows=struct([]);
for order=1:2
 t=v6_graph_setup(p,order);alpha=.07;[x,info,state]=v6_graph_candidate(p,t,alpha,[],12000);
 assert(all(x>=0)&&all(isfinite(x)));assert(info.converged,'Strict graph ADMM fixture failed');
 % Independent dense epigraph formulation, solved using fmincon SQP.
 % The ADMM state is used only as a feasible starting point, not in objective.
 nv=t.nvar;nr=n*numel(t.widths);u0=state.u;u0(1:n)=x;reg=t.Dreg*u0;
 b0=zeros(nr,1);offset=0;
 for j=1:numel(t.widths)
  a=reshape(reg(offset+(1:n*t.widths(j))),n,t.widths(j));b0((j-1)*n+(1:n))=sqrt(sum(a.^2,2));offset=offset+numel(a);
 end
 initial=[u0;b0+1e-8];coeff=kron(t.coefficients(:),t.weights);
 o=optimoptions('fmincon','Algorithm','sqp','Display','off','OptimalityTolerance',1e-10,'ConstraintTolerance',1e-10,'MaxIterations',1000);
 lb=[zeros(n,1);-Inf(nv-n,1);zeros(nr,1)];
 [reference,fref,flag]=fmincon(@obj,initial,[],[],[],[],lb,[],@constraints,o);
 relativeObjective=abs(info.objective-fref)/max(1,abs(fref));
 assert(flag>0&&relativeObjective<5e-5,'Independent epigraph reference failed');
 % A stopped short solve must never be relabelled converged because it fits.
 [~,short]=v6_graph_candidate(p,t,alpha,[],1);assert(~short.converged);
 q=struct('order',order,'converged',info.converged,'objectiveDifference',relativeObjective,'kkt',info.kkt, ...
  'gap',info.complementarityGap,'iterations',info.iterations);rows=[rows;q]; %#ok<AGROW>
 fprintf('PASS order%d: independent epigraph objective %.3g, KKT %.3g, gap %.3g, iterations%d\n',order,relativeObjective,info.kkt,info.complementarityGap,info.iterations);
end
save(fullfile(fileparts(mfilename('fullpath')),'v6_tv_tgv_tests.mat'),'rows');
 function f=obj(v)
  r=t.B*v(1:nv)-p.b;f=.5*(r'*r)+alpha*coeff'*v(nv+1:end);
 end
 function [ineq,equality]=constraints(v)
  reg=t.Dreg*v(1:nv);ineq=zeros(nr,1);offset=0;
  for jj=1:numel(t.widths)
   aa=reshape(reg(offset+(1:n*t.widths(jj))),n,t.widths(jj));
   ineq((jj-1)*n+(1:n))=sqrt(sum(aa.^2,2))-v(nv+(jj-1)*n+(1:n));offset=offset+numel(aa);
  end
  equality=[];
 end
end
