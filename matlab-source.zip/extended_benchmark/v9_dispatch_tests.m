function v9_dispatch_tests
% Actual central dispatch, including same-alpha independent optimizer arm.
c=extended_config;c.nBins=3;c.rangeNm=[20 1000];c.revisionTrace=false;
c.pathMultipliers=[0 1e-4 .01 .1 1 10 1000];
g=cdma_grid(c);n=numel(g.active);A=sparse(n,g.n*g.n);A(:,g.active)=speye(n);
p=cdma_prepare(A,[1;5;2;9;3;11],ones(n,1),g,c,zeros(n,2));
s=extended_solve('Tikhonov',p);
assert(s.converged && s.diagnostics.v9StrictCertificate.converged,'Main dispatch lost its strict certificate');
q=extended_solve('Tikhonov-lsqlin',p,s);
save(fullfile(c.root,'v9_dispatch_moderate_diagnostics.mat'),'s','q','p');
fprintf('lsqlin dispatch diagnostics: rawKKT %.4g, dualgap %.4g, dualfallback %d, convergence %d.\n', ...
 q.diagnostics.kkt,q.diagnostics.v9StrictCertificate.relativeGap,q.diagnostics.v9StrictCertificate.certificateFallback,q.converged);
assert(~q.converged || q.diagnostics.v9StrictCertificate.converged,'Independent lsqlin arm bypassed strict certificate');
assert(q.parameter==s.parameter && q.parameterSelectionValid==s.parameterSelectionValid);
assert(norm(q.x-s.x)/max(1,norm(s.x))<1e-4,'Same-objective optimizer arms disagree');
r=extended_solve('POCS-CDMA',p);
assert(r.converged && r.dataCompatible && r.benchmarkValid);
assert(all(r.binCounts(~g.allowed)==0),'Dispatch reconstructed forbidden support');
fprintf('PASS v9 central dispatch: main Tikhonov, strict same-alpha lsqlin and POCS-CDMA certificates.\n');
end
