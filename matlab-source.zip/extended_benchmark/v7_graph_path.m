function s=v7_graph_path(p)
% Bounded, data-only Morozov search. An uncertified alpha never brackets.
t=v7_graph_setup(p);ratios=p.c.pathMultipliers;ratios=ratios(ratios>0);
scale=max(norm(p.B'*p.b,inf),eps)/max(norm([p.Ga;p.Gm],1),eps);
if isempty(ratios),ratios=logspace(-6,4,17);end
alpha=scale*ratios(1);params=[];res=[];xs={};infos={};states={};total=0;
candidateLimit=12;refinements=4;pathCap=min(t.cap,2500);
if isfield(p.c,'pdMaxCandidates'),candidateLimit=p.c.pdMaxCandidates;end
if isfield(p.c,'graphMaxCandidates'),candidateLimit=p.c.graphMaxCandidates;refinements=0;end
if isfield(p.c,'pdPathIterations'),pathCap=min(t.cap,p.c.pdPathIterations);end
% Pilot candidates locate the direction; only polished candidates certify.
for attempt=1:candidateLimit
 state=[];
 if ~isempty(params),[~,near]=min(abs(log(params/alpha)));state=states{near};end
 [x,info,state]=v7_graph_candidate(p,t,alpha,state,pathCap);append(alpha,x,info,state);
 if numel(res)>1&&min(res)<=p.target&&max(res)>=p.target,break;end
 if res(end)>p.target,alpha=alpha/10;else,alpha=alpha*10;end
 if any(abs(log(params/alpha))<1e-8)
  if min(res)>p.target,alpha=min(params)/10;else,alpha=max(params)*10;end
 end
end
below=find(res<=p.target);above=find(res>p.target);
if isempty(below)||isempty(above),[~,j]=min(abs(log(max(res,realmin)/p.target)));anchors=j;
else,[~,j]=max(params(below));[~,k]=min(params(above));anchors=[below(j),above(k)];end
for j=anchors,polish(j);end
for fine=1:refinements
 [ib,ia]=bracket();
 if isempty(ib)||isempty(ia),break;end
 if abs(log(max(res(ib),realmin)/p.target))<.03,break;end
 a=sqrt(params(ib)*params(ia));
 [x,info,state]=v7_graph_candidate(p,t,a,states{ib},t.cap);append(a,x,info,state);
end
[params,order]=sort(params);res=res(order);xs=xs(order);infos=infos(order);states=states(order);
good=find(cellfun(@(z)z.converged,infos));eligible=good;
if isempty(eligible),eligible=1:numel(res);end
[~,k]=min(abs(log(max(res(eligible),realmin)/p.target)));j=eligible(k);
[ib,ia]=bracket();bracketed=~isempty(ib)&&~isempty(ia);
s=struct('x',xs{j},'converged',infos{j}.converged,'iterations',total,'parameter',params(j), ...
 'boundary',j==1||j==numel(params),'selection','Morozov; certified primal-dual gap bracket; bounded data-only search', ...
 'diagnostics',struct('parameters',params,'residuals',res,'selectedIndex',j, ...
 'candidateConverged',cellfun(@(z)z.converged,infos),'selectedSolver',infos{j}, ...
 'targetBracketed',bracketed,'selectionValid',bracketed&&infos{j}.converged, ...
 'targetBracketedBeforeCertification',min(res)<=p.target&&max(res)>=p.target, ...
 'parameterSelectionUsesConvergedCandidates',~isempty(good), ...
 'algorithm','Pock-Chambolle diagonal metric; Malitsky-Pock line search', ...
 'regularization','Same masked-density isotropic TV objective as TV-2D', ...
 'objectiveConverged',infos{j}.converged));
 function append(a,x,info,state)
  params(end+1)=a;res(end+1)=info.residual;xs{end+1}=x;infos{end+1}=info;states{end+1}=state;
  total=total+info.iterations;
  fprintf('TV-PD alpha %.4g chi2 %.5g conv%d gap%.3g KKT%.3g iter%d\n',a,info.residual,info.converged,info.relativeGap,info.kkt,info.iterations);
 end
 function polish(j)
  if infos{j}.converged,return;end
  old=infos{j};[x,info,state]=v7_graph_candidate(p,t,params(j),states{j},t.cap);
  total=total+info.iterations;
  % Retain a converged result even if roundoff reverses objective by tiny eps.
  if info.converged||info.objective<=old.objective+1e-10*max(1,abs(old.objective))
   xs{j}=x;infos{j}=info;states{j}=state;res(j)=info.residual;
  end
 end
 function [ib,ia]=bracket()
  g=find(cellfun(@(z)z.converged,infos));bb=g(res(g)<=p.target);aa=g(res(g)>p.target);ib=[];ia=[];
  if isempty(bb)||isempty(aa),return;end
  [~,j1]=max(params(bb));[~,j2]=min(params(aa));ib=bb(j1);ia=aa(j2);
  if params(ib)>=params(ia),ib=[];ia=[];end
 end
end
