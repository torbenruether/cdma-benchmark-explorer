function [mu,info]=v6_gp_lbfgs(P,x0,d,mu,audit,c)
% Bounded, matrix-free interior-point L-BFGS for the SAME GP covariance dual.
% Subtracting a fixed objective constant avoids cancellation near its minimum.
reference=max(mu./d,0);Q=@(v)d.*P(d.*v);
gradientAtReference=d.*(x0+P(d.*reference));
objectiveScale=max(norm(gradientAtReference,inf),1e-8);
cap=180;if isfield(c,'gpLBFGSIterations'),cap=c.gpLBFGSIterations;end
flag=-99;out=struct('iterations',0,'firstorderopt',Inf,'message','not called');
try
 options=optimoptions('fmincon','Algorithm','interior-point','Display','off', ...
  'SpecifyObjectiveGradient',true,'HessianApproximation','lbfgs', ...
  'SubproblemAlgorithm','cg','OptimalityTolerance',min(1e-10,c.tolerance*.01), ...
  'ConstraintTolerance',1e-12,'StepTolerance',1e-13,'FunctionTolerance',1e-14, ...
  'MaxIterations',cap,'MaxFunctionEvaluations',10*cap);
 % Strictly positive starting values prevent automatic large bound shifts.
 start=max(reference,1e-12*max(1,norm(reference,inf)));
 [z,~,flag,out]=fmincon(@objective,start,[],[],[],[],zeros(size(start)),[],[],options);
 if any(~isfinite(z)),z=reference;end
catch err
 z=reference;out.message=err.message;
end
mu=d.*max(z,0);
% Interior-point iterates approach an active bound from inside. Project only
% negligible multipliers whose own bound gradient points outward; audit the
% resulting full primal again, rather than treating its exit flag as success.
primal=x0+P(mu);near=mu<=1e-9*max(1,norm(mu,inf))&primal>0;
snapped=mu;snapped(near)=0;
[originalKKT,originalImpact]=audit(mu,primal);
[snappedKKT,snappedImpact]=audit(snapped,x0+P(snapped));
delta=snapped-mu;change=primal'*delta+.5*delta'*P(delta);
if change<=0&&snappedKKT<originalKKT&&snappedImpact<=max(originalImpact,.01)
 mu=snapped;kkt=snappedKKT;impact=snappedImpact;
else,kkt=originalKKT;impact=originalImpact;end
target=1;if isfield(c,'gpAuditTarget'),target=c.gpAuditTarget;end
info=struct('iterations',out.iterations,'kkt',kkt,'exitflag',flag, ...
 'firstorderopt',out.firstorderopt,'message',out.message, ...
 'clippingMeasurementImpact',impact,'negligibleBoundCandidates',nnz(near), ...
 'converged',kkt<c.tolerance&&impact<.01*sqrt(target), ...
 'algorithm','Matrix-free interior-point L-BFGS, analytic gradient, fixed-reference quadratic objective');
 function [value,gradient]=objective(z)
  delta=z-reference;Qdelta=Q(delta);
  value=(.5*delta'*Qdelta+gradientAtReference'*delta)/objectiveScale;
  gradient=(Qdelta+gradientAtReference)/objectiveScale;
 end
end
