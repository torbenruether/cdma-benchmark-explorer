function s=extended_tgv(p)
% Same TGV2 objective as v5. The historical method label is retained for
% benchmark continuity; the actual optimizer is explicitly recorded as ADMM.
% Positivity is an exact consensus variable, not final unchecked clipping.
s=v6_graph_path(p,2);
end
