function s=extended_lognormal(p)
% Separate strong-prior arm: a single correlated lognormal with fitted total.
% Fixed starts are instrument-domain choices, not the benchmark's true GMDs.
lo=log(p.g.edges(1));hi=log(p.g.edges(end));
starts=[180 45;350 90;650 180;120 100];
lb=[lo lo log(1.05) log(1.05) -.95 log(1e-3/p.scale)];
ub=[hi hi log(2.5) log(2.5) .95 log(1e9/p.scale)];
opts=optimoptions('lsqnonlin','Display','off','MaxIterations',150, ...
 'MaxFunctionEvaluations',1800,'FunctionTolerance',1e-9,'OptimalityTolerance',1e-6);
best=Inf;iterations=0;records=[];
for j=1:size(starts,1)
 z0=[log(starts(j,:)) log([1.5 1.5]) 0 log(max(sum(p.y)/max(sum(p.A,1)),1)/p.scale)];
 z0=min(max(z0,lb),ub);
 [z,value,~,flag,out]=lsqnonlin(@residual,z0,lb,ub,opts);
 iterations=iterations+out.iterations;records=[records; value flag]; %#ok<AGROW>
 if value<best,best=value;bestz=z;bestflag=flag;bestout=out;end
end
s=struct('x',mass(bestz),'iterations',iterations,'converged',bestflag>0, ...
 'parameter',NaN,'selection','Four fixed starts; lowest measured-space objective; one-mode prior', ...
 'boundary',any(abs(bestz-lb)<1e-5|abs(bestz-ub)<1e-5), ...
 'diagnostics',struct('parameters',bestz,'startResults',records,'exitflag',bestflag, ...
 'firstOrderOptimality',bestout.firstorderopt,'prior','One correlated 2D lognormal; not nonparametric'));
 function x=mass(z)
  comp=struct('gmdDm',exp(z(1)),'gmdDst',exp(z(2)), ...
   'gsdDm',exp(z(3)),'gsdDst',exp(z(4)),'rho',z(5),'weight',1);
  X=cdma_truth(p.g,comp,exp(z(6)));x=X(p.g.active);
 end
 function r=residual(z),r=p.B*mass(z)-p.b;end
end
