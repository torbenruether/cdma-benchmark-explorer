function [X,info] = cdma_truth(g,components,totalN)
% A lognormal component conditioned on dm>=dst and finite grid, per mode.
% Component weights denote POST-conditioning concentration fractions.
assert(abs(sum([components.weight])-1)<1e-12,'Modal weights must sum to one.');
components=reshape(components,1,[]);
X=zeros(g.n); kept=zeros(size(components)); physical=kept; box=kept;
nodes=[-0.960289856497536 -0.796666477413627 -0.525532409916329 -0.183434642495650 ...
        0.183434642495650 0.525532409916329 0.796666477413627 0.960289856497536];
w=[0.101228536290376 0.222381034453374 0.313706645877887 0.362683783378362 ...
   0.362683783378362 0.313706645877887 0.222381034453374 0.101228536290376]/2;
u=(nodes+1)/2; h=g.h(1); loM=log(g.dm)-h/2; loS=log(g.dst)-h/2;
for k=1:numel(components)
    a=components(k); assert(a.gmdDm>0 && a.gmdDst>0 && a.gsdDm>1 && a.gsdDst>1);
    assert(abs(a.rho)<1 && a.weight>=0);
    sm=log(a.gsdDm); ss=log(a.gsdDst); P=zeros(g.n); B=P;
    for i=1:8
        for j=1:8
            lm=loM+h*u(i); ls=loS+h*u(j);
            B=B+w(i)*w(j)*density(lm,ls)*h^2;
            % Integrate diagonal: lm=lo+h*u, ls=lo+h*u*v, Jacobian h^2*u.
            lm(g.diagonal)=loM(g.diagonal)+h*u(i);
            ls(g.diagonal)=loS(g.diagonal)+h*u(i)*u(j);
            jac=h^2*ones(g.n); jac(g.diagonal)=h^2*u(i);
            P=P+w(i)*w(j)*density(lm,ls).*jac;
        end
    end
    P(~g.allowed)=0; kept(k)=sum(P(:)); box(k)=sum(B(:));
    assert(kept(k)>1e-12,'Component has negligible admissible mass.');
    sd=sqrt(sm^2+ss^2-2*a.rho*sm*ss);
    physical(k)=0.5*erfc(log(a.gmdDm/a.gmdDst)/(sqrt(2)*sd));
    X=X+totalN*a.weight*P/kept(k);
end
info.componentRetainedFraction=kept;
info.componentPhysicalExcludedFraction=physical;
info.componentGridExcludedFraction=1-box;
info.retainedFraction=sum([components.weight].*kept);
info.truncatedFraction=1-info.retainedFraction;
info.renormalization=1./kept;
assert(abs(sum(X(:))/totalN-1)<1e-12 && all(X(~g.allowed)==0));
    function f=density(lm,ls)
        z=(lm-log(a.gmdDm))/sm; v=(ls-log(a.gmdDst))/ss;
        f=exp(-(z.^2-2*a.rho*z.*v+v.^2)/(2*(1-a.rho^2))) ...
            /(2*pi*sm*ss*sqrt(1-a.rho^2));
    end
end
