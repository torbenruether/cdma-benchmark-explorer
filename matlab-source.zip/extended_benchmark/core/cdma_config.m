function c = cdma_config()
%CDMA_CONFIG Small preregistered pilot, independent of reconstruction truth.
c.version = '2.0-dm-dst';
c.outputName = 'monomodal_dst';
c.gmdDm = [250 315 400]; c.gmdDst = [50 60 75];
c.proposedGmd = [50 150 450];
c.gsd = 1.30; c.totalN = 1e5;
% Optional struct array: each entry is a case with a .components array.
% Component fields: gmdDm,gmdDst,gsdDm,gsdDst,rho,weight. Weights sum to 1.
c.customCases = [];
c.rangeNm = [20 1000]; c.nBins = 24;
c.scanPoints = 24; c.scanRangeNm = [15 1200];
c.quadrature = 6; c.fineFactor = 4;
c.fineCases = [3 5 7];
c.noiseRelative = 0.03; c.replicates = 2; c.noiseFloorRatio = 0.1;
c.noiselessRelative = 1e-3; c.noiselessFloor = 1e-4;
c.seed = 314159;
c.maxIterations = 4000; c.tolerance = 2e-6;
c.pathMultipliers = [0 logspace(-6,4,17)];
c.pocsIterations = 15000; c.legacyIterations = 600; c.tvIterations = 12000;
c.gpLengths = [0.08 0.2 0.5];
c.gpAlpha = logspace(-6,4,17);
c.methods = {'Tikhonov','Twomey-Markowski','Maximum Entropy', ...
    'POCS-PSS','Bayesian GP-MAP','Huber-TV','POCS-CDMA','TV-2D'};
c.makeFigures = true;
c.device = struct('L',0.334,'Ri',0.0709,'Ra',0.0743, ...
    'Qsh',1.5/6e4,'Qa',0.3/6e4,'Qs',0.3/6e4, ...
    'eta',1.8077e-5,'lambda',6.65e-8,'rhoP',10490,'e',1.602176634e-19);
end


