function [p,rawSum] = cdma_charge(dm)
% Wiedensohler(-2:2)/Gunn tails from original CalcChargeDist.m.
% Correct original Gunn k=1.31e-23 typo to 1.380649e-23; normalize hybrid.
dm=dm(:)'; assert(all(dm>=20 & dm<=1000));
a=[-26.3328 -2.3197 -0.0003 -2.3484 -44.4756; ...
35.9044 0.6175 -0.1014 0.6044 79.3772; ...
-21.4608 0.6201 0.3073 0.48 -62.89; ...
7.0867 -0.1105 -0.3372 0.0013 26.4492; ...
-1.3088 -0.126 0.1023 -0.1544 -5.748; ...
0.1051 0.0297 -0.0105 0.032 0.5059];
p=zeros(21,numel(dm));
ix=dm>=100;
s=2*pi*8.8542e-12*1.380649e-23*293.15/1.602176634e-19^2*dm(ix)*1e-9;
if any(ix)
    p(:,ix)=exp(-((-10:10)'-s*log(0.875)).^2./(2*s))./sqrt(2*pi*s);
end
t=log10(dm);
for j=1:5, p(j+8,:)=10.^polyval(flipud(a(:,j)),t); end
rawSum=sum(p,1); p=p./rawSum;
end
