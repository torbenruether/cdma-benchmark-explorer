function [A,scan,diagnostics] = cdma_kernel(g,c,scan)
% Ideal plug-flow CDMA trajectories from original ForwardCalc.m.
% Analytic inlet-flux overlap replaces 50 radial particle trajectories.
% Source convention: dst=sqrt(dv^3/dm); tau=rhoP*dst^2*Cc(dm)/(18*eta).
d=c.device; cc=@(x) 1+2*d.lambda./x.*(1.142+0.558*exp(-0.999*x/(2*d.lambda)));
resTime=d.L*pi*(d.Ra^2-d.Ri^2)/(d.Qsh+d.Qa);
ri2=d.Ri^2; ro2=d.Ra^2;
inHi=ri2+d.Qa/(d.Qsh+d.Qa)*(ro2-ri2);
outLo=ro2-d.Qs/(d.Qsh+d.Qa)*(ro2-ri2);
if nargin<3 || isempty(scan)
    ds=logspace(log10(c.scanRangeNm(1)),log10(c.scanRangeNm(2)),c.scanPoints)*1e-9;
    z=d.e*cc(ds)./(3*pi*d.eta*ds);
    volt=[0 d.Qsh*log(d.Ra/d.Ri)./(2*pi*d.L*z)];
    tau=d.rhoP*ds.^2.*cc(ds)/(18*d.eta);
    a0=log((ro2+outLo)/(ri2+inHi))/(2*resTime);
    hz=[0 sqrt(a0./tau)/(2*pi)];
    [U,H]=meshgrid(volt,hz); scan=table(U(:),H(:),'VariableNames',{'Voltage_V','Rotation_Hz'});
    % Neither force transfers particles to the outer outlet; omit zero row.
    scan(scan.Voltage_V==0 & scan.Rotation_Hz==0,:)=[];
end
q=c.quadrature; nodes=((1:q)-0.5)/q;
A=zeros(height(scan),g.n^2); rawMin=inf; rawMax=0;
for im=1:q
    for ia=1:q
        dm=g.dm(:)'*exp((nodes(im)-0.5)*g.h(1))*1e-9;
        da=g.dst(:)'*exp((nodes(ia)-0.5)*g.h(1))*1e-9;
        ix=g.diagonal(:)'; % uniform-area samples in triangular log cells
        dm(ix)=g.dm(ix)*exp((sqrt(nodes(im))-0.5)*g.h(1))*1e-9;
        da(ix)=g.dst(ix)*exp((sqrt(nodes(im))*nodes(ia)-0.5)*g.h(1))*1e-9;
        [prob,raw]=cdma_charge(dm*1e9); rawMin=min(rawMin,min(raw)); rawMax=max(rawMax,max(raw));
        Z=d.e*cc(dm)./(3*pi*d.eta*dm);
        tau=d.rhoP*da.^2.*cc(dm)/(18*d.eta);
        for r=1:height(scan)
            a=tau*(2*pi*scan.Rotation_Hz(r))^2;
            ee=exp(-2*resTime*a);
            factor=2*resTime*ones(size(a)); pos=a>0;
            factor(pos)=-expm1(-2*resTime*a(pos))./a(pos);
            unitShift=scan.Voltage_V(r)*Z/log(d.Ra/d.Ri).*factor;
            trans=zeros(size(dm));
            for j=1:21
                shift=(j-11)*unitShift;
                lower=outLo*ee-shift; upper=ro2*ee-shift;
                overlap=max(0,min(inHi,upper)-max(ri2,lower))/(inHi-ri2);
                trans=trans+prob(j,:).*overlap;
            end
            A(r,:)=A(r,:)+trans/(q*q);
        end
    end
end
A(:,~g.allowed(:))=0;
assert(all(isfinite(A(:))) && min(A(:))>=0 && max(A(:))<=1+1e-12);
diagnostics=struct('rawChargeSumMin',rawMin,'rawChargeSumMax',rawMax, ...
    'minimumColumnSensitivity',min(max(A,[],1)), ...
    'zeroAllowedColumns',sum(max(A(:,g.active),[],1)==0),'excludedColumns',sum(~g.allowed(:)),'residenceTime_s',resTime);
A=sparse(A);
end
