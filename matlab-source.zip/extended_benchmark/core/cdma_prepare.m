function p=cdma_prepare(A,y,sigma,g,c,scan)
% Matrix-free in parameter space: only measurement-space dense matrices.
p.fullA=A; p.A=A(:,g.active); p.y=y(:); p.sigma=sigma(:);p.g=g;p.c=c;p.scan=scan;
p.scale=max(max(abs(y)),1);p.m=numel(y);p.n=numel(g.active);
p.B=spdiags(p.scale./sigma(:)/sqrt(p.m),0,p.m,p.m)*p.A;
p.b=y(:)./sigma(:)/sqrt(p.m);p.rhs=p.B'*p.b;
% Direct rectangular SVD preserves small weighted measurement directions.
% A relative eig(B*B') cutoff previously misclassified feasible cases.
[p.svdV,S,p.svdU]=svd(full(p.B'),'econ');p.svdS=diag(S);
p.V=p.svdU;p.e=p.svdS.^2;p.lip=max(p.e);
p.svdRelativeReconstruction=norm(p.B-p.svdU*S*p.svdV','fro')/max(norm(p.B,'fro'),eps);
p.target=1;p.diagQ=full(sum(p.B.^2,1))';
if isfield(g,'normalizedR'),p.R=g.normalizedR;p.D=g.normalizedD;
else,p.R=g.L'*g.L;p.R=p.R/max(norm(p.R,inf),eps);D=g.D*g.densityScale;p.D=D/max(sqrt(norm(D,1)*norm(D,inf)),eps);end
p.Ga=g.Ga;p.Gm=g.Gm;p.zero=zeros(p.n,1);p.priorMass=g.area(g.active)/sum(g.area(:));
end
