function g = cdma_grid(c,n)
if nargin<2, n=c.nBins; end
g.edges=logspace(log10(c.rangeNm(1)),log10(c.rangeNm(2)),n+1);
g.centres=sqrt(g.edges(1:end-1).*g.edges(2:end));
g.h=diff(log(g.edges)); g.n=n;
[g.dm,g.dst]=meshgrid(g.centres,g.centres);
% Rows=dst, columns=dm, dst varies fastest in X(:).
% Diagonal cells are TRIANGLES, not full rectangular cells.
g.allowed=g.dst<=g.dm; g.active=find(g.allowed); g.diagonal=eye(n)>0;
g.area=g.h(:)*g.h(:)'; g.area(~g.allowed)=0;
g.area(g.diagonal)=g.area(g.diagonal)/2;
g.meanLogDm=log(g.dm); g.meanLogDst=log(g.dst);
g.meanLogDm(g.diagonal)=g.meanLogDm(g.diagonal)+g.h(1)/6;
g.meanLogDst(g.diagonal)=g.meanLogDst(g.diagonal)-g.h(1)/6;
g.varLog=g.h(1)^2/12*ones(n); g.varLog(g.diagonal)=g.h(1)^2/18;
E=spdiags([-ones(n,1) ones(n,1)],[0 1],n-1,n)/g.h(1);
Da=kron(speye(n),E); Dm=kron(E,speye(n));
Da=inside(Da); Dm=inside(Dm); g.Dst=Da; g.Dm=Dm;
g.D=[Da;Dm];
E2=spdiags([ones(n,1) -2*ones(n,1) ones(n,1)],[0 1 2],n-2,n)/g.h(1)^2;
L=[kron(speye(n),E2);kron(E2,speye(n))]; L=inside(L);
% Smooth density rather than bin mass (diagonal bins have half the area).
g.densityScale=spdiags(g.h(1)^2./g.area(g.active),0,numel(g.active),numel(g.active));
g.L=L*g.densityScale;
F=[E;sparse(1,n)]; Ga=kron(speye(n),F); Gm=kron(F,speye(n));
Ga(any(Ga(:,~g.allowed(:))~=0,2),:)=0;
Gm(any(Gm(:,~g.allowed(:))~=0,2),:)=0;
g.Ga=Ga(g.active,g.active)*g.densityScale;
g.Gm=Gm(g.active,g.active)*g.densityScale;
    function R=inside(R)
        R=R(~any(R(:,~g.allowed(:))~=0,2),g.active);
    end
end
