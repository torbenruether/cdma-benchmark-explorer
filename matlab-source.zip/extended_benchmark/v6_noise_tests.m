function v6_noise_tests
c=extended_config;mu=[0;10;200;1000];
d=extended_noise(mu,.03,.05,20261006,c);
assert(isequal(d.y,d.raw) && ~c.clipNegative);
z=extended_noise(mu,0,0,1,c);assert(isequal(z.y,mu));
again=extended_noise(mu,.03,.05,20261006,c);assert(isequal(d,again));
assert(abs(d.sigmaAbs-50)<eps && all(d.sigma>0));
% Exact reproducibility of separate absolute/relative random deviates.
st=RandStream('mt19937ar','Seed',20261006);a=50*randn(st,4,1);r=.03*mu.*randn(st,4,1);
assert(isequal(d.y,mu+a+r));
fprintf('PASS: signed Gaussian noise, absolute peak calibration, reproducible draws.\n');
end
