function [z,info]=revision_ball_project(v,p,limit)
% Euclidean projection of ORIGINAL v onto ||B*x-b||^2 <= limit.
% Direct rectangular SVD; no relative Gram rank cutoff or repeated prox.
r=p.B*v-p.b;initial=r'*r;
info=struct('verified',true,'lambda',0,'residual',initial,'status','inside', ...
 'infeasibleCertified',false,'relativeStationarity',0);
if initial<=limit,z=v;return;end
U=p.svdU;W=p.svdV;s=p.svdS;t=U'*r;exactZero=s==0;
% Square U spans all measurement directions. Its rounded orthogonality
% error must not be interpreted as an unavoidable physical residual.
if size(U,2)==p.m,perp=0;else,perp=norm(r-U*t)^2;end
minimum=perp+sum(t(exactZero).^2);
zeroRows=~any(p.B~=0,2);zeroMinimum=sum(p.b(zeroRows).^2);
if zeroMinimum>limit
 z=v;info.verified=false;info.infeasibleCertified=true;
 info.status='exact-zero-row infeasibility certificate';return;
end
if minimum>limit*(1+1e-8)
 z=v;info.verified=false;info.status='SVD range verification numerical failure';
 info.spectralMinimum=minimum;return;
end
lo=0;hi=1/max(max(s)^2,realmin);
for k=1:320
 if spectral(hi)<=limit,break;end
 hi=hi*4;if ~isfinite(hi),hi=realmax/16;break;end
end
if spectral(hi)>limit
 z=v;info.verified=false;info.status='projection bracket numerical failure';return;
end
for k=1:90
 mid=.5*lo+.5*hi;
 if spectral(mid)>limit,lo=mid;else,hi=mid;end
end
% Reciprocal form avoids lambda*s^2 overflow and Gram subtraction.
coef=s./(s.^2+1/hi);coef(exactZero)=0;
z=v-W*(coef.*t);
actual=norm(p.B*z-p.b)^2;
% Re-applying the prox to z would change the original closest-point problem.
% Certify stationarity relative to v instead of silently changing the prior.
directGradient=hi*(p.B'*(p.B*z-p.b));
directRelative=norm(z-v+directGradient)/max([1,norm(z-v),norm(directGradient)]);
% The direct B' residual above loses digits for the intentionally 1e10-
% conditioned regression fixture. Verify stationarity in the orthogonal SVD
% coordinates and retain the raw calculation as a rounding diagnostic.
stableGradient=W*(coef.*t);
relativeStationarity=norm(z-v+stableGradient)/max(1,norm(z-v));
info.lambda=hi;info.residual=actual;info.relativeStationarity=relativeStationarity;
info.directRelativeStationarity=directRelative;
info.verified=actual<=limit*(1+1e-5)&&relativeStationarity<=1e-5;
info.status='projected';if ~info.verified,info.status='projection verification numerical failure';end
info.spectralResidual=spectral(hi);info.spectralMinimum=minimum;
 function q=spectral(a)
  q=perp+sum((t./(1+a*s.^2)).^2);
 end
end
