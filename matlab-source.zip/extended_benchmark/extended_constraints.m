function [C,lo,hi]=extended_constraints(g,aux,scale)
% Optional EXTERNAL measurements in bin concentration units, not densities.
% Each entry: .value, .sigma (same shape); bands are +/- 3 sigma.
% .source must identify independent measured information, never synthetic truth.
assert(isscalar(scale)&&isfinite(scale)&&scale>0,'Invalid concentration scale');
n=numel(g.active);[rows,cols]=ind2sub([g.n g.n],g.active);
C=sparse(0,n);lo=[];hi=[];
for key={'total','dm','dst'}
 name=key{1};if isempty(aux.(name)),continue;end
 v=aux.(name);assert(isfield(v,'source')&&~isempty(v.source),'Auxiliary measurement source required');
 assert(all(isfinite(v.value(:)))&&all(v.value(:)>=0)&& ...
  all(isfinite(v.sigma(:)))&&all(v.sigma(:)>=0),'Invalid auxiliary measurement');
 switch name
  case 'total',M=sparse(ones(1,n));
  case 'dm',M=sparse(cols,1:n,1,g.n,n);
  case 'dst',M=sparse(rows,1:n,1,g.n,n);
 end
 assert(numel(v.value)==size(M,1),'Wrong auxiliary measurement dimension');
 ss=v.sigma;assert(isscalar(ss)||numel(ss)==numel(v.value),'Wrong auxiliary uncertainty dimension');
 if isscalar(ss),ss=repmat(ss,size(v.value));end
 C=[C;M];lo=[lo;max(v.value(:)-3*ss(:),0)/scale];hi=[hi;(v.value(:)+3*ss(:))/scale]; %#ok<AGROW>
end
end
