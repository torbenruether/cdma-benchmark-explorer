function v7_audit_control_metadata
% Keep declared Morozov noise budget separate from optimiser convergence.
% Solutions and error metrics are unchanged; prior metadata is archived.
c=v7_config;backup=fullfile(c.outputRoot,'metadata_before_audit');
if ~exist(backup,'dir'),mkdir(backup);end
files=dir(fullfile(c.outputRoot,'ds*_TV_Morozov_PD.mat'));
for k=1:numel(files)
 file=fullfile(files(k).folder,files(k).name);d=load(file);
 before=fullfile(backup,files(k).name);if ~exist(before,'file'),copyfile(file,before);end
 csv=strrep(file,'.mat','.csv');beforeCsv=fullfile(backup,strrep(files(k).name,'.mat','.csv'));
 if ~exist(beforeCsv,'file'),copyfile(csv,beforeCsv);end
 radius=d.s.diagnostics.residualBallRadius;
 validBudget=isfinite(radius)&&radius>0;
 d.s.diagnostics.selectionValid=validBudget;
 d.s.diagnostics.fixedNoiseBudgetValid=validBudget;
 d.row.ParameterSelectionValid=validBudget;
 d.row.DataCompatible=sqrt(d.row.WeightedResidual)<=radius+64*eps*max(1,radius);
 d.row.Validated=d.row.ObjectiveConverged&&d.row.DataCompatible&&validBudget&&d.row.ConstraintViolation<=1e-9;
 d.row.TargetPass=d.row.Validated&&d.row.QualityTargetsPass;
 save(file,'-struct','d','-v7');writetable(struct2table(d.row),csv);
end
fprintf('Morozov metadata audited: defined error radius independent of convergence; original metadata retained.\n');
end
