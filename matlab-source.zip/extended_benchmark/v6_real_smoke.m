function v6_real_smoke(stage)
% Same 108x108 physical grid and new 1224-row operator as the forthcoming run.
if nargin<1,stage='all';end
c=extended_config;maxNumCompThreads(1);k=load(c.commonFile);[manifest,~]=extended_plan(c);
row=manifest(5,:);a=struct('gmdDm',c.pairsNm(1,1),'gmdDst',c.pairsNm(1,2), ...
 'gsdDm',c.gsd,'gsdDst',c.gsd,'rho',0,'weight',1);
truth=cdma_truth(k.g,a,c.totalN);clean=k.A*truth(:);
data=extended_noise(clean,row.Relative,row.AbsoluteFraction,row.Seed,c);
timer=tic;p=cdma_prepare(k.A,data.y,data.sigma,k.g,c,k.scan);preparationSeconds=toc(timer);
folder=fullfile(c.root,'smoke_outputs');if ~exist(folder,'dir'),mkdir(folder);end
results=struct([]);methods={'POCS-PSS','POCS-CDMA','Bayesian GP-MAP'};
if strcmp(stage,'gp'),methods={'Bayesian GP-MAP'};end
if strcmp(stage,'graph'),methods={};end
for j=1:numel(methods)
 s=extended_solve(methods{j},p);r=large_metrics(s.binCounts,truth,k.g,a,c.totalN);
 r.Method=methods{j};r.Validated=s.benchmarkValid;r.ObjectiveConverged=s.objectiveConverged;
 r.DataCompatible=s.dataCompatible;r.ParameterSelectionValid=s.parameterSelectionValid;
 r.Seconds=s.seconds;r.Iterations=s.iterations;r.Status=s.status;r.ConstraintViolation=s.constraintViolation;
 results=[results;r];save(fullfile(folder,sprintf('smoke_%d.mat',j)),'s','r','row','data','truth','-v7');
 writetable(struct2table(results),fullfile(folder,'results.csv'));
 fprintf('Real1224 %s: validated%d, objective%d, data%d, parameter%d, L2%.3g, %.1fs\n', ...
  methods{j},r.Validated,r.ObjectiveConverged,r.DataCompatible,r.ParameterSelectionValid,r.RelativeL2,r.Seconds);
end
if strcmp(stage,'gp'),return;end
% Bounded fixed-alpha controls check the actual large TV/TGV operators.
for order=1:2
 timer=tic;t=v6_graph_setup(p,order);setupSeconds=toc(timer);
 alpha=max(norm(t.rhs,inf),eps)/max(norm(t.Dreg,1),eps)*.01;
 [x,info]=v6_graph_candidate(p,t,alpha,[],12000);
 s=struct('x',x,'diagnostics',info,'alpha',alpha,'order',order,'setupSeconds',setupSeconds);
 save(fullfile(folder,sprintf('graph_order%d.mat',order)),'s','-v7');
 assert(all(isfinite(x)) && min(x)>=0 && isfinite(info.objective));
 fprintf('Real1224 fixed-alpha order%d: converged%d KKT%.3g gap%.3g %.1fs +setup%.1fs\n', ...
  order,info.converged,info.kkt,info.complementarityGap,toc(timer)-setupSeconds,setupSeconds);
end
save(fullfile(folder,'summary.mat'),'results','preparationSeconds','row','-v7');
fprintf('Full-grid smoke finished; uncertified solutions remain explicitly uncertified.\n');
end
