function results=run_v7_tests(families)
% Bounded independent-reference tests. Never resumes a benchmark or a pool.
if nargin<1,families={'pocs','smooth','strong','tv','dispatch'};end
root=fileparts(mfilename('fullpath'));addpath(root,fullfile(root,'core'));
maxNumCompThreads(2); %#ok<MAXNCT>
results=struct('family',{},'passed',{},'seconds',{},'message',{});
for k=1:numel(families)
 timer=tic;passed=false;message='';
 try
  switch families{k}
   case 'pocs',v7_pocs_tests;
   case 'smooth',v7_smooth_tests;
   case 'strong',v7_strong_tests;
   case 'tv',v7_graph_tests;
   case 'dispatch',v7_dispatch_tests;
   otherwise,error('Unknown fixture family %s',families{k});
  end
  passed=true;message='All independent-reference fixtures passed';
 catch err
  message=getReport(err,'extended','hyperlinks','off');fprintf(2,'%s\n',message);
 end
 results(k)=struct('family',families{k},'passed',passed,'seconds',toc(timer),'message',message); %#ok<AGROW>
end
save(fullfile(root,'v7_fixture_summary.mat'),'results','-v7');
writetable(struct2table(results),fullfile(root,'v7_fixture_summary.csv'));
assert(all([results.passed]),'v7:FixturesFailed','Some independent-reference fixtures failed.');
end
