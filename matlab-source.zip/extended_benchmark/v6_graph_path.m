function s=v6_graph_path(p,order)
t=v6_graph_setup(p,order);
if order==1,ratios=p.c.pathMultipliers;ratios=ratios(ratios>0);cap=p.c.tvIterations;
else,ratios=p.c.tgvAlpha;cap=p.c.tgvIterations;end
% Data/penalty gradient scale does not depend on the unknown true distribution.
scale=max(norm(t.rhs,inf),eps)/max(norm(t.Dreg,1),eps);
params=scale*ratios;xs={};states={};infos={};res=[];tested=[];state=[];total=0;next=1;extra=0;
pathCap=min(cap,2500);if isfield(p.c,'graphPathIterations'),pathCap=min(cap,p.c.graphPathIterations);end
while true
 if next<=numel(params),a=params(next);next=next+1;
 elseif min(res)>p.target&&extra<10,a=min(tested)/10;extra=extra+1;
 elseif max(res)<p.target&&extra<10,a=max(tested)*10;extra=extra+1;
 else,break;end
 if ~isempty(tested),[~,near]=min(abs(log(tested/a)));state=states{near};end
 [x,info,state]=v6_graph_candidate(p,t,a,state,pathCap);append(a,x,info,state);
 if numel(res)==1&&res(1)>p.target,next=numel(params)+1;end
 if numel(res)>1&&min(res)<=p.target&&max(res)>=p.target,break;end
 if isfield(p.c,'graphMaxCandidates')&&numel(res)>=p.c.graphMaxCandidates,break;end
end
% Polish both sides of the measured crossing, retaining the entire state.
below=find(res<=p.target);above=find(res>p.target);
if isempty(below)||isempty(above),[~,j]=min(abs(log(max(res,realmin)/p.target)));anchors=j;
else,[~,b]=max(tested(below));[~,a]=min(tested(above));anchors=[below(b) above(a)];end
for j=anchors,polish(j);end
for fine=1:5
 if isfield(p.c,'graphMaxCandidates'),break;end
 good=find(cellfun(@(v)v.converged,infos));below=good(res(good)<=p.target);above=good(res(good)>p.target);
 if isempty(below)||isempty(above),break;end
 [~,b]=max(tested(below));ib=below(b);[~,a]=min(tested(above));ia=above(a);
 if tested(ib)>=tested(ia)||abs(log(max(res(ib),realmin)/p.target))<.03,break;end
 a=sqrt(tested(ib)*tested(ia));[x,info,state]=v6_graph_candidate(p,t,a,states{ib},cap);append(a,x,info,state);
end
[tested,ord]=sort(tested);res=res(ord);xs=xs(ord);states=states(ord);infos=infos(ord);
good=find(cellfun(@(v)v.converged,infos));eligible=good;if isempty(eligible),eligible=1:numel(res);end
[~,best]=min(abs(log(max(res(eligible),realmin)/p.target)));j=eligible(best);
bracketed=~isempty(good)&&min(res(good))<=p.target&&max(res(good))>=p.target;
s=struct('x',xs{j},'converged',infos{j}.converged,'iterations',total,'parameter',tested(j), ...
 'boundary',j==1||j==numel(res),'selection','Morozov; warm ADMM path, certified crossing and retained-state polishing', ...
 'diagnostics',struct('parameters',tested,'residuals',res,'selectedIndex',j, ...
 'candidateConverged',cellfun(@(v)v.converged,infos),'selectedSolver',infos{j}, ...
 'targetBracketed',bracketed,'targetBracketedBeforeCertification',min(res)<=p.target&&max(res)>=p.target, ...
 'parameterSelectionUsesConvergedCandidates',~isempty(good),'order',order, ...
 'objectiveConverged',infos{j}.converged,'dataCompatible',res(j)<=1.10*p.target, ...
 'algorithmChange','Same TV/TGV2 regularization; over-relaxed two-block ADMM replaces previous implementation'));
 function append(a,x,info,state)
  tested(end+1)=a;res(end+1)=norm(p.B*x-p.b)^2;xs{end+1}=x;infos{end+1}=info;states{end+1}=state;total=total+info.iterations;
  fprintf('GRAPH order%d alpha %.4g chi2 %.5g conv%d KKT%.3g gap%.3g iter%d\n',order,a,res(end),info.converged,info.kkt,info.complementarityGap,info.iterations);
 end
 function polish(j)
  if infos{j}.converged,return;end
  old=infos{j};[x,info,state]=v6_graph_candidate(p,t,tested(j),states{j},2*cap);total=total+info.iterations;
  if info.objective<=old.objective+1e-10*max(1,abs(old.objective))
   info.iterations=info.iterations+old.iterations;xs{j}=x;res(j)=norm(p.B*x-p.b)^2;infos{j}=info;states{j}=state;
  end
 end
end
