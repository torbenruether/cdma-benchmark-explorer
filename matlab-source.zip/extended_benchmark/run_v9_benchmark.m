function run_v9_benchmark
% Fresh production entry; refuses old checkpoints and changed frozen sources.
c=extended_config;
assert(exist(fullfile(c.root,'V9_PREFLIGHT_PASS.json'),'file')==2,'v9 preflight not executed');
passed=jsondecode(fileread(fullfile(c.root,'V9_PREFLIGHT_PASS.json')));
assert(passed.passed && strcmp(passed.version,c.version),'Wrong preflight revision');
assert(~exist(fullfile(c.outputRoot,'progress.json'),'file'),'Fresh entry refuses existing run');
assert(~exist(fullfile(c.outputRoot,'STOP'),'file'),'Run is stopped');
pointer=jsondecode(fileread(fullfile(fileparts(c.root),'ACTIVE_RUN.json')));
assert(strcmp(pointer.version,c.version) && strcmp(pointer.sourceRoot,c.root) && strcmp(pointer.outputRoot,c.outputRoot));
manifest=readtable(fullfile(c.root,'SOURCE_SHA256.csv'),'TextType','string');
for j=1:height(manifest)
 file=fullfile(c.root,char(manifest.Path(j)));fid=fopen(file,'rb');assert(fid>=0);
 data=fread(fid,Inf,'*uint8');fclose(fid);md=java.security.MessageDigest.getInstance('SHA-256');md.update(data);
 actual=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
 assert(strcmp(actual,char(manifest.SHA256(j))),'Frozen source changed: %s',file);
end
run_extended_benchmark('full');
end
