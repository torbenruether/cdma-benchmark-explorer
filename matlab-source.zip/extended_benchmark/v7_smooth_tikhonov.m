function s=v7_smooth_tikhonov(p)
% Separate optimizer arm for unchanged nonnegative 2D Tikhonov regularization.
% Optional calling interface: v7_smooth_candidate(p,alpha,'Tikhonov',x0).
timer=tic;coarse=p;refined=p;
coarse.c.v7SmoothIterations=get('v7SmoothPathIterations',12);
coarse.c.v7SmoothLSQRIterations=get('v7SmoothPathLSQRIterations',200);
refined.c.v7SmoothIterations=get('v7SmoothSelectedIterations',40);
refined.c.v7SmoothLSQRIterations=get('v7SmoothSelectedLSQRIterations',600);
params=[];xs={};infos={};residuals=[];total=0;
run(0,p.zero,false);pilot=xs{1};diagData=full(sum(p.B.^2,1))';
S=ones(p.n,1);positive=diagData>0;S(positive)=1./sqrt(diagData(positive));
den=norm(S.*(p.R*pilot),inf);scale=norm(S.*p.rhs,inf)/max(den,realmin);
if ~isfinite(scale)||scale<=0||den<=1e-16,scale=max(p.lip,eps);end
initial=sort(unique(scale*p.c.pathMultipliers(p.c.pathMultipliers>0)));initial=initial(:)';
assert(~isempty(initial),'Tikhonov-Scaled requires a positive parameter grid.');
for alpha=initial
 run(alpha,xs{end},false);
 if numel(residuals)>2&&all(residuals(end-1:end)>p.target),break;end
end
for trial=1:get('v7SmoothAlphaExtensions',6)
 if any(residuals(params>0)>p.target),break;end
 run(max(params)*10,xs{end},false);
end
positive=find(params>0);[lowAlpha,index]=min(params(positive));lowIndex=positive(index);
for trial=1:get('v7SmoothAlphaExtensions',6)
 if any(residuals(params>0)<=p.target),break;end
 lowAlpha=lowAlpha/10;run(lowAlpha,xs{lowIndex},false);lowIndex=numel(params);
end
eligible=find(params>0);[~,near]=sort(abs(log(max(residuals(eligible),realmin)/p.target)));
for k=1:min(3,numel(near)),certify(eligible(near(k)));end
for trial=1:get('revisionAlphaRefinements',5)
 solved=find(params>0&cellfun(@(q)q.converged,infos));
 below=solved(residuals(solved)<=p.target);above=solved(residuals(solved)>=p.target);
 if isempty(below)||isempty(above),break;end
 [lo,idx]=max(params(below));iLo=below(idx);hi=min(params(above));
 if lo>=hi,break;end
 run(sqrt(lo*hi),xs{iLo},true);
 if infos{end}.converged&&abs(log(max(residuals(end),realmin)/p.target))<.03,break;end
end
[params,order]=sort(params);xs=xs(order);infos=infos(order);residuals=residuals(order);
eligible=find(params>0);qualified=eligible(cellfun(@(q)q.converged,infos(eligible)));
selectable=qualified;if isempty(selectable),selectable=eligible;end
[~,index]=min(abs(log(max(residuals(selectable),realmin)/p.target)));selected=selectable(index);
bracket=~isempty(qualified)&&min(residuals(qualified))<=p.target&&max(residuals(qualified))>=p.target;
boundary=selected==eligible(1)||selected==eligible(end);
selectionValid=bracket&&abs(log(max(residuals(selected),realmin)/p.target))<=.05;
s=struct('x',xs{selected},'converged',infos{selected}.converged,'iterations',total, ...
 'parameter',params(selected),'boundary',boundary,'selection','Measurement-only discrepancy; positive alpha; augmented-LS optimizer variant', ...
 'diagnostics',struct('parameters',params,'residuals',residuals,'selectedIndex',selected, ...
 'candidateConverged',cellfun(@(q)q.converged,infos),'selectableParameters',params(eligible), ...
 'selectedSolver',infos{selected},'targetBracketed',bracket,'selectionValid',selectionValid, ...
 'alphaScale',scale,'alphaScalePolicy','Exact data-column equilibration and NNLS pilot penalty gradient; no truth', ...
 'parameterSelectionUsesConvergedCandidates',~isempty(qualified),'weightDiagnostics',v7_weight_diagnostics(p), ...
 'sameRegularizerAs','Tikhonov','objectiveConverged',infos{selected}.converged, ...
 'dataCompatible',residuals(selected)<=1.10*p.target));
s.residual=residuals(selected);s.seconds=toc(timer);
s.binCounts=zeros(p.g.n);s.binCounts(p.g.active)=s.x*p.scale;
 function run(alpha,start,full)
  pp=coarse;if full,pp=refined;end
  t=tic;[x,info]=v7_smooth_candidate(pp,alpha,'Tikhonov',start);
  r=norm(p.B*x-p.b)^2;params(end+1)=alpha;xs{end+1}=x;infos{end+1}=info;residuals(end+1)=r;
  total=total+info.iterations;trace(alpha,info,r,toc(t));
 end
 function certify(index)
  if infos{index}.converged,return;end
  t=tic;[x,info]=v7_smooth_candidate(refined,params(index),'Tikhonov',xs{index});total=total+info.iterations;
  if info.objective<=infos{index}.objective+1e-10*max(1,abs(infos{index}.objective))
   xs{index}=x;infos{index}=info;residuals(index)=norm(p.B*x-p.b)^2;
  end
  trace(params(index),infos{index},residuals(index),toc(t));
 end
 function trace(alpha,info,r,t)
  if get('revisionTrace',false),fprintf('PATH7 Tikhonov-Scaled alpha %.5g chi2 %.5g KKT %.3g conv%d it%d LSQR%d %.1fs\n', ...
   alpha,r,info.kkt,info.converged,info.iterations,info.innerLSQRIterations,t);end
 end
 function v=get(name,default)
  if isfield(p.c,name),v=p.c.(name);else,v=default;end
 end
end
