function [x,info]=revision_pocs_polish(p,x,limit,lambda)
% KKT dual of min 0.5||x||^2 with x>=0, ||B*x-b||^2<=limit.
% Inner: min 0.5||B*x-b||^2+0.5*alpha||x||^2, alpha=1/lambda.
% Matching a feasible active data boundary and bound KKT certifies same POCS
% metric solution; it is an optimizer refinement, not a new regularizer.
% The active-boundary search needs finer inner precision than the main path:
% otherwise a warm-start passes stationarity without moving as alpha changes.
p.c.tolerance=min(p.c.tolerance,2e-8);
alpha=1/max(lambda,realmin);alpha=min(max(alpha,realmin),p.lip);
lo=NaN;hi=NaN;best=[];params=[];res=[];solved=[];iterations=0;
for k=1:16
 s=revision_optimizers('POCS-fixed-ridge',p,struct('alpha',alpha,'x',x));
 x=s.x;iterations=iterations+s.iterations;params(end+1)=alpha;res(end+1)=s.residual;solved(end+1)=s.converged; %#ok<AGROW>
 if isfield(p.c,'revisionTrace')&&p.c.revisionTrace,fprintf('POCS dual alpha %.5g | chi2 %.6g | KKT %.3g | conv %d\n',alpha,s.residual,s.diagnostics.kkt,s.converged);end
 if s.converged&&s.residual<=limit
  lo=alpha;best=s;
  if ~isnan(hi),break;end
  alpha=alpha*10;
 else
  hi=alpha;if ~isnan(lo),break;end
  alpha=alpha/10;
 end
end
if ~isnan(lo)&&~isnan(hi)&&~isempty(best)
 for k=1:14
  alpha=sqrt(lo*hi);s=revision_optimizers('POCS-fixed-ridge',p,struct('alpha',alpha,'x',best.x));
  iterations=iterations+s.iterations;params(end+1)=alpha;res(end+1)=s.residual;solved(end+1)=s.converged; %#ok<AGROW>
  if isfield(p.c,'revisionTrace')&&p.c.revisionTrace,fprintf('POCS dual refine %.5g | chi2 %.6g | KKT %.3g | conv %d\n',alpha,s.residual,s.diagnostics.kkt,s.converged);end
  if s.converged&&s.residual<=limit,lo=alpha;best=s;else,hi=alpha;end
  if best.residual>=limit*(1-2e-3),break;end
 end
end
converged=~isempty(best)&&best.converged&&best.residual<=limit*(1+1e-5)&&best.residual>=limit*(1-2e-3);
info=struct('converged',converged,'iterations',iterations,'alpha',NaN, ...
 'residuals',res,'alphas',params,'candidateConverged',logical(solved), ...
 'algorithm','Bound-dual minimum-bin-mass-norm polishing; projected Newton with exact prior', ...
 'certificate','Original ridge objective KKT and feasible active measurement boundary within 0.2%');
if ~isempty(best),x=best.x;info.alpha=best.parameter;info.kkt=best.diagnostics.kkt;end
end
