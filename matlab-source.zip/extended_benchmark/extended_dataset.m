function result=extended_dataset(c,row,shared)
maxNumCompThreads(c.threadsPerWorker);addpath(c.root,fullfile(c.root,'core'));
k=shared.Value;g=k.g;A=k.A;file=fullfile(c.outputRoot,'datasets',char(row.Dataset+".mat"));
if exist(file,'file'),d=load(file);else
 a=struct('gmdDm',c.pairsNm(row.CaseIndex,1),'gmdDst',c.pairsNm(row.CaseIndex,2), ...
  'gsdDm',c.gsd,'gsdDst',c.gsd,'rho',0,'weight',1);
 [truth,truthInfo]=cdma_truth(g,a,c.totalN);clean=A*truth(:);
 data=extended_noise(clean,row.Relative,row.AbsoluteFraction,row.Seed,c);row.SigmaAbs=data.sigmaAbs;
 d=struct('row',row,'components',a,'truth',truth,'truthInfo',truthInfo, ...
  'data',data,'clean',clean,'solutions',{cell(numel(c.methods),1)},'rows',struct([]),'complete',false);
end
if d.complete,result=[numel(d.rows) sum([d.rows.Converged]) sum(~[d.rows.Success])];return;end
p=cdma_prepare(A,d.data.y,d.data.sigma,g,c,k.scan);
for mi=numel(d.rows)+1:numel(c.methods)
 if exist(fullfile(c.outputRoot,'STOP'),'file'),break;end
 method=c.methods{mi};timer=tic;
 try
  baseline=[];if strcmp(method,'Tikhonov-lsqlin'),baseline=d.solutions{find(strcmp(c.methods,'Tikhonov'))};end
  s=extended_solve(method,p,baseline);r=large_metrics(s.binCounts,d.truth,g,d.components,c.totalN);
  r.Success=true;r.Converged=s.converged;r.Iterations=s.iterations;r.Seconds=s.seconds;
  r.ObjectiveConverged=s.objectiveConverged;r.DataCompatible=s.dataCompatible;
  r.ParameterSelectionValid=s.parameterSelectionValid;r.Validated=s.benchmarkValid;
  r.ConstraintViolation=s.constraintViolation;r.Status=string(s.status);
  r.Parameter=s.parameter;r.Boundary=s.boundary;r.ReducedChi2=s.residual;
  r.MeasurementRelativeL2=norm(A*s.binCounts(:)-d.data.y)/max(norm(d.data.y),eps);r.Error="";
  d.solutions{mi}=s;
 catch err
  r=large_metrics(nan(g.n),d.truth,g,d.components,c.totalN);r.Success=false;r.Converged=false;
  r.Iterations=0;r.Seconds=toc(timer);r.Parameter=NaN;r.Boundary=false;r.ReducedChi2=NaN;
  r.MeasurementRelativeL2=NaN;r.Error=string(err.message);d.solutions{mi}=struct('error',err.message);
  r.ObjectiveConverged=false;r.DataCompatible=false;r.ParameterSelectionValid=false;
  r.Validated=false;r.ConstraintViolation=NaN;r.Status="execution error";
 end
 names=d.row.Properties.VariableNames;for j=1:numel(names),r.(names{j})=d.row.(names{j});end
 r.Method=string(method);r.ClippedFraction=mean(d.data.clipped);
 r.QueueSeconds=0;r.SolverWallSeconds=r.Seconds;
 if r.Success,r.QueueSeconds=s.queueSeconds;r.SolverWallSeconds=s.wallSeconds;end
 r.NegativeMeasurementFraction=mean(d.data.y<0);
 r.AssessmentIncluded=~strcmp(method,'Lognormal-fit');
 r.QualityTargetsPass=r.Success && r.RelativeL2<=.20 && abs(r.TotalRelativeError)<=.05 && ...
  abs(r.GMD_dm_RelativeError)<=.05 && abs(r.GMD_dst_RelativeError)<=.05 && ...
  abs(r.GSD_dm_RelativeError)<=.05 && abs(r.GSD_dst_RelativeError)<=.05;
 r.TargetPass=r.Validated && r.QualityTargetsPass && r.AssessmentIncluded;
 d.rows=[d.rows;r];d.complete=mi==numel(c.methods);
 tmp=[file '.tmp.mat'];save(tmp,'-struct','d','-v7');movefile(tmp,file,'f');
 writetable(struct2table(d.rows),fullfile(c.outputRoot,'metrics',char(row.Dataset+".csv")));
 fprintf('%s | %s | converged=%d | %.1fs\n',row.Dataset,method,r.Converged,r.Seconds);
end
result=[numel(d.rows) sum([d.rows.Validated]) sum(~[d.rows.Success])];
end
