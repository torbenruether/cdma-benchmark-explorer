function extended_tests()
c=extended_config;maxNumCompThreads(1);k=load(c.commonFile);g=k.g;
[m,plan]=extended_plan(c);assert(height(m)==27);assert(height(unique(m(:,{'CaseIndex','AbsoluteFraction','Relative'})))==27);
assert(max(abs(diff(log10(g.edges))-1/64))<1e-14);
for j=1:3
 [T,info]=cdma_truth(g,plan.cases(j).components,c.totalN);
 assert(abs(sum(T(:))/c.totalN-1)<1e-12);assert(info.truncatedFraction<.001);
 mu=k.A*T(:);a=extended_noise(mu,.03,.05,c.seed+j,c);b=extended_noise(mu,.03,.05,c.seed+j,c);
 assert(isequal(a,b));assert(abs(a.sigmaAbs/max(mu)-.05)<1e-15);
 assert(norm(a.raw-mu-a.absoluteNoise-a.relativeNoise)<1e-9);
 z=extended_noise(mu,0,0,c.seed+j,c);assert(isequal(z.y,mu));
end
% Both physical properties are needed to infer dv; transformed cells conserve mass.
x=log(g.dm(g.active));y=log(g.dst(g.active));z=(x+2*y)/3;
assert(max(abs((3*z-x)/2-y))<1e-14);assert(all(y<=z+1e-14 & z<=x+1e-14));
ar=g.area(g.active);mass=T(g.active);
assert(abs(sum(1.5*(mass./ar).*(ar/1.5))-c.totalN)<1e-8);
assert(abs(sum(3*(mass./ar).*(ar/3))-c.totalN)<1e-8);
% Adjoint identity for masked gradients, including half-area diagonal cells.
st=RandStream('mt19937ar','Seed',27);u=randn(st,numel(g.active),1);v=randn(st,size(g.D,1),1);
assert(abs((g.D*u)'*v-u'*(g.D'*v))<1e-9);
fprintf('PASS: 27 factorial cases, 64 bins/decade, truth normalization/tails, paired noise, coordinate mass and adjoint.\n');
% Small inverse problem verifies TGV primal-dual implementation and lsqlin result.
cc=c;cc.nBins=8;cc.rangeNm=[20 1000];gg=cdma_grid(cc);n=numel(gg.active);
AA=sparse(1:n,gg.active,ones(n,1),n,gg.n^2);
tt=cdma_truth(gg,plan.cases(2).components,1e5);yy=AA*tt(:);
pp=cdma_prepare(AA,yy,ones(n,1)*20,gg,cc,table);
pp.c.tgvAlpha=[1e-7 1e-5];pp.c.tgvIterations=10000;
s=extended_solve('TGV2-PDHG',pp);assert(all(s.x>=0));assert(s.residual<1);assert(s.converged);
pp.c.pathMultipliers=[0 1e-4 .1];base=extended_solve('Tikhonov',pp);
s=extended_solve('Tikhonov-lsqlin',pp,base);
assert(s.diagnostics.objective<=s.diagnostics.baselineObjective+1e-6);
fprintf('PASS: TGV saddle convergence and independent lsqlin objective verification on small known operator.\n');
% Exact simplex projection tests normalization and positivity jointly.
z=extended_project([-1;2;3],sparse(ones(1,3)),1,1);
assert(norm(z-[0;0;1])<1e-8);
aux=cc.aux;aux.total=struct('value',100,'sigma',1,'source','test-only external measurement');
[C,lo,hi]=extended_constraints(gg,aux,10);
assert(isequal(size(C),[1 n])&&abs(lo-9.7)<1e-12&&abs(hi-10.3)<1e-12);
fprintf('PASS: optional independent measurement slabs and nonnegative normalization projection.\n');
end
