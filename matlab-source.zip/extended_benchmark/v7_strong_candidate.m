function [x,info]=v7_strong_candidate(p,alpha,method,x)
% EXPERIMENTAL stronger preconditioning of the SAME nonnegative Tikhonov objective.
% No data row rescaling, changed noise floor, eig cutoff, or implicit ridge.
if nargin<4,x=zeros(p.n,1);end
assert(strcmp(method,'Tikhonov')||strcmp(method,'Tikhonov-LSQR-StrongPrecond'));
assert(isfinite(alpha)&&alpha>=0);
if isfield(p,'auxC')
 assert(isempty(p.auxC),'Tikhonov-LSQR-StrongPrecond currently requires no auxiliary measurements.');
elseif isfield(p,'g')&&isfield(p.c,'aux')
 aux=extended_constraints(p.g,p.c.aux,p.scale);
 assert(isempty(aux),'Tikhonov-LSQR-StrongPrecond currently requires no auxiliary measurements.');
end
if isfield(p,'tikhFactor'),L=p.tikhFactor;
else,L=p.g.L/sqrt(max(norm(p.g.L'*p.g.L,inf),eps));end
factorError=norm(L'*L-p.R,'fro')/max(norm(p.R,'fro'),eps);
assert(factorError<1e-10,'Augmented penalty factor does not match the existing Tikhonov objective.');
C=[p.B;sqrt(alpha)*L];b=[p.b;zeros(size(L,1),1)];
columnNorm=sqrt(full(sum(C.^2,1)))';S=ones(p.n,1);
positive=columnNorm>0;S(positive)=1./columnNorm(positive);
assert(all(isfinite(S)),'Augmented column norm cannot be represented.');
rhs=p.B'*p.b;x=max(x,0);[value,gradient,residual]=evaluate(x);
legacyDiagonal=full(sum(p.B.^2,1))'+alpha*full(diag(p.R));
legacyScale=1./sqrt(max(legacyDiagonal,realmin));
cap=get('v7StrongIterations',20);innerCap=get('v7StrongLSQRIterations',300);
solverTimer=tic;wallLimit=get('v7StrongMaxSeconds',120);budgetStopped=false;
qrLimit=get('v7StrongQRLimit',192);lsqrTol=get('v7StrongLSQRTolerance',1e-13);
inner=0;qrSolves=0;lineFailed=false;lsqrFlags=[];iterations=0;
for k=1:cap
 [scaledKKT,originalKKT,legacyKKT,legacyOriginal]=audit(x,gradient);
 if max([scaledKKT,originalKKT,legacyKKT,legacyOriginal])<=p.c.tolerance,break;end
 if toc(solverTimer)>=wallLimit,budgetStopped=true;break;end
 free=(x>1e-15*max(1,norm(x,inf)))|gradient<0;
 if ~any(free),break;end
 cf=C(:,free)*spdiags(S(free),0,nnz(free),nnz(free));
 % Solve the correction using rectangular LS, not C'*C. Sparse regularizer
 % Cholesky is only a right preconditioner; it does not alter the objective.
 if nnz(free)<=qrLimit&&size(cf,1)>=nnz(free)
  [Q,T]=qr(full(cf),0);
  if all(diag(T)~=0)
   q=T\(-Q'*residual);qrSolves=qrSolves+1;flag=0;it=1;
  else,[q,flag,~,it]=lsqr(cf,-residual,lsqrTol,innerCap);end
 else
  diagonalData=full(sum(p.B(:,free).^2,1))'.*S(free).^2;
  cfReg=sqrt(alpha)*L(:,free)*spdiags(S(free),0,nnz(free),nnz(free));
  M=cfReg'*cfReg+spdiags(1e-6*diagonalData+1e-10,0,nnz(free),nnz(free));
  [T,bad]=chol(M);
  if bad==0,[q,flag,~,it]=lsqr(cf,-residual,lsqrTol,innerCap,T);
  else,[q,flag,~,it]=lsqr(cf,-residual,lsqrTol,innerCap);end
 end
 inner=inner+it;lsqrFlags(end+1)=flag; %#ok<AGROW>
 direction=zeros(p.n,1);direction(free)=S(free).*q;
 if any(~isfinite(direction))||gradient'*direction>=0
  direction=-S.^2.*gradient;direction(~free)=0;
 end
 accepted=false;step=1;
 for attempt=1:50
  candidate=max(x+step*direction,0);delta=candidate-x;slope=gradient'*delta;
  % Exact quadratic CHANGE avoids subtracting large almost equal objectives.
  Cdelta=C*delta;change=slope+.5*(Cdelta'*Cdelta);
  if slope<0&&change<=1e-4*slope,accepted=true;break;end
  step=step/2;
 end
 if ~accepted
  direction=-S.^2.*gradient;direction(~free)=0;step=1;
  for attempt=1:50
   candidate=max(x+step*direction,0);delta=candidate-x;slope=gradient'*delta;
   Cdelta=C*delta;change=slope+.5*(Cdelta'*Cdelta);
   if slope<0&&change<=1e-4*slope,accepted=true;break;end
   step=step/2;
  end
 end
 if ~accepted||isequal(candidate,x),lineFailed=true;break;end
 x=candidate;[value,gradient,residual]=evaluate(x);iterations=k;
end
[scaledKKT,originalKKT,legacyKKT,legacyOriginal]=audit(x,gradient);
info=struct('iterations',iterations,'converged',max([scaledKKT,originalKKT,legacyKKT,legacyOriginal])<=p.c.tolerance, ...
 'kkt',legacyKKT,'unscaledKkt',legacyOriginal,'objective',value, ...
 'naturalProjectedKKT',scaledKKT,'naturalOriginalProjectedKKT',originalKKT, ...
 'innerLSQRIterations',inner,'qrSolves',qrSolves,'lsqrFlags',lsqrFlags, ...
 'lineSearchFailed',lineFailed,'budgetStopped',budgetStopped,'seconds',toc(solverTimer), ...
 'penaltyFactorRelativeError',factorError, ...
 'columnScaleRange',[min(S),max(S)],'changedMeasurementWeights',false,'preconditionerDataFraction',1e-6, ...
 'algorithm','Experimental strong regularizer preconditioner (data fraction1e-6); projected augmented LSQR and small-system QR', ...
 'stopping','Exact legacy-v6 masked KKT AND natural projected-gradient mappings in original x; no optimizer exitflag substitution');
 function [f,g,r]=evaluate(u)
  dataResidual=p.B*u-p.b;penalty=L*u;r=[dataResidual;sqrt(alpha)*penalty];
  f=.5*(dataResidual'*dataResidual)+.5*alpha*(penalty'*penalty);
  % p.R provides an independent check of the augmented factor convention.
  g=p.B'*dataResidual+alpha*(p.R*u);
 end
 function [scaled,original,legacy,legacyUnscaled]=audit(u,g)
  % Natural residual for a positive diagonal variable transform. It treats
  % near-bound positive variables continuously rather than classifying
  % every tiny interior-point coordinate as an unconstrained direction.
  mapped=min(u./S,S.*g);
  scaled=norm(mapped,inf)/max(1,norm(S.*rhs,inf));
  original=norm(min(u,g),inf)/max(1,norm(rhs,inf));
  % EXACT v6 Tikhonov masked-gradient certificate, mandatory in addition.
  free=u>1e-13*max(1,norm(u,inf))|g<0;pg=g;pg(~free)=0;
  legacy=norm(legacyScale.*pg,inf)/max(1,norm(legacyScale.*rhs,inf));
  legacyUnscaled=norm(pg,inf)/max(1,norm(rhs,inf));
 end
 function v=get(name,default)
  if isfield(p.c,name),v=p.c.(name);else,v=default;end
 end
end
