function s=v6_smooth_path(method,p,solve)
% Measurement-only adaptive discrepancy path; preliminary values are not certificates.
% V9 integrates V8's beta=1e-3 adaptive augmented LSQR for Tikhonov, including
% alpha=0 pilots, and requires a strict feasible-dual gap for every such candidate.
assert(ismember(method,{'Tikhonov','Maximum Entropy','Huber-TV'}));
coarse=p;coarse.c.revisionNewtonIterations=cfg('revisionPathNewtonIterations',40);
coarse.c.revisionPCGIterations=cfg('revisionPathPCGIterations',100);
refined=p;refined.c.revisionNewtonIterations=cfg('revisionSelectedNewtonIterations',400);
coarse.c.v9SmoothIterations=cfg('v9SmoothPathIterations',20);
coarse.c.v9SmoothLSQRIterations=cfg('v9SmoothPathLSQRIterations',cfg('v9SmoothLSQRIterations',300));
coarse.c.v9SmoothMaxSeconds=cfg('v9SmoothPathMaxSeconds',25);
refined.c.v9SmoothIterations=cfg('v9SmoothSelectedIterations',80);
refined.c.v9SmoothLSQRIterations=cfg('v9SmoothSelectedLSQRIterations',cfg('v9SmoothLSQRIterations',300));
refined.c.v9SmoothMaxSeconds=cfg('v9SmoothSelectedMaxSeconds',120);
x=p.zero;if isfield(p,'revisionWarmStart'),x=max(p.revisionWarmStart,0);end
params=[];xs={};infos={};residual=[];total=0;
run(0,x,false,'Tikhonov');pilot=xs{1};
D=1./sqrt(max(p.diagQ,max(max(p.diagQ),1)*1e-14));
switch method
 case 'Tikhonov',rg=p.R*pilot;fallback=p.lip;
 case 'Maximum Entropy'
  u=max(pilot,1e-10*max(sum(pilot),1)*p.priorMass);rg=log(u./(p.priorMass*sum(u)));fallback=p.lip/p.n;
 case 'Huber-TV'
  z=p.D*pilot;rg=p.D'*(z./hypot(1,z/(.03/p.n)));fallback=p.lip/.03;
end
den=norm(D.*rg,inf);scale=norm(D.*p.rhs,inf)/max(den,realmin);
if ~isfinite(scale)||den<=1e-16||scale<=0,scale=max(fallback,eps);end
initial=sort(unique(scale*p.c.pathMultipliers(p.c.pathMultipliers>0)));
initial=initial(:)'; % MATLAB for loops iterate columns, including empty columns.
if isempty(initial)
 assert(strcmp(method,'Tikhonov'),'A positive regularization candidate is required for %s.',method);
 [xx,info]=candidate(refined,0,'Tikhonov',pilot);r=norm(p.B*xx-p.b)^2;
 s=struct('x',xx,'converged',info.converged,'iterations',total+info.iterations, ...
  'parameter',0,'boundary',true,'selection','Explicit NNLS-only diagnostic control', ...
  'diagnostics',struct('parameters',0,'residuals',r,'selectedIndex',1, ...
  'selectableParameters',0,'candidateConverged',info.converged, ...
  'selectedSolver',info,'targetBracketed',false,'selectionValid',false, ...
  'alphaScale',scale,'alphaScalePolicy','NNLS-only diagnostic; no regularization selection', ...
  'parameterSelectionUsesConvergedCandidates',info.converged));
 return;
end
for a=initial
 run(a,xs{end},false,method);
 if numel(residual)>2&&all(residual(end-1:end)>p.target),break;end
end
% Upper extension is essential for bounded Huber gradients; do not stop at an
% old arbitrary grid edge or silently substitute alpha=0 under its method name.
for retry=1:cfg('revisionAlphaExtensions',6)
 if max(residual)>p.target,break;end
 run(max(params)*10,xs{end},false,method);
end
positive=find(params>0);[amin,ii]=min(params(positive));imin=positive(ii);
for retry=1:cfg('revisionAlphaExtensions',6)
 if any(residual(positive)<=p.target),break;end
 amin=amin/10;run(amin,xs{imin},false,method);imin=numel(params);positive=find(params>0);
end
% Certify the closest preliminary candidates before using them for selection.
eligible=find(params>0);if strcmp(method,'Tikhonov'),eligible=1:numel(params);end
[~,near]=sort(abs(log(max(residual(eligible),realmin)/p.target)));
for ii=1:min(3,numel(near)),certify(eligible(near(ii)));end
for retry=1:cfg('revisionAlphaRefinements',5)
 solved=find(cellfun(@(q)q.converged,infos));
 low=solved(residual(solved)<=p.target);high=solved(residual(solved)>=p.target&params(solved)>0);
 if isempty(low)||isempty(high),break;end
 [alo,il]=max(params(low));lo=low(il);[ahi,ih]=min(params(high));hi=high(ih);
 if alo>=ahi,break;end
 if alo==0,a=ahi/10;else,a=sqrt(alo*ahi);end
 run(a,xs{lo},true,method);
 if infos{end}.converged&&abs(log(residual(end)/p.target))<.03,break;end
end
[params,order]=sort(params);xs=xs(order);infos=infos(order);residual=residual(order);
eligible=find(params>0);if strcmp(method,'Tikhonov'),eligible=1:numel(params);end
qualified=intersect(eligible,find(cellfun(@(q)q.converged,infos)));
selectable=qualified;if isempty(selectable),selectable=eligible;end
[~,best]=min(abs(log(max(residual(selectable),realmin)/p.target)));j=selectable(best);
solved=find(cellfun(@(q)q.converged,infos));
bracket=~isempty(solved)&&min(residual(solved))<=p.target&&max(residual(solved))>=p.target;
s=struct('x',xs{j},'converged',infos{j}.converged,'iterations',total, ...
 'parameter',params(j),'boundary',j==eligible(1)||j==eligible(end), ...
 'selection','Morozov: data-scaled pilot, adaptive alpha bounds, certified crossing refinement', ...
 'diagnostics',struct('parameters',params,'residuals',residual,'selectedIndex',j, ...
 'selectableParameters',params(eligible),'candidateConverged',cellfun(@(q)q.converged,infos), ...
 'selectedSolver',infos{j},'targetBracketed',bracket, ...
 'selectionValid',infos{j}.converged&&bracket&&abs(log(max(residual(j),realmin)/p.target))<=.05, ...
 'alphaScale',scale,'alphaScalePolicy','Equilibrated data RHS / pilot penalty gradient; no truth', ...
 'parameterSelectionUsesConvergedCandidates',~isempty(qualified)));
 function run(a,start,full,objective)
  pp=coarse;if full,pp=refined;end
  timer=tic;[xx,info]=candidate(pp,a,objective,start);r=norm(p.B*xx-p.b)^2;
  params(end+1)=a;xs{end+1}=xx;infos{end+1}=info;residual(end+1)=r;total=total+info.iterations;
  trace(a,info,r,toc(timer));
 end
 function certify(index)
  if infos{index}.converged,return;end
  objective=method;if params(index)==0,objective='Tikhonov';end
  timer=tic;[xx,info]=candidate(refined,params(index),objective,xs{index});total=total+info.iterations;
  if info.objective<=infos{index}.objective+1e-10*max(1,abs(infos{index}.objective))
   xs{index}=xx;infos{index}=info;residual(index)=norm(p.B*xx-p.b)^2;
  end
  trace(params(index),infos{index},residual(index),toc(timer));
 end
 function [xx,info]=candidate(pp,a,objective,start)
  if strcmp(objective,'Tikhonov')
   settings=struct('beta',cfg('v9SmoothBeta',1e-3),'adaptive',true, ...
    'earlyTolerance',cfg('v9SmoothEarlyInnerTolerance',1e-7), ...
    'finalTolerance',cfg('v9SmoothFinalInnerTolerance',1e-13), ...
    'damping',1e-10,'qrLimit',cfg('v9SmoothQRLimit',64), ...
    'maxIterations',pp.c.v9SmoothIterations,'maxLSQRIterations',pp.c.v9SmoothLSQRIterations, ...
    'maxSeconds',pp.c.v9SmoothMaxSeconds);
   [xx,info]=v9_smooth_candidate(pp,a,start,settings);
   % Re-audit at the selection boundary. Neither a normalized KKT flag nor
   % an uncertified alpha=0 reference may enter a discrepancy bracket.
   cert=v9_tikhonov_strict_certificate(pp,a,xx);
   info.strictCertificate=cert;info.relativeDualGap=cert.relativeGap;
   info.converged=info.converged&&cert.converged;
  else
   [xx,info]=solve(pp,a,objective,start);
  end
 end
 function trace(a,info,r,time)
  if cfg('revisionTrace',false),fprintf('PATH6 %s alpha=%.5g chi2=%.5g kkt=%.3g conv=%d it=%d %.2fs\n', ...
   method,a,r,info.kkt,info.converged,info.iterations,time);end
 end
 function v=cfg(name,default)
  if isfield(p.c,name),v=p.c.(name);else,v=default;end
 end
end
