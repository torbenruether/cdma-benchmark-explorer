function [f,g,x]=v7_pocs_objective(w,C,lo,hi)
% C1 convex bound dual; alpha/beta are nonnegative upper/lower multipliers.
q=size(C,1);signed=w(1:q)-w(q+1:end);x=max(-C'*signed,0);y=C*x;
f=.5*(x'*x)+hi'*w(1:q)-lo'*w(q+1:end);
if nargout>1,g=[hi-y;y-lo];end
end
