function v6_optimizer_tests()
% Root executes this bounded fixture; this module never launches MATLAB.
c=extended_config;maxNumCompThreads(1);c.nBins=6;c.rangeNm=[20 1000];
c.pathMultipliers=[0 logspace(-5,3,9)];c.revisionAlphaRefinements=6;
c.revisionPathNewtonIterations=40;c.revisionPathPCGIterations=60;
c.revisionSelectedNewtonIterations=250;c.revisionPCGIterations=120;c.revisionTrace=false;
c.aux=struct('total',[],'dm',[],'dst',[],'tolerance',[]);
g=cdma_grid(c);n=numel(g.active);A=sparse(1:n,g.active,ones(n,1),n,g.n^2);
comp=struct('gmdDm',315,'gmdDst',60,'gsdDm',1.3,'gsdDst',1.3,'rho',0,'weight',1);
truth=cdma_truth(g,comp,1e5);y=A*truth(:);p=cdma_prepare(A,y,ones(n,1)*20,g,c,table);
methods={'Tikhonov','Maximum Entropy','Huber-TV'};results=struct([]);
for j=1:numel(methods)
 s=revision_optimizers(methods{j},p);
 assert(all(isfinite(s.x))&&all(s.x>=0));
 assert(s.converged,'v6 objective stationarity failed: %s',methods{j});
 assert(s.diagnostics.selectionValid,'v6 discrepancy crossing not certified: %s',methods{j});
 if ~strcmp(methods{j},'Tikhonov'),assert(s.parameter>0);end
 results=[results;struct('method',methods{j},'parameter',s.parameter,'chi2',s.residual, ...
  'kkt',s.diagnostics.selectedSolver.kkt,'seconds',s.seconds)]; %#ok<AGROW>
end
% Previously column-normalized weak channels could receive ~1e12 times the
% actual mass. Check the new bin-mass metric and conservative smoothing.
weak=p;weak.B=sparse(1,[1 2],[1 1e-12],1,n);weak.b=10;
weak.m=1;weak.rhs=weak.B'*weak.b;weak.diagQ=full(sum(weak.B.^2,1))';weak.lip=1;
weak.scale=1;weak.y=10;weak.sigma=1;
tw=revision_optimizers('Twomey-Markowski',weak);
assert(tw.converged&&tw.residual<=1+1e-8);assert(sum(tw.x)<=10.00001);
% Independent small bound-quadratic reference for selected GP dual polishing.
Q=[2 .3 .1;.3 1 .2;.1 .2 .5];f=[-1;.2;-.3];d=1./sqrt(diag(Q));
[mu,polish]=v6_gp_polish(@(v)Q*v,f,d,zeros(3,1),@audit,c);
opt=optimoptions('quadprog','Display','off','OptimalityTolerance',1e-10);
reference=quadprog(Q,f,[],[],[],[],zeros(3,1),[],[],opt);
assert(polish.converged&&norm(mu-reference)<1e-5,'GP dual projected-Newton reference mismatch');
[muLB,lbfgs]=v6_gp_lbfgs(@(v)Q*v,f,d,zeros(3,1),@audit,c);
assert(lbfgs.converged&&norm(muLB-reference)<1e-5,'GP matrix-free L-BFGS reference mismatch');
save(fullfile(c.root,'v6_optimizer_fixture_results.mat'),'results','tw','mu','polish','reference','muLB','lbfgs','-v7');
fprintf('PASS v6 optimizer fixtures: certified three-prior paths, weak-column Twomey mass, independent GP dual quadratic.\n');
 function [kkt,impact]=audit(mult,grad)
  pg=grad;pg(mult<=1e-12&grad>0)=0;kkt=norm(pg,inf);impact=0;
 end
end
