function coordinate_study()
% Limited direct basis comparison on SAME data; no information gain assumed.
% Conservative overlap quadrature maps uniform transformed cells back to the
% original physical domain. New regularization is isotropic in its own axes.
c=extended_config;maxNumCompThreads(1);k=load(c.commonFile);g=k.g;
d=load(fullfile(c.root,'outputs','pilot','datasets','ds00005.mat'));
base=d.solutions{3};rows=struct([]);solutions=cell(2,1);
for mode=1:2
 [W,area]=mapping(g,mode,24);[Wfine,~]=mapping(g,mode,48);
 gg=customgrid(c,area);At=k.A(:,g.active)*W;
 mismatch=norm(At-k.A(:,g.active)*Wfine,'fro')/norm(At,'fro');
 Afull=sparse(size(At,1),g.n^2);Afull(:,gg.active)=At;
 p=cdma_prepare(Afull,d.data.y,d.data.sigma,gg,c,k.scan);
 s=extended_solve('Tikhonov',p);X=zeros(g.n);X(g.active)=W*s.binCounts(gg.active);
 names={'dm-dv','dv-dst'};r=large_metrics(X,d.truth,g,d.components,c.totalN);r.Coordinates=string(names{mode});
 r.Converged=s.converged;r.Seconds=s.seconds;r.Residual=s.residual;r.OverlapQuadratureDifference=mismatch;
 rb=large_metrics(base.binCounts,d.truth,g,d.components,c.totalN);r.BaselineRelativeL2=rb.RelativeL2;
 r.BaselineConverged=base.converged;r.NewUnknowns=numel(gg.active);
 rows=[rows;r];solutions{mode}=s; %#ok<AGROW>
 writetable(struct2table(rows),fullfile(c.root,'coordinate_study.csv'));
 save(fullfile(c.root,'coordinate_study.mat'),'rows','solutions');
end
end
function [W,area]=mapping(g,mode,q)
n=g.n;ix=g.active;h=g.h(1);a0=log(g.edges(1));
x0=log(g.dm(ix))-h/2;y0=log(g.dst(ix))-h/2;diag=g.diagonal(ix);
N=numel(ix);rows=repmat((1:N)',q*q,1);cols=zeros(N*q*q,1);val=repmat(g.area(ix)/(q*q),q*q,1);offset=0;
for i=1:q,for j=1:q
 u=(i-.5)/q;v=(j-.5)/q;x=x0+h*u;y=y0+h*v;
 x(diag)=x0(diag)+h*sqrt(u);y(diag)=y0(diag)+h*sqrt(u)*v;
 z=(x+2*y)/3;
 if mode==1,b=x;a=z;else,b=z;a=y;end
 im=min(n,max(1,floor((b-a0)/h)+1));ia=min(n,max(1,floor((a-a0)/h)+1));
 cols(offset+(1:N))=ia+(im-1)*n;offset=offset+N;
end,end
O=sparse(rows,cols,val,N,n*n);colArea=full(sum(O,1))';active=find(colArea>0);
W=O(:,active)*spdiags(1./colArea(active),0,numel(active),numel(active));
assert(max(abs(full(sum(W,1))-1))<1e-12);
jac=1.5;if mode==2,jac=3;end
area=reshape(colArea/jac,n,n);
end
function gg=customgrid(c,area)
% Same finite-difference construction as cdma_grid with clipped cell areas.
gg=cdma_grid(c);gg.area=area;gg.allowed=area>0;gg.active=find(gg.allowed);n=gg.n;h=gg.h(1);
E=spdiags([-ones(n,1) ones(n,1)],[0 1],n-1,n)/h;
Da=inside(kron(speye(n),E));Dm=inside(kron(E,speye(n)));gg.D=[Da;Dm];
E2=spdiags([ones(n,1) -2*ones(n,1) ones(n,1)],[0 1 2],n-2,n)/h^2;
S=spdiags(h^2./area(gg.active),0,numel(gg.active),numel(gg.active));gg.densityScale=S;
gg.L=inside([kron(speye(n),E2);kron(E2,speye(n))])*S;
F=[E;sparse(1,n)];Ga=kron(speye(n),F);Gm=kron(F,speye(n));
Ga(any(Ga(:,~gg.allowed(:))~=0,2),:)=0;Gm(any(Gm(:,~gg.allowed(:))~=0,2),:)=0;
gg.Ga=Ga(gg.active,gg.active)*S;gg.Gm=Gm(gg.active,gg.active)*S;
 function R=inside(R),R=R(~any(R(:,~gg.allowed(:))~=0,2),gg.active);end
end
