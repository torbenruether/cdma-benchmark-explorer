function s=v6_tv_solver(p)
s=v6_graph_path(p,1);
end
