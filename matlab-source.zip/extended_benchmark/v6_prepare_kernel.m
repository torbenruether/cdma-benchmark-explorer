function v6_prepare_kernel
% Reuse the previously computed stationary 1224-row operator; verify its layout.
c=extended_config;parent=fileparts(c.root);
base=fullfile(fileparts(parent),'outputs','mono_first_64bpd_20261005','common.mat');
operator=fullfile(parent,'measurement_design','new_24x48_kernel.mat');
assert(exist(base,'file')==2 && exist(operator,'file')==2,'Required cached physics not found');
k=load(base);q=load(operator);k.A=q.Anew;k.scan=q.scanNew;k.info=q.info;
assert(k.g.n==108 && numel(k.g.active)==5886 && size(k.A,1)==1224);
assert(size(k.A,2)==k.g.n^2 && all(isfinite(nonzeros(k.A))) && all(nonzeros(k.A)>=0));
assert(nnz(k.A(:,~k.g.allowed(:)))==0,'Operator leaks outside physical support');
u=k.scan.Voltage_V;h=k.scan.Rotation_Hz;
assert(numel(unique(u(u>0)))==24 && numel(unique(h(h>0)))==48);
assert(nnz(u>0 & h>0)==1152 && nnz(u>0 & h==0)==24 && nnz(u==0 & h>0)==48);
assert(~any(u==0 & h==0) && height(unique(k.scan,'rows'))==1224);
assert(all(abs(diff(log10(k.g.centres))-1/64)<1e-12));
assert(max(abs(full(sum(k.A,2))))>0 && c.quadrature==6);
k.provenance=struct('baseCommon',base,'operator',operator,'rows',1224, ...
 'description','24x48 positive settings +24 zero-rotation +48 zero-voltage controls; stationary kernel; no scan/delay model');
if ~exist(fileparts(c.commonFile),'dir'),mkdir(fileparts(c.commonFile));end
save(c.commonFile,'-struct','k','-v7.3');
writetable(k.scan,fullfile(c.root,'measurement_plan_1224.csv'));
fprintf('PASS: 1224 stationary measurements, 64 bins/decade, 5886 physical bin masses.\n');
end
