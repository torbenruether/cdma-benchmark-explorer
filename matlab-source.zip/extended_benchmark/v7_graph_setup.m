function t=v7_graph_setup(p)
% Full two-block TV saddle operator. Same Ga/Gm density TV as v6.
% Diagonal preconditioners: Pock & Chambolle, ICCV 2011, alpha=1.
t.n=p.n;t.m=p.m;t.reg=p.m+(1:2*p.n);t.data=1:p.m;
t.C=sparse(0,p.n);t.lo=[];t.hi=[];
if isfield(p,'auxC')&&~isempty(p.auxC)
 t.C=p.auxC;t.lo=p.auxLo(:);t.hi=p.auxHi(:);
 assert(all(isfinite(t.lo))&&all(isfinite(t.hi))&&all(t.lo<=t.hi), ...
  'TV-PD: auxiliary slabs must have finite, ordered bounds.');
end
t.slabs=p.m+2*p.n+(1:size(t.C,1));
t.K=[p.B;p.Ga;p.Gm;t.C];
cols=full(sum(abs(t.K),1))';rows=full(sum(abs(t.K),2));
cols(cols==0)=1;rows(rows==0)=1;t.tx=.98./cols;t.sy=.98./rows;
% Isotropic ball projection is exact only for equal steps within each group.
% Reducing both component steps preserves the preconditioning bound.
ss=min(t.sy(p.m+(1:p.n)),t.sy(p.m+p.n+(1:p.n)));
t.sy(t.reg)=[ss;ss];t.sqrtTx=sqrt(t.tx);t.sqrtSy=sqrt(t.sy);
t.positiveDirection=p.B'*ones(p.m,1);
t.rhsInf=max(1,norm(p.B'*p.b,inf));
t.tolerance=p.c.tolerance;t.cap=p.c.tvIterations;
if isfield(p.c,'pdIterations'),t.cap=p.c.pdIterations;end
assert(all(isfinite(t.tx))&&all(t.tx>0)&&all(isfinite(t.sy))&&all(t.sy>0));
end
