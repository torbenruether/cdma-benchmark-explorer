function [release,queueSeconds]=v6_heavy_qp_lock
% Run-specific OS mutex: serialize memory-heavy QPs without stale file locks.
assert(ispc,'This benchmark launcher is configured for Windows');
mutex=System.Threading.Mutex(false,'Local\CDMA_v6_SlabQP_20261005');timer=tic;
try
 mutex.WaitOne();
catch err
 % Windows grants ownership when the previous holder terminated unexpectedly.
 if ~contains(err.message,'AbandonedMutex'),mutex.Dispose();rethrow(err);end
end
queueSeconds=toc(timer);release=onCleanup(@unlock);
 function unlock
  try,mutex.ReleaseMutex();catch,end
  mutex.Dispose();
 end
end
