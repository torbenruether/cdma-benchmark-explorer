function start_validated_full()
c=extended_config;folder=fullfile(c.outputRoot,'datasets');if ~exist(folder,'dir'),mkdir(folder);end
target=fullfile(folder,'ds00005.mat');
if ~exist(target,'file')
 d=load(fullfile(c.root,'outputs','pilot','datasets','ds00005.mat'));
 % Preserve ONLY five validated unchanged arms; later pilot arm used old cached function.
 assert(numel(d.rows)>=5 && all([d.rows(1:5).Success]));
 d.rows=d.rows(1:5);d.solutions(6:end)={[]};d.complete=false;
 save(target,'-struct','d','-v7');
end
run_extended_benchmark('full');
end
