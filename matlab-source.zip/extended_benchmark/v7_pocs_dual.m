function s=v7_pocs_dual(p)
% Separate POCS-CDMA-Dual optimizer for the IDENTICAL convex norm projection.
% No call to the large primal quadprog, no truth-derived constraints.
timer=tic;budgetStopped=false;maxSeconds=getcfg('v7POCSDualMaxSeconds',120);
assert(isscalar(maxSeconds)&&isreal(maxSeconds)&&maxSeconds>=0, ...
 'v7:InvalidPOCSTimeBudget','Time budget must be a nonnegative scalar; Inf disables it.');
if ~isfield(p,'auxC'),[p.auxC,p.auxLo,p.auxHi]=extended_constraints(p.g,p.c.aux,p.scale);end
kappa=sqrt(2)*erfcinv(.05/p.m);width=kappa/sqrt(p.m);
C=[p.B;p.auxC];lo=[p.b-width;p.auxLo];hi=[p.b+width;p.auxHi];
norms=sqrt(full(sum(C.^2,2)));zero=norms==0;
incompatible=zero&(lo>0|hi<0);
if any(incompatible)
 s=pack(p.zero,false,0,struct('infeasibleCertified',true, ...
  'status','Exact original zero-row band excludes zero', ...
  'incompatibleRows',find(incompatible),'certificate',struct));return;
end
C=C(~zero,:);lo=lo(~zero);hi=hi(~zero);norms=norms(~zero);
C=spdiags(1./norms,0,numel(norms),numel(norms))*C;
lo=lo./norms;hi=hi./norms;q=size(C,1);z=zeros(2*q,1);
L=max(2*norm(C,1)*norm(C,inf),1e-12);iterations=0;
% Bound dual: phi=.5||[C'*(beta-alpha)]_+||^2 + hi'*alpha-lo'*beta.
% Smooth C1 convex objective with exact analytic gradient, nonnegative bounds.
warm=getcfg('v7POCSDualWarmup',100);a=1;momentum=z;[f,~]=objective(z);
for k=1:warm
 if expired(),break;end
 [fq,gq]=objective(momentum);
 for bt=1:30
  trial=max(momentum-gq/L,0);[ft,~]=objective(trial);delta=trial-momentum;
  if ft<=fq+gq'*delta+.5*L*(delta'*delta)+16*eps*max(1,abs(fq)),break;end
  L=2*L;
 end
 if ft>f+16*eps*max(1,abs(f)),momentum=z;a=1;continue;end
 an=(1+sqrt(1+4*a*a))/2;momentum=trial+(a-1)/an*(trial-z);z=trial;a=an;f=ft;
 iterations=iterations+1;
 [accepted,certificate,x]=certify(z);
 if accepted,s=pack(x,true,iterations,struct('certificate',certificate, ...
   'stage','Projected accelerated dual warmup','infeasibleCertified',false));return;end
end
newtonCap=getcfg('v7POCSDualNewtonIterations',220);
[z,ni,newtonInfo]=newton(z,newtonCap);iterations=iterations+ni;
[accepted,certificate,x]=certify(z);
lbfgs=struct('used',false,'exitflag',NaN,'iterations',0);
if ~accepted&&~expired()&&exist('fmincon','file')==2&&getcfg('v7POCSDualLBFGSIterations',250)>0
 lbfgs.used=true;
 try
  opts=optimoptions('fmincon','Algorithm','interior-point', ...
   'SpecifyObjectiveGradient',true,'HessianApproximation','lbfgs', ...
   'SubproblemAlgorithm','cg','Display','off','UseParallel',false, ...
   'MaxIterations',getcfg('v7POCSDualLBFGSIterations',250), ...
   'MaxFunctionEvaluations',5000,'OptimalityTolerance',1e-12, ...
   'ConstraintTolerance',1e-12,'StepTolerance',1e-14,'OutputFcn',@timeguard);
  [zz,ff,flag,out]=fmincon(@objective,z,[],[],[],[],zeros(2*q,1),[],[],opts);
  [oldf,~]=objective(z);
  if all(isfinite(zz))&&ff<=oldf+16*eps*max(1,abs(oldf)),z=max(zz,0);end
  lbfgs.exitflag=flag;lbfgs.iterations=out.iterations;lbfgs.message=out.message;
  iterations=iterations+out.iterations;
 catch err
  lbfgs.message=[err.identifier ': ' err.message];
 end
 [z,ni,polishInfo]=newton(z,getcfg('v7POCSDualPolishIterations',120));
 iterations=iterations+ni;newtonInfo.polish=polishInfo;
 [accepted,certificate,x]=certify(z);
end
diagnostics=struct('certificate',certificate,'newton',newtonInfo, ...
 'lbfgs',lbfgs,'dualVariables',2*q,'primalVariables',p.n, ...
 'stage','Bound dual: projected warmup, matrix-free generalized Newton/PCG, optional L-BFGS', ...
 'infeasibleCertified',false,'rowNormScaling',true);
s=pack(x,accepted,iterations,diagnostics);

 function [f,g,x]=objective(w)
  [f,g,x]=v7_pocs_objective(w,C,lo,hi);
 end

 function [w,k,info]=newton(w,cap)
  pcgFailures=0;lineSearchFailures=0;k=0;
  for j=1:cap
   if expired(),break;end
   k=j;[ok,~,~]=certify(w);if ok,break;end
   [fv,grad,xx]=objective(w);
   free=w>1e-14*max(1,norm(w,inf))|grad<0;pg=grad;pg(~free)=0;
   if ~any(free),break;end
   positive=xx>0;diagH=full((C.^2)*double(positive));diagH=[diagH;diagH];
   damp=max(1e-13,1e-10*max(diagH));d=diagH(free)+damp;
   forcing=max(1e-10,min(.05,sqrt(norm(pg,inf)/max(1,norm([hi;lo],inf)))));
   op=@(v)hessian(v,free,positive,damp);
   [step,flag]=pcg(op,-grad(free),forcing,getcfg('v7POCSDualPCGIterations',350),@(v)v./d);
   direction=zeros(2*q,1);direction(free)=step;
   if flag~=0,pcgFailures=pcgFailures+1;end
   if any(~isfinite(direction))||grad'*direction>=0
    direction=-pg/L;
   end
   acceptedStep=false;t=1;
   for ls=1:45
    candidate=max(w+t*direction,0);[fc,~]=objective(candidate);
    if isfinite(fc)&&fc<=fv+1e-4*grad'*(candidate-w)+16*eps*max(1,abs(fv))
     w=candidate;acceptedStep=true;break;
    end
    t=t/2;
   end
   if ~acceptedStep
    lineSearchFailures=lineSearchFailures+1;
    candidate=max(w-grad/L,0);[fc,~]=objective(candidate);
    if fc<=fv+16*eps*max(1,abs(fv)),w=candidate;else,break;end
   end
  end
  [~,grad]=objective(w);pg=grad;pg(w<=0&grad>0)=0;
  info=struct('iterations',k,'pcgFailures',pcgFailures,'lineSearchFailures',lineSearchFailures, ...
   'boundProjectedGradient',norm(pg,inf),'generalizedHessian','A*diag(x>0)*A''; matrix-free, damping only in Newton direction');
 end

 function y=hessian(v,free,positive,damp)
  temp=zeros(2*q,1);temp(free)=v;
  h=C*((C'*(temp(1:q)-temp(q+1:end))).*positive);hh=[h;-h];
  y=hh(free)+damp*v;
 end

 function [ok,cert,x]=certify(w)
  signed=w(1:q)-w(q+1:end);x=max(-C'*signed,0);cx=C*x;
  primal=.5*(x'*x);dual=-primal-hi'*w(1:q)+lo'*w(q+1:end);
  gap=(primal-dual)/max(1,primal);
  station=norm(x-max(-C'*signed,0))/max(1,norm(x));
  standard=max(abs(sqrt(p.m)*(p.B*x-p.b)));
  auxViolation=max([0;-x;p.auxLo-p.auxC*x;p.auxC*x-p.auxHi]);
  violation=max([0;-x;lo-cx;cx-hi]);
  [~,gradient]=objective(w);pg=gradient;pg(w<=0&gradient>0)=0;
  naturalKKT=norm(w-max(w-gradient,0),inf)/max(1,norm(w,inf));
  cert=struct('primalObjective',primal,'dualObjective',dual,'relativeDualGap',gap, ...
   'relativeStationarity',station,'normalizedSlabViolation',violation, ...
   'maxStandardizedResidual',standard,'auxiliaryConstraintViolation',auxViolation, ...
   'boundProjectedGradient',norm(pg,inf),'relativeBoundKKT',naturalKKT);
  ok=all(isfinite(x))&&all(isfinite([gap,standard,auxViolation]))&& ...
   gap>=-1e-9&&gap<=p.c.tolerance&&station<=p.c.tolerance&&naturalKKT<=p.c.tolerance&& ...
   violation<=1e-9&&standard<=kappa*(1+1e-5)&&auxViolation<=1e-9;
 end

 function ss=pack(x,ok,it,diagnostics)
  standard=max(abs(sqrt(p.m)*(p.B*x-p.b)));
  diagnostics.bandMultiplier=kappa;diagnostics.bandsSatisfied=standard<=kappa*(1+1e-5);
  diagnostics.maxStandardizedResidual=standard;
  diagnostics.physicalSupport='Only dst<=dm active bins; no support threshold';
  diagnostics.regularizingPrior='Euclidean nearest-to-zero bin concentrations; identical to POCS-CDMA';
  diagnostics.selectionValid=true;
  diagnostics.budgetStopped=budgetStopped;diagnostics.timeBudgetSeconds=maxSeconds;
  diagnostics.auxiliaryConstraintViolation=max([0;-x;p.auxLo-p.auxC*x;p.auxC*x-p.auxHi]);
  if ~isfield(diagnostics,'status')
   if ok,diagnostics.status='Original primal feasibility and bound-dual optimum certified';
   elseif budgetStopped,diagnostics.status='Wall-clock budget stopped; optimum not certified';
   else,diagnostics.status='Iteration/numerical limit; optimum not certified';end
  end
  ss=struct('x',x,'iterations',it,'converged',ok,'parameter',kappa, ...
   'selection','Same simultaneous 95% Gaussian bands as POCS-CDMA; bound-dual optimizer variant', ...
   'boundary',false,'residual',norm(p.B*x-p.b)^2,'diagnostics',diagnostics,'seconds',toc(timer));
 end

 function value=getcfg(name,fallback)
  if isfield(p.c,name),value=p.c.(name);else,value=fallback;end
 end

 function stopped=expired()
  stopped=toc(timer)>=maxSeconds;
  if stopped,budgetStopped=true;end
 end

 function stop=timeguard(~,~,~)
  % R2021a-compatible callback; no newer MaxTime option required.
  stop=expired();
 end
end
