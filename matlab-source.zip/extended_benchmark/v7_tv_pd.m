function s=v7_tv_pd(p)
% Separate experimental optimiser arm; fixed-alpha TV is unchanged.
s=v7_graph_path(p);
end
