function s=extended_solve(method,p,baseline)
if nargin<3,baseline=[];end
t=tic;
queueSeconds=0;
if strcmp(method,'Tikhonov-lsqlin')
 [memoryGuard,queueSeconds]=v6_heavy_qp_lock; %#ok<NASGU>
end
[p.auxC,p.auxLo,p.auxHi]=extended_constraints(p.g,p.c.aux,p.scale);
if ~isempty(p.auxC) && ~ismember(method,{'POCS-PSS','POCS-CDMA','TGV2-PDHG','TGV2-ADMM','Tikhonov-lsqlin','POCS-CDMA-Dual','TV-PD','TV-Morozov-PD'})
 error('Auxiliary constraints are supported by POCS-PSS, TGV2 and lsqlin only; this arm is not comparable with extra data.');
end
switch method
 case 'Tikhonov-Scaled'
  s=v7_smooth_tikhonov(p);
 case 'Tikhonov-LSQR-StrongPrecond'
  s=v7_strong_tikhonov(p);
 case 'POCS-CDMA-Dual'
  s=v7_pocs_dual(p);
 case {'TV-PD','TV-Morozov-PD'}
  s=v7_tv_solve(method,p);
 case {'Tikhonov','Tikhonov-lsqlin','Maximum Entropy','Huber-TV','TV-2D','Twomey-Markowski'}
  s=revision_optimizers(method,p,baseline);
 case 'POCS-CDMA'
  s=v9_pocs(p);
 case 'POCS-PSS'
  s=revision_pocs(method,p);
 case 'Lognormal-fit'
  s=extended_lognormal(p);
 case {'TGV2-PDHG','TGV2-ADMM'}
  s=extended_tgv(p);
 otherwise
  s=cdma_solve(method,p);
end
if ismember(method,{'Tikhonov','Tikhonov-lsqlin'}) && isempty(p.auxC)
 certificate=v9_tikhonov_strict_certificate(p,s.parameter,s.x);
 s.diagnostics.v9StrictCertificate=certificate;
 s.converged=s.converged && certificate.converged;
end
s.residual=norm(p.B*s.x-p.b)^2;s.wallSeconds=toc(t);
if isfield(s.diagnostics,'polish') && isfield(s.diagnostics.polish,'queueSeconds')
 queueSeconds=queueSeconds+s.diagnostics.polish.queueSeconds;
end
s.queueSeconds=queueSeconds;s.seconds=max(0,s.wallSeconds-queueSeconds);
s.binCounts=zeros(p.g.n);s.binCounts(p.g.active)=s.x*p.scale;
assert(all(isfinite(s.x)) && all(s.x>=-1e-10),'Invalid reconstruction');
s.objectiveConverged=s.converged;
s.dataCompatible=s.residual<=(1-2/(9*p.m)+1.64485362695147*sqrt(2/(9*p.m)))^3*(1+1e-5);
if ismember(method,{'POCS-CDMA','POCS-CDMA-Dual'}),s.dataCompatible=s.diagnostics.bandsSatisfied;end
if strcmp(method,'TV-Morozov-PD'),s.dataCompatible=sqrt(s.residual)<=sqrt(p.target)+64*eps*max(1,sqrt(p.target));end
s.parameterSelectionValid=true;
if isfield(s.diagnostics,'targetBracketed'),s.parameterSelectionValid=s.diagnostics.targetBracketed;end
if isfield(s.diagnostics,'selectionValid'),s.parameterSelectionValid=s.parameterSelectionValid&&s.diagnostics.selectionValid;end
if strcmp(method,'Tikhonov-lsqlin'),s.parameterSelectionValid=baseline.parameterSelectionValid;end
if ismember(method,{'Maximum Entropy','Huber-TV','TV-2D','Tikhonov-Scaled','Tikhonov-LSQR-StrongPrecond','TV-PD'}),s.parameterSelectionValid=s.parameterSelectionValid&&s.parameter>0;end
s.constraintViolation=max([0;-s.x;p.auxLo-p.auxC*s.x;p.auxC*s.x-p.auxHi]);
s.benchmarkValid=s.objectiveConverged&&s.dataCompatible&&s.parameterSelectionValid&&s.constraintViolation<=1e-9;
if ~s.objectiveConverged,s.status='iteration/stationarity not certified';
elseif ~s.dataCompatible,s.status='objective converged but measurement mismatch';
elseif ~s.parameterSelectionValid,s.status='parameter selection not bracketed';
elseif s.constraintViolation>1e-9,s.status='auxiliary constraint violation';
else,s.status='validated';end
end
