function v6_fine_forward_audit
% Limited independent forward-grid check; no parameter selection from truth.
c=extended_config;k=load(c.commonFile);indices=unique(round(linspace(1,1224,12)));
components=cell(3,1);coarse=cell(3,1);
for ci=1:3
 a=struct('gmdDm',c.pairsNm(ci,1),'gmdDst',c.pairsNm(ci,2), ...
  'gsdDm',c.gsd,'gsdDst',c.gsd,'rho',0,'weight',1);components{ci}=a;
 x=cdma_truth(k.g,a,c.totalN);coarse{ci}=k.A*x(:);[~,peak]=max(coarse{ci});indices=unique([indices peak]);
end
cf=c;cf.nBins=216;cf.binsPerDecade=128;gf=cdma_grid(cf);scan=k.scan(indices,:);
[Af,~,info]=cdma_kernel(gf,cf,scan);rows=struct([]);
for ci=1:3
 tf=cdma_truth(gf,components{ci},c.totalN);yf=Af*tf(:);yc=coarse{ci}(indices);
 r=struct('CaseIndex',ci,'Measurements',numel(indices),'ForwardBinsPerDecade',128, ...
  'InverseBinsPerDecade',64,'RelativeSignalL2',norm(yf-yc)/max(norm(yf),eps), ...
  'MaxAbsoluteDifferenceOverPeak',max(abs(yf-yc))/max(yf));rows=[rows;r];
end
writetable(struct2table(rows),fullfile(c.root,'fine_forward_audit.csv'));
save(fullfile(c.root,'fine_forward_audit.mat'),'rows','indices','scan','info','-v7');
assert(all(isfinite([rows.RelativeSignalL2])) && all([rows.RelativeSignalL2]<.02), ...
 'Fine-forward mismatch exceeds preflight model check');
fprintf('PASS limited fine-forward audit: %d settings, relative signal differences %.4g..%.4g.\n', ...
 numel(indices),min([rows.RelativeSignalL2]),max([rows.RelativeSignalL2]));
end
