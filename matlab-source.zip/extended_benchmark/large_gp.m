function s=large_gp(p,s)
% Stationary GP prior, Gaussian marginal-likelihood parameter selection.
% Nonnegative MAP is the bound-constrained covariance dual. All selected-dual
% stages are bounded and matrix-free; their exit flags never replace the
% independent primal positivity/complementarity audit.
ratios=sort(unique([min(p.c.gpAlpha)*[.01 .1] p.c.gpAlpha(:)' max(p.c.gpAlpha)*[10 100]]));
lengths=p.c.gpLengths(:)';negativeEigen=0;cache=containers.Map('KeyType','char','ValueType','any');
Bs=p.B/sqrt(p.lip);bs=p.b/sqrt(p.lip);
for expansion=0:1
 alphas=p.lip*ratios;scores=inf(numel(lengths),numel(alphas));best=Inf;
for i=1:numel(lengths)
 key=sprintf('%.17g',lengths(i));
 if isKey(cache,key)
  entry=cache(key);W=entry.W;U=entry.U;ev=entry.ev;
 else
  K=large_gp_kernel(p.g,lengths(i));W=K(full(Bs'));
  C=full(Bs*W);[U,ev]=eig((C+C')/2,'vector');
  negativeEigen=max(negativeEigen,max(0,-min(ev))/max(max(ev),eps));
  ev=max(ev,0);cache(key)=struct('W',W,'U',U,'ev',ev);
 end
 ub=U'*bs;
 for j=1:numel(ratios)
  a=ratios(j);
  scores(i,j)=.5*(sum(log1p(ev/a))+p.m*p.lip*sum((a./(ev+a)).*ub.^2));
  if scores(i,j)<best
   best=scores(i,j);bi=i;bj=j;bestW=W;bestU=U;bestEv=ev;
  end
 end
end
 if expansion==0&&bi==1,lengths=sort(unique([lengths lengths(1)*[.25 .5]]));
 elseif expansion==0&&bi==numel(lengths),lengths=sort(unique([lengths lengths(end)*[2 4]]));
 else,break;end
end
alpha=ratios(bj);K=large_gp_kernel(p.g,lengths(bi));
V=bestW*bestU;den=bestEv+alpha;
x0=V*((bestU'*bs)./den);
P=@(z)K(z)-V*((V'*z)./den);
area=p.g.area(p.g.active)/p.g.h(1)^2;
diagP=area.^2*(1+1e4+1e-8)-sum(V.^2./den',2);
% Diagonal scaling changes only dual coordinates, not the GP prior.
d=1./sqrt(max(diagP,1e-10*max(max(diagP),eps)));
Pscaled=@(z)d.*P(d.*z);f=d.*x0;
mu=zeros(p.n,1);iterations=0;stages=struct([]);bestMu=mu;bestKKT=Inf;bestImpact=Inf;
flag=0;out=struct('iterations',0,'firstorderopt',Inf);
polish=struct('iterations',0,'innerPCGIterations',0,'kkt',Inf,'converged',false);
lbfgs=struct('iterations',0,'kkt',Inf,'converged',false);
initialCap=min(800,p.c.maxIterations);
if isfield(p.c,'gpInitialIterations'),initialCap=p.c.gpInitialIterations;end
stageTimer=tic;[candidate,apg]=accelerate(mu,initialCap);accept(candidate,'scaled FISTA start',apg.iterations,toc(stageTimer));
if ~converged
 stageTimer=tic;[candidate,polish]=v6_gp_polish(P,x0,d,mu,@audit,p.c);
 accept(candidate,'projected Newton-PCG',polish.iterations,toc(stageTimer));
end
if ~converged
 stageTimer=tic;[candidate,lbfgs]=v6_gp_lbfgs(P,x0,d,mu,@audit,p.c);
 accept(candidate,'interior-point L-BFGS',lbfgs.iterations,toc(stageTimer));
end
if ~converged
stageTimer=tic;
options=optimoptions('quadprog','Algorithm','trust-region-reflective', ...
 'Display','off','HessianMultiplyFcn',@(unused,z)Pscaled(z), ...
 'OptimalityTolerance',max(1e-10,p.c.tolerance*.01),'FunctionTolerance',1e-14, ...
 'StepTolerance',1e-13,'MaxIterations',60,'TolPCG',.01,'MaxPCGIter',80);
try
 [z,~,flag,out]=quadprog(speye(p.n),f,[],[],[],[],zeros(p.n,1),[],max(mu./d,1e-8),options);
catch err
 % Older MATLAB trust-region implementations may fail internally. Keep the
 % same dual objective and fall back to the explicitly audited FFT solver.
 z=mu./d;flag=-99;out=struct('iterations',0,'firstorderopt',Inf,'message',err.message);
end
accept(d.*max(z,0),'trust-region fallback',out.iterations,toc(stageTimer));
end
% A positive exitflag is not a scientific convergence certificate. Refine
% only if the independent bound-dual KKT/positivity audit still fails.
if ~converged
 finalCap=min(2000,2*p.c.maxIterations);
 if isfield(p.c,'gpFinalIterations'),finalCap=p.c.gpFinalIterations;end
 stageTimer=tic;[candidate,apg]=accelerate(mu,finalCap);accept(candidate,'scaled FISTA final',apg.iterations,toc(stageTimer));
end
mu=bestMu;primal=x0+P(mu);[kkt,clipImpact]=audit(mu,primal);
converged=certified(kkt,clipImpact);
s.x=max(primal,0);s.converged=converged;s.iterations=iterations;
s.parameter=alpha*p.lip*p.m;
s.selection='Gaussian evidence; bound-dual GP MAP with independent optimality audit';
s.boundary=bi==1 || bi==numel(lengths) || bj==1 || bj==numel(alphas);
chi2=norm(p.B*s.x-p.b)^2;
s.diagnostics=struct('evidence',scores,'length',lengths(bi),'lengthGrid',lengths,'alphaGrid',alphas*p.m, ...
 'kkt',kkt,'minimumBeforeProjection',min(primal),'clippingMeasurementImpact',clipImpact, ...
 'exitflag',flag,'firstorderopt',out.firstorderopt,'posteriorMinimumDiagonal',min(diagP), ...
 'covarianceNegativeEigenFraction',negativeEigen,'objectiveConverged',converged, ...
 'dataCompatible',chi2<=1.10*p.target,'selectionValid',~s.boundary&&negativeEigen<1e-9, ...
 'dualNewtonPolish',polish,'dualLBFGS',lbfgs,'dualStages',stages, ...
 'algorithm','Scaled FISTA; projected Newton-PCG; bounded matrix-free L-BFGS; selective TRR and final FISTA', ...
 'evidenceCaveat','Gaussian evidence excludes positivity normalization; observed-signal variance proxy; prior at bin centres');
 function [error,impact]=audit(mult,x)
  pg=x;pg(mult<=1e-10*max(1,norm(mult,inf)) & x>0)=0;
 error=norm(pg,inf)/max(1,norm(x0,inf));
  impact=norm(p.B*(max(x,0)-x));
 end
 function value=certified(error,impact)
  value=error<p.c.tolerance&&impact<.01*sqrt(p.target)&&negativeEigen<1e-9;
 end
 function accept(candidate,name,count,seconds)
  iterations=iterations+count;
  if any(~isfinite(candidate)),candidate=mu;end
  candidate=max(candidate,0);[error,impact]=audit(candidate,x0+P(candidate));
  stages=[stages;struct('name',name,'iterations',count,'seconds',seconds,'kkt',error, ...
   'clippingMeasurementImpact',impact,'converged',certified(error,impact))]; %#ok<AGROW>
  if error<bestKKT||(error==bestKKT&&impact<bestImpact)
   bestMu=candidate;bestKKT=error;bestImpact=impact;
  end
  mu=bestMu;converged=certified(bestKKT,bestImpact);
  if isfield(p.c,'revisionTrace')&&p.c.revisionTrace
   fprintf(' GP %s: it=%d KKT=%.3g clip=%.3g %.1fs certified=%d\n',name,count,error,impact,seconds,certified(error,impact));
  end
 end
 function [result,info]=accelerate(start,cap)
  z=max(start./d,0);y=z;acc=1;v=ones(p.n,1)/sqrt(p.n);
  for jj=1:15,w=Pscaled(v);v=w/max(norm(w),eps);end
  L=max(1.1*norm(Pscaled(v)),eps);bestZ=z;lowest=Inf;count=0;
  for it=1:cap
   grad=Pscaled(y)+f;
   for ls=1:40
    zz=max(y-grad/L,0);delta=zz-y;
    % Quadratic backtracking needs only curvature, not subtracting large
    % absolute objective values near the solution.
    if delta'*Pscaled(delta)<=L*(delta'*delta)*(1+1e-12),break;end
    L=L*2;
   end
   if mod(it,20)==0||it==cap
    mult=d.*zz;[error,impact]=audit(mult,x0+P(mult));
    if error<lowest,lowest=error;bestZ=zz;end
    if certified(error,impact),bestZ=zz;count=it;break;end
   end
   an=(1+sqrt(1+4*acc^2))/2;
   if (y-zz)'*(zz-z)>0,y=zz;an=1;else,y=zz+(acc-1)/an*(zz-z);end
   z=zz;acc=an;count=it;
  end
  result=d.*bestZ;info=struct('iterations',count);
 end
end
