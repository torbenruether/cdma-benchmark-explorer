function [x,info,state]=v7_graph_candidate(p,t,alpha,state,cap,formulation)
% Malitsky-Pock 2018 Algorithm 1 in fixed diagonal coordinates.
% No nonnegative clipping after optimisation: every primal update is the
% exact orthant prox. Data and all TV/slab blocks share the same operator K.
if nargin<6,formulation='quadratic';end
if nargin<5||isempty(cap),cap=t.cap;end
assert(alpha>0&&isfinite(alpha));
timer=tic;secondsLimit=Inf;
if isfield(p.c,'v7GraphMaxSeconds'),secondsLimit=p.c.v7GraphMaxSeconds;
elseif isfield(p,'v7GraphMaxSeconds'),secondsLimit=p.v7GraphMaxSeconds;end
if isempty(state)
 x=zeros(t.n,1);
 if isfield(p,'revisionWarmStart'),x=max(p.revisionWarmStart(:),0);end
 y=zeros(size(t.K,1),1);tau=1;theta=1;
else,x=state.x;y=state.y;tau=state.tau;theta=state.theta;
end
% A warm dual from a different alpha must be projected into the new balls.
v=reshape(y(t.reg),t.n,2);v=v./max(1,hypot(v(:,1),v(:,2))/alpha);y(t.reg)=v(:);
Kx=t.K*x;KTy=t.K'*y;accepted=true;backtracks=0;
info=v7_graph_certificate(p,t,x,y,alpha,formulation,Kx,KTy);
iteration=0;delta=.99;mu=.5;budgetStopped=false;
restoration=struct('attempted',false,'successful',false,'iterations',0,'relativeChange',0,'rawDataViolation',0);
while iteration<cap&&~info.converged
 iteration=iteration+1;
 xn=max(x-tau*(t.tx.*KTy),0);Kxn=t.K*xn;
 trial=min(tau*sqrt(1+theta),1e8);accepted=false;
 for search=1:60
  th=trial/tau;Kbar=(1+th)*Kxn-th*Kx;
  yn=v7_graph_dualprox(p,t,y+trial*(t.sy.*Kbar),trial*t.sy,alpha,formulation);
  Ktyn=t.K'*yn;dy=yn-y;
  left=trial*norm(t.sqrtTx.*(Ktyn-KTy));right=delta*norm(dy./t.sqrtSy);
  if left<=right+64*eps*max(1,right),accepted=true;break;end
  trial=mu*trial;backtracks=backtracks+1;
 end
 if ~accepted||~all(isfinite(xn))||~all(isfinite(yn)),break;end
 x=xn;Kx=Kxn;y=yn;KTy=Ktyn;theta=trial/tau;tau=trial;
 if mod(iteration,50)==0||iteration==cap
  info=v7_graph_certificate(p,t,x,y,alpha,formulation,Kx,KTy);
  % Strictly active constraints approached from outside can make the true
  % primal gap infinite. Produce a feasible upper-bound point, then recheck
  % both the gap and stationarity at THAT point; no tolerance is relaxed.
  nearBall=~strcmp(formulation,'morozov')|| ...
   norm(Kx(t.data)-p.b)<=sqrt(p.target)*(1+10*t.tolerance);
  if ~info.primalFeasible&&info.kkt<=10*t.tolerance&&nearBall
   [checked,restoration]=v7_graph_restore(p,t,x,formulation);
   if restoration.successful
    checkedK=t.K*checked;checkedInfo=v7_graph_certificate(p,t,checked,y,alpha,formulation,checkedK,KTy);
    if checkedInfo.converged,x=checked;Kx=checkedK;info=checkedInfo;end
   end
  end
  if toc(timer)>=secondsLimit,budgetStopped=true;break;end
 end
end
info=v7_graph_certificate(p,t,x,y,alpha,formulation,Kx,KTy);
info.iterations=iteration;info.lineSearchFailures=~accepted;
info.backtracks=backtracks;info.scalarStep=tau;
info.seconds=toc(timer);info.budgetStopped=budgetStopped;info.feasibilityRestoration=restoration;
info.stopReason='iteration_limit';
if info.converged,info.stopReason='feasible_primal_dual_gap_and_KKT';
elseif ~accepted,info.stopReason='line_search_or_nonfinite_failure';
elseif budgetStopped,info.stopReason='explicit_time_budget';end
info.formulation=formulation;
state=struct('x',x,'y',y,'tau',tau,'theta',theta);
end
