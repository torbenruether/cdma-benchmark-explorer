function test_revision_optimizers_real()
% Bounded check on one existing mixed-noise dataset at its original 64/bin-decade grid.
root=fileparts(mfilename('fullpath'));addpath(root,fullfile(root,'core'));maxNumCompThreads(1);
c=extended_config;old=fileparts(root);k=load(fullfile(old,'outputs','factorial27','common.mat'));
d=load(fullfile(old,'outputs','factorial27','datasets','ds00005.mat'));
c.pathMultipliers=[0 1e-5 1e-3];c.revisionAlphaRefinements=2;c.revisionNewtonIterations=60;
c.tvIterations=300;c.tolerance=2e-6;
testDir=fullfile(root,'test_outputs');if ~exist(testDir,'dir'),mkdir(testDir);end
p=cdma_prepare(k.A,d.data.y,d.data.sigma,k.g,c,k.scan);
methods={'Tikhonov','Huber-TV','Maximum Entropy'};results=struct([]);
for j=1:numel(methods)
 s=revision_optimizers(methods{j},p);
 save(fullfile(testDir,['ds00005_' strrep(methods{j},' ','_') '_truncated.mat']),'s','-v7');
 r=struct('method',methods{j},'residual',s.residual,'converged',s.converged, ...
  'seconds',s.seconds,'parameter',s.parameter,'diagnostics',s.diagnostics.selectedSolver);
 results=[results;r];assert(all(isfinite(s.x))&&all(s.x>=0));
 fprintf('%s | residual %.6g | converged %d | %.3fs\n',methods{j},s.residual,s.converged,s.seconds);
end
save(fullfile(root,'optimizer_real_tests.mat'),'results','-v7');
fprintf('Completed bounded existing mixed-noise dataset check; flags describe actual stopping.\n');
end
