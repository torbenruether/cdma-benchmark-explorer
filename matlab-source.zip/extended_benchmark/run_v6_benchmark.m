function run_v6_benchmark
c=extended_config;
assert(exist(fullfile(c.root,'V6_PREFLIGHT_PASS.json'),'file')==2,'Preflight not executed');
passed=jsondecode(fileread(fullfile(c.root,'V6_PREFLIGHT_PASS.json')));assert(passed.passed);
assert(exist(c.commonFile,'file')==2 && exist(fullfile(c.root,'SOURCE_SHA256.csv'),'file')==2);
assert(~exist(fullfile(c.outputRoot,'STOP'),'file'),'Explicit stop marker exists');
assert(~exist(fullfile(c.outputRoot,'progress.json'),'file'),'This entry starts a fresh run only');
run_extended_benchmark('full');
end
