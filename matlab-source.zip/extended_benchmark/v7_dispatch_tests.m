function v7_dispatch_tests
% Integration test of all NEW registry arms; no full benchmark is started.
c=v7_config;c.nBins=6;c.rangeNm=[20 1000];c.revisionTrace=false;
c.pathMultipliers=[0 logspace(-5,3,9)];c.revisionAlphaRefinements=8;
c.v7SmoothPathIterations=100;c.v7SmoothSelectedIterations=200;
c.v7StrongPathIterations=100;c.v7StrongSelectedIterations=200;
c.pdIterations=10000;c.pdMaxCandidates=3;
g=cdma_grid(c);n=numel(g.active);A=sparse(1:n,g.active,1,n,g.n^2);
y=500*exp(-((1:n)'-n*.55).^2/(n*.15)^2)+4;
p=cdma_prepare(A,y,4*ones(n,1),g,c,table);
rows=struct([]);
for k=1:numel(c.addedMethods)
 method=c.addedMethods{k};s=extended_solve(method,p);
 assert(all(isfinite(s.x))&&all(s.x>=0));
 assert(all(s.binCounts(~g.allowed)==0));
 assert(isfield(s,'objectiveConverged')&&isfield(s,'dataCompatible')&& ...
  isfield(s,'parameterSelectionValid')&&isfield(s,'benchmarkValid')&&isfield(s,'status'));
 assert(s.benchmarkValid==(s.objectiveConverged&&s.dataCompatible&& ...
  s.parameterSelectionValid&&s.constraintViolation<=1e-9));
 if strcmp(method,'POCS-CDMA-Dual'),assert(s.dataCompatible==s.diagnostics.bandsSatisfied);end
 if any(strcmp(method,{'Tikhonov-Scaled','Tikhonov-LSQR-StrongPrecond'}))
  assert(s.objectiveConverged&&s.parameterSelectionValid&&s.parameter>0);
 end
 row=struct('method',method,'objectiveConverged',s.objectiveConverged, ...
  'dataCompatible',s.dataCompatible,'parameterSelectionValid',s.parameterSelectionValid, ...
  'benchmarkValid',s.benchmarkValid,'status',s.status);
 rows=[rows;row]; %#ok<AGROW>
 fprintf('DISPATCH7 %s optimum%d data%d parameter%d valid%d\n',method,s.objectiveConverged,s.dataCompatible,s.parameterSelectionValid,s.benchmarkValid);
end
limited=p;limited.c.pdIterations=0;
s=extended_solve('TV-Morozov-PD',limited);
assert(s.parameterSelectionValid&&~s.objectiveConverged&&~s.dataCompatible&&~s.benchmarkValid, ...
 'A defined Morozov budget must stay independent of a failed optimisation.');
save(fullfile(c.root,'v7_dispatch_test_results.mat'),'rows','-v7');
writetable(struct2table(rows),fullfile(c.root,'v7_dispatch_test_results.csv'));
fprintf('PASS v7 registered solver dispatch, support, separate certification fields.\n');
end
