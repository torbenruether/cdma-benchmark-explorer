function revision_seed_datasets
% Measurement-only migration. NEVER reuse old reconstructions after repairs.
c=extended_config;common=load(c.commonFile);[manifest,plan]=extended_plan(c);
for sub={'datasets','metrics'},folder=fullfile(c.outputRoot,sub{1});if ~exist(folder,'dir'),mkdir(folder);end;end
for idx=1:height(manifest)
 row=manifest(idx,:);name=char(row.Dataset+".mat");target=fullfile(c.outputRoot,'datasets',name);
 assert(~exist(target,'file'),'Fresh solver revision requires empty checkpoint destination');
 original=fullfile(fileparts(c.root),'outputs','factorial27','datasets',name);
 if exist(original,'file')
  d=load(original);newData=extended_noise(d.clean,row.Relative,row.AbsoluteFraction,row.Seed,c);
  assert(isequal(newData.y,d.data.y)&&isequal(newData.sigma,d.data.sigma),'Existing measurements changed');
  d.data=newData;
 else
  a=struct('gmdDm',c.pairsNm(row.CaseIndex,1),'gmdDst',c.pairsNm(row.CaseIndex,2), ...
   'gsdDm',c.gsd,'gsdDst',c.gsd,'rho',0,'weight',1);
  [truth,truthInfo]=cdma_truth(common.g,a,c.totalN);clean=common.A*truth(:);
  data=extended_noise(clean,row.Relative,row.AbsoluteFraction,row.Seed,c);
  d=struct('components',a,'truth',truth,'truthInfo',truthInfo,'clean',clean,'data',data);
 end
 row.SigmaAbs=d.data.sigmaAbs;d.row=row;d.solutions=cell(numel(c.methods),1);d.rows=struct([]);d.complete=false;
 save(target,'-struct','d','-v7');
end
writetable(manifest,fullfile(c.outputRoot,'manifest.csv'));
write(fullfile(c.outputRoot,'config.json'),c);write(fullfile(c.outputRoot,'plan.json'),plan);
copyfile(c.commonFile,fullfile(c.outputRoot,'common.mat'));
write(fullfile(c.outputRoot,'progress.json'),struct('state','prepared','completedSolverRuns',0, ...
 'totalSolverRuns',27*numel(c.methods),'datasets',27,'converged',0,'validated',0,'failed',0, ...
 'version',c.version,'updated',datestr(now,31)));
fprintf('27 fixed measurement datasets prepared. No baseline solver results migrated.\n');
end
function write(file,value)
fid=fopen(file,'w');fwrite(fid,jsonencode(value),'char');fclose(fid);
end
