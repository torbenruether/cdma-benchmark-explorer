function revision_gp_tgv_tests()
maxNumCompThreads(1);c=extended_config;c.nBins=6;c.rangeNm=[20 1000];
g=cdma_grid(c);n=numel(g.active);A=sparse(1:n,g.active,1,n,g.n^2);
component=struct('gmdDm',315,'gmdDst',60,'gsdDm',1.3,'gsdDst',1.3,'rho',0,'weight',1);
truth=cdma_truth(g,component,1e5);y=A*truth(:);sigma=ones(n,1)*100;
p=cdma_prepare(A,y,sigma,g,c,table);p.auxC=sparse(0,n);p.auxLo=[];p.auxHi=[];
% The matrix-free quadratic proximal must agree with its dense normal-equation
% reference on a well-conditioned small operator (also tests SVD orientation).
tau=.7;probe=sin((1:n)');factor=tau*p.svdS./(1+tau*p.svdS.^2);
prox=probe+p.svdV*(factor.*(p.svdU'*(p.b-p.B*probe)));
proxRef=(eye(n)+tau*(p.B'*p.B))\(probe+tau*p.B'*p.b);
assert(norm(prox-proxRef)/max(norm(proxRef),eps)<1e-11);
p.c.tgvIterations=10000;p.c.tgvAlpha=logspace(-7,1,9);
t=tic;st=extended_tgv(p);fprintf('TGV small: %.2fs conv=%d chi2=%.6g KKT=%.3g bracket=%d\n',toc(t),st.converged, ...
 norm(p.B*st.x-p.b)^2,st.diagnostics.selectedSolver.kkt,st.diagnostics.targetBracketed);
disp(st.diagnostics.selectedSolver);assert(st.converged);assert(all(st.x>=0));assert(st.diagnostics.targetBracketed);
t=tic;sg=large_gp(p,struct);fprintf('GP small: %.2fs conv=%d chi2=%.6g KKT=%.3g\n',toc(t),sg.converged, ...
 norm(p.B*sg.x-p.b)^2,sg.diagnostics.kkt);
assert(sg.converged);assert(all(sg.x>=0));
% Independent dense primal MAP verifies the covariance dual and FFT kernel.
K=large_gp_kernel(g,sg.diagnostics.length);KM=K(eye(n));alpha=sg.parameter/p.m;
H=p.B'*p.B+alpha*(KM\eye(n));H=(H+H')/2;f=-p.B'*p.b;
o=optimoptions('quadprog','Display','off','Algorithm','interior-point-convex','OptimalityTolerance',1e-10);
[ref,~,flag]=quadprog(H/p.lip,f/p.lip,[],[],[],[],zeros(n,1),[],[],o);
relative=norm(ref-sg.x)/max(norm(ref),eps);
objective=@(x).5*norm(p.B*x-p.b)^2+.5*alpha*x'*(KM\x);
fprintf('GP primal reference: flag=%d relative=%.3g objective difference=%.3g\n',flag,relative,objective(sg.x)-objective(ref));
assert(flag>0);assert(relative<1e-3);assert(objective(sg.x)<=objective(ref)+1e-5*max(1,objective(ref)));
% An explicitly labelled external total measurement checks the slab proximal.
pa=p;pa.auxC=sparse(ones(1,n));pa.auxLo=(sum(y)-300)/p.scale;pa.auxHi=(sum(y)+300)/p.scale;
pa.c.tgvIterations=10000;sa=extended_tgv(pa);
assert(pa.auxC*sa.x>=pa.auxLo-1e-3 && pa.auxC*sa.x<=pa.auxHi+1e-3);
fprintf('TGV optional total: slab violation %.3g, optimum certified=%d (kept distinct).\n',sa.diagnostics.selectedSolver.slabViolation,sa.converged);
save(fullfile(fileparts(mfilename('fullpath')),'gp_tgv_small_tests.mat'),'st','sg','ref','relative');
fprintf('PASS: independent dense GP primal reference, exact SVD data proximal, positive/feasible outputs, baseline TGV target bracket and objective convergence.\n');
end
