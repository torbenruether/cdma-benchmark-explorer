function revision_gp_tgv_real_tests()
maxNumCompThreads(1);root=fileparts(mfilename('fullpath'));addpath(root,fullfile(root,'core'));
folder=fullfile(root,'test_outputs');tests={5,'Bayesian GP-MAP';1,'TGV2-PDHG'};rows=struct([]);
for i=1:size(tests,1)
 idx=tests{i,1};method=tests{i,2};d=load(fullfile(folder,sprintf('ds%05d_problem.mat',idx)));p=d.p;
 if strcmp(method,'TGV2-PDHG')
  p.c.tgvBalance=1;p.c.tgvMaxCandidates=1;p.c.tgvRefine=false;
 end
 output=fullfile(folder,sprintf('ds%05d_%s.mat',idx,matlab.lang.makeValidName(method)));
 if exist(output,'file')
  cached=load(output);s=cached.s;q=cached.q;
 else
  fprintf('Real-grid %s ds%05d started\n',method,idx);t=tic;s=extended_solve(method,p);
  r=large_metrics(s.binCounts,d.truth,p.g,d.components,p.c.totalN);
  q=struct('Dataset',sprintf('ds%05d',idx),'Method',method,'Success',true,'Converged',s.converged, ...
   'Seconds',toc(t),'Iterations',s.iterations,'ReducedChi2',s.residual,'RelativeL2',r.RelativeL2, ...
   'Parameter',s.parameter,'Boundary',s.boundary,'Error','');
  save(output,'s','q','-v7');
 end
 rows=[rows;q];writetable(struct2table(rows,'AsArray',true),fullfile(folder,'gp_tgv_real_metrics.csv')); %#ok<AGROW>
 fprintf('Real-grid %s: conv=%d chi2=%.6g L2=%.5g time=%.1fs\n',method,s.converged,s.residual,q.RelativeL2,q.Seconds);
end
end
