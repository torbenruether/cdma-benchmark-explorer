function s=v7_tv_solve(method,p)
% Central v7 dispatch: same-objective optimizer vs separate constrained TV.
switch method
 case 'TV-PD',s=v7_tv_pd(p);
 case 'TV-Morozov-PD',s=v7_tv_morozov(p);
 otherwise,error('Unknown TV variant %s',method);
end
end
