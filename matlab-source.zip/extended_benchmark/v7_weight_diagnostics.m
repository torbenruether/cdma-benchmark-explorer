function d=v7_weight_diagnostics(p)
% Read-only diagnostics of the EXACT supplied variance weights.
sigma=p.sigma(:);positive=sigma(sigma>0);
if isempty(positive),range=[NaN NaN];ratio=Inf;else,range=[min(positive) max(positive)];ratio=max(positive)/min(positive);end
column=sqrt(full(sum(p.B.^2,1)))';nz=column(column>0);
if isempty(nz),columnRange=[0 0];else,columnRange=[min(nz) max(nz)];end
nonnegativeKernel=all(nonzeros(p.B)>=0);lower=NaN;
if nonnegativeKernel,lower=sum(min(p.b,0).^2);end
d=struct('sigmaRange',range,'sigmaDynamicRange',ratio,'columnNormRange',columnRange, ...
 'maximumWeightedKernelEntry',max(abs(nonzeros(p.B))), ...
 'nonnegativeKernel',nonnegativeKernel,'nonnegativeMeasurementResidualLowerBound',lower, ...
 'targetProvablyIncompatible',isfinite(lower)&&lower>p.target, ...
 'weightsModified',false,'note','Diagnostics only; no weight floor, likelihood, or data rescaling changed.');
end
