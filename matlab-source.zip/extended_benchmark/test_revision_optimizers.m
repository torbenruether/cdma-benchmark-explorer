function test_revision_optimizers()
root=fileparts(mfilename('fullpath'));addpath(root,fullfile(root,'core'));maxNumCompThreads(1);
c=extended_config;c.nBins=8;c.rangeNm=[20 1000];c.pathMultipliers=[0 1e-6 1e-3 .1];
c.maxIterations=500;c.revisionNewtonIterations=250;c.tvIterations=4000;
c.notify=false;c.aux=struct('total',[],'dm',[],'dst',[],'tolerance',[]);
g=cdma_grid(c);n=numel(g.active);A=sparse(1:n,g.active,ones(n,1),n,g.n^2);
comp=struct('gmdDm',315,'gmdDst',60,'gsdDm',1.3,'gsdDst',1.3,'rho',0,'weight',1);
T=cdma_truth(g,comp,1e5);y=A*T(:);p=cdma_prepare(A,y,ones(n,1)*20,g,c,table);
methods={'Tikhonov','Maximum Entropy','Huber-TV','TV-2D'};results=struct([]);
for j=1:numel(methods)
 s=revision_optimizers(methods{j},p);assert(all(isfinite(s.x))&&all(s.x>=0));
 assert(s.converged,'Small convex test did not meet stationarity: %s',methods{j});
 r=struct('method',methods{j},'residual',s.residual,'converged',s.converged,'seconds',s.seconds,'parameter',s.parameter,'diagnostics',s.diagnostics.selectedSolver);
 results=[results;r];if j==1,base=s;end
 fprintf('%s | residual %.6g | converged %d | %.3fs\n',methods{j},s.residual,s.converged,s.seconds);
end
s=revision_optimizers('Tikhonov-lsqlin',p,base);
assert(s.diagnostics.objective<=s.diagnostics.baselineObjective+1e-8);
assert(s.converged,'Independent scaled lsqlin stationarity failed.');
tw=revision_optimizers('Twomey-Markowski',p);assert(tw.converged&&tw.residual<=1+1e-8);
assert(all(tw.x>=0),'Diffusion broke positivity.');
ridge=revision_optimizers('POCS-fixed-ridge',p,struct('alpha',p.lip/2,'x',p.zero));
expected=(p.B'*p.b)./(p.diagQ+p.lip/2);
assert(ridge.converged&&norm(ridge.x-expected)/norm(expected)<1e-5, ...
 'Fixed-ridge POCS multiplier primitive failed known solution.');
% Strongly heterogeneous channels: each true solution fits exactly even with 1e12 weight span.
pp=p;pp.B=spdiags(logspace(-6,6,n)',0,n,n);pp.b=pp.B*max(T(g.active)/p.scale,1e-5);
pp.rhs=pp.B'*pp.b;pp.diagQ=full(sum(pp.B.^2,1))';pp.lip=max(pp.diagQ);
pp.c.pathMultipliers=0;pp.zero=zeros(n,1);
z=revision_optimizers('Tikhonov',pp);
assert(z.converged&&norm(pp.B*z.x-pp.b)/norm(pp.b)<1e-10,'Heterogeneous weights test failed.');
twH=revision_optimizers('Twomey-Markowski',pp);
% Restored bin-mass metric has a severe spectral convergence limit on this
% 12-decade fixture. Check truthful stopping, not universal finite-budget fit.
assert(all(isfinite(twH.x))&&all(twH.x>=0));
assert(twH.converged==(twH.residual<=1+1e-8),'Twomey falsely certified discrepancy');
fprintf('Twomey 12-decade stress: reached=%d chi2=%.6g iterations=%d (failure remains explicit).\n', ...
 twH.converged,twH.residual,twH.iterations);
save(fullfile(root,'optimizer_small_tests.mat'),'results','s','z','tw','twH','ridge','-v7');
fprintf('PASS: four convex regularizers, independent optimizer objective check, scaled Twomey and twelve-decade heteroscedastic data.\n');
end
