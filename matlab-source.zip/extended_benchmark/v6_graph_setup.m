function t=v6_graph_setup(p,order)
% Same masked-density TV/TGV objectives, split into two ADMM blocks.
n=p.n;I=speye(n);
if order==1
 t.Dreg=[p.Ga;p.Gm];t.widths=2;t.weights=ones(n,1);t.coefficients=1;
 t.D=[t.Dreg;I];t.B=p.B;t.nvar=n;t.pos=2*n+(1:n);
else
 S=p.g.densityScale;H1=p.g.Gm/S;H2=p.g.Ga/S;
 gn=max(sqrt(norm([H1;H2],1)*norm([H1;H2],inf)),eps);H1=H1/gn;H2=H2/gn;Z=sparse(n,n);
 G=[H1*S;H2*S];E=[H1 Z;Z H2;H2/sqrt(2) H1/sqrt(2)];
 t.Dreg=[G -speye(2*n);sparse(3*n,n) E];
 t.widths=[2 3];t.weights=p.g.area(p.g.active)/p.g.h(1)^2;t.coefficients=[1 p.c.tgvRatio];
 t.D=[t.Dreg;I sparse(n,2*n)];t.B=[p.B sparse(p.m,2*n)];t.nvar=3*n;t.pos=5*n+(1:n);
end
t.slabs=[];t.lo=[];t.hi=[];
if isfield(p,'auxC') && ~isempty(p.auxC)
 t.slabs=size(t.D,1)+(1:size(p.auxC,1));t.lo=p.auxLo;t.hi=p.auxHi;
 t.D=[t.D;p.auxC sparse(size(p.auxC,1),t.nvar-n)];
end
t.n=n;t.order=order;R=t.D'*t.D;t.perm=symamd(R);t.L=chol(R(t.perm,t.perm),'lower');
% Direct rectangular SVD of the whitened data operator. No Gram rank cutoff.
C=full(t.B(:,t.perm)/t.L');[t.V,S,t.U]=svd(C','econ');t.s=diag(S);t.ub=t.U'*p.b;
t.rhs=t.B'*p.b;t.rhsNorm=max(1,norm(t.rhs));t.rhsInf=max(1,norm(t.rhs,inf));
end
