function results=v9_pocs_tests()
% Small isolated fixtures. Caller executes; this file launches no process.
% No benchmark cache or truth-derived auxiliary constraints are loaded.
root=fileparts(mfilename('fullpath'));addpath(root,fullfile(root,'core'));
c=struct('nBins',3,'rangeNm',[20 1000],'tolerance',2e-6, ...
 'tgvTolerance',2e-5,'tgvRatio',2);
c.aux=struct('total',[],'dm',[],'dst',[],'tolerance',[]);
g=cdma_grid(c);n=numel(g.active);
tests={@defaultPolicy,@analytic,@coupled,@exactDualConsistency, ...
 @coupledAuxiliary,@zeroRows,@finiteBudget,@invalidPolicy, ...
 @tvRelaxation,@tgvUnchanged};
names={'explicit_production_policy','analytical_minimum_bin_mass_norm', ...
 'same_primal_dense_QP_reference','wrapper_preserves_exact_dual_certificate', ...
 'simultaneous_external_total_and_marginals','zero_row_compatibility_and_exact_contradiction', ...
 'budget_stop_never_certifies_optimality_or_infeasibility','invalid_policy_rejected', ...
 'TV_relaxation_1p8_same_strict_certificate','TGV_ignores_TV_relaxation'};
results=struct('name',{},'passed',{},'seconds',{},'message',{});
for k=1:numel(tests)
 timer=tic;
 try,tests{k}();passed=true;message='PASS';
 catch err,passed=false;message=[err.identifier ': ' err.message];end
 results(k)=struct('name',names{k},'passed',passed,'seconds',toc(timer),'message',message); %#ok<AGROW>
 fprintf('%s: %s (%.3fs)\n',names{k},message,results(k).seconds);
end
save(fullfile(root,'v9_pocs_test_results.mat'),'results');
writetable(struct2table(results),fullfile(root,'v9_pocs_test_results.csv'));
assert(all([results.passed]),'v9:POCSTestsFailed','%d of %d v9 POCS/TV policy tests failed.', ...
 sum(~[results.passed]),numel(tests));

 function defaultPolicy()
  p=problem(zeros(3,n),ones(n,1));s=v9_pocs(p);check(s,p);
  q=s.diagnostics.v9Policy;
  assert(q.warmupIterations==100&&q.newtonIterations==400&&q.pcgIterations==100&& ...
   q.lbfgsIterations==0&&q.polishIterations==0&&q.maxSeconds==180&&q.strictCertificateUnchanged, ...
   'Production POCS defaults drifted from declared v9 policy.');
  assert(~isempty(strfind(s.diagnostics.objectiveEquivalence,'min 0.5*||x||_2^2')), ...
   'Objective equivalence is not recorded.'); %#ok<STREMP>
 end

 function analytic()
  known=[.1;3;5;1;7;.2];p=problem(eye(n),known);s=v9_pocs(p);check(s,p);
  width=sqrt(2)*erfcinv(.05/p.m)/sqrt(p.m);expected=max(known-width,0);
  assert(norm(s.x-expected)/max(1,norm(expected))<5e-6,'Analytical norm projector differs.');
  full=zeros(g.n);full(g.active)=s.x;assert(all(full(~g.allowed)==0),'Physical support escaped.');
  compareQP(s,p);
 end

 function coupled()
  B=[1 .4 .2 .5 .3 .1;.2 1 .5 .1 .4 .6;.6 .3 1 .4 .2 .7];
  p=problem(B,[1;3;2;4;5;2]);s=v9_pocs(p);check(s,p);compareQP(s,p);
 end

 function exactDualConsistency()
  p=problem(eye(n),(1:n)');
  p.c.v7POCSDualWarmup=100;p.c.v7POCSDualNewtonIterations=400;
  p.c.v7POCSDualPCGIterations=100;p.c.v7POCSDualLBFGSIterations=0;
  p.c.v7POCSDualPolishIterations=0;p.c.v7POCSDualMaxSeconds=Inf;
  wrapped=v9_pocs(p);original=v7_pocs_dual(p);check(wrapped,p);
  assert(isequal(wrapped.x,original.x)&&wrapped.converged==original.converged&& ...
   wrapped.iterations==original.iterations&&isequal(wrapped.diagnostics.certificate,original.diagnostics.certificate), ...
   'Wrapper changed the numerical solution or the original certificate.');
 end

 function coupledAuxiliary()
  p=problem(eye(n),(1:n)');N=zeros(g.n);N(g.active)=p.b;
  source='independently generated isolated fixture, not benchmark truth input';
  aux=struct('total',struct('value',sum(N(:)),'sigma',0,'source',source), ...
   'dm',struct('value',sum(N,1)','sigma',0,'source',source), ...
   'dst',struct('value',sum(N,2),'sigma',0,'source',source),'tolerance',[]);
  [p.auxC,p.auxLo,p.auxHi]=extended_constraints(g,aux,1);
  s=v9_pocs(p);check(s,p);compareQP(s,p);
  F=zeros(g.n);F(g.active)=s.x;
  assert(norm(sum(F,1)'-sum(N,1)',inf)<1e-8&&norm(sum(F,2)-sum(N,2),inf)<1e-8, ...
   'Simultaneous marginal constraints or axes changed.');
 end

 function zeroRows()
  p=problem(zeros(2,n),ones(n,1));s=v9_pocs(p);check(s,p);
  assert(all(s.x==0)&&~s.diagnostics.infeasibleCertified,'Compatible zero kernel changed.');
  p.b(1)=10;s=v9_pocs(p);
  assert(~s.converged&&s.diagnostics.infeasibleCertified&&all(isfinite(s.x)), ...
   'Exact original zero-row contradiction not reported.');
 end

 function finiteBudget()
  p=problem(eye(n),(1:n)');p.c.v7POCSDualMaxSeconds=0;
  s=v9_pocs(p);
  assert(~s.converged&&s.diagnostics.budgetStopped&&~s.diagnostics.infeasibleCertified, ...
   'Budget stop was used as an optimality or infeasibility certificate.');
  assert(s.diagnostics.v9Policy.maxSeconds==0,'Explicit time override was ignored.');
  p=problem([ones(1,n);ones(1,n)],ones(n,1));p.b=[1;10];
  p.c.v7POCSDualWarmup=5;p.c.v7POCSDualNewtonIterations=5;
  s=v9_pocs(p);
  assert(~s.converged&&~s.diagnostics.infeasibleCertified&&all(isfinite(s.x))&&all(s.x>=0), ...
   'Inconsistent iteration limit was mistaken for a mathematical infeasibility proof.');
  assert(s.diagnostics.v9Policy.warmupIterations==5&&s.diagnostics.v9Policy.newtonIterations==5, ...
   'Explicit iteration overrides were ignored.');
 end

 function invalidPolicy()
  p=problem(eye(n),(1:n)');p.c.v7POCSDualPCGIterations=0;
  try,v9_pocs(p);catch err,assert(strcmp(err.identifier,'v9:InvalidPOCSIterationBudget'));return;end
  error('v9:InvalidPolicyAccepted','Invalid PCG iteration budget was accepted.');
 end

 function tvRelaxation()
  p=problem(eye(n),[1;4;2;6;3;5]);t=v6_graph_setup(p,1);alpha=.07;
  [x0,old]=v6_graph_candidate(p,t,alpha,[],12000);
  p.c.v9TVADMMRelaxation=1.8;[x1,new]=v6_graph_candidate(p,t,alpha,[],12000);
  assert(old.relaxation==1.6&&new.relaxation==1.8,'TV relaxation override/default changed.');
  assert(old.converged&&new.converged,'TV fixture did not meet the original strict certificate.');
  assert(new.primalResidual<=c.tolerance&&new.dualResidual<=c.tolerance&& ...
   new.kkt<=c.tolerance&&new.complementarityGap<=c.tolerance&& ...
   new.clippingMeasurementImpact<=.01*sqrt(p.target)&&new.slabViolation<=c.tolerance, ...
   'TV relaxation was accepted without the complete original strict certificate.');
  assert(abs(new.objective-old.objective)/max(1,abs(old.objective))<5e-5&& ...
   norm(x1-x0)/max(1,norm(x0))<5e-5,'TV relaxation changed the small-fixture optimum.');
  [~,short]=v6_graph_candidate(p,t,alpha,[],1);assert(~short.converged, ...
   'Short TV solve was falsely certified.');
  p.c.v9TVADMMRelaxation=2;
  try,v6_graph_candidate(p,t,alpha,[],1);
  catch err,assert(strcmp(err.identifier,'v9:InvalidTVADMMRelaxation'));return;end
  error('v9:InvalidPolicyAccepted','Invalid ADMM relaxation was accepted.');
 end

 function tgvUnchanged()
  p=problem(eye(n),[1;4;2;6;3;5]);t=v6_graph_setup(p,2);
  [x0,old,state0]=v6_graph_candidate(p,t,.07,[],1);
  p.c.v9TVADMMRelaxation=1.8;[x1,new,state1]=v6_graph_candidate(p,t,.07,[],1);
  assert(old.relaxation==1.6&&new.relaxation==1.6&&isequal(x0,x1)&&isequal(state0,state1)&& ...
   isequal(old,new),'TV-only setting changed order-2 TGV numerics or checks.');
 end

 function p=problem(B,known)
  p=struct('B',sparse(B),'b',B*known,'m',size(B,1),'n',n,'zero',zeros(n,1), ...
   'c',c,'g',g,'scale',1,'auxC',sparse(0,n),'auxLo',[],'auxHi',[], ...
   'Ga',g.Ga,'Gm',g.Gm,'target',1);
 end

 function check(s,p)
  if ~s.converged,disp(s.diagnostics);end
  assert(s.converged&&all(isfinite(s.x))&&all(s.x>=0),'Known feasible norm projection was not certified.');
  cert=s.diagnostics.certificate;kappa=sqrt(2)*erfcinv(.05/p.m);
  assert(cert.relativeDualGap>=-1e-9&&cert.relativeDualGap<=c.tolerance&& ...
   cert.relativeStationarity<=c.tolerance&&cert.relativeBoundKKT<=c.tolerance&& ...
   cert.normalizedSlabViolation<=1e-9&&s.diagnostics.auxiliaryConstraintViolation<=1e-9&& ...
   max(abs(sqrt(p.m)*(p.B*s.x-p.b)))<=kappa*(1+1e-5), ...
   'The full unchanged POCS certificate failed.');
 end

 function compareQP(s,p)
  assert(exist('quadprog','file')==2,'Dense reference requires Optimization Toolbox quadprog.');
  width=sqrt(2)*erfcinv(.05/p.m)/sqrt(p.m);
  C=[p.B;p.auxC];lo=[p.b-width;p.auxLo];hi=[p.b+width;p.auxHi];
  zero=~any(C~=0,2);C=C(~zero,:);lo=lo(~zero);hi=hi(~zero);eq=lo==hi;
  opts=optimoptions('quadprog','Algorithm','interior-point-convex','Display','off', ...
   'MaxIterations',300,'OptimalityTolerance',1e-12,'ConstraintTolerance',1e-12);
  [xq,~,flag]=quadprog(eye(n),zeros(n,1),full([C(~eq,:);-C(~eq,:)]), ...
   [hi(~eq);-lo(~eq)],full(C(eq,:)),lo(eq),zeros(n,1),[],[],opts);
  assert(flag>0,'Independent same-primal reference QP failed.');
  assert(norm(s.x-xq)/max(1,norm(xq))<1e-5,'v9 dual solution differs from the unique minimum-norm primal.');
 end
end
