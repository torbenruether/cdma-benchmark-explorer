function run_v9_preflight
% Isolated implementation checks; never seeds the production results.
c=extended_config;maxNumCompThreads(1);
writejson(fullfile(c.root,'V9_PREFLIGHT_PASS.json'),struct('passed',false,'version',c.version,'scope','Preflight in progress or failed'));
assert(strcmp(c.version,'9.0-best-settings-1224'));
assert(numel(c.methods)==11 && numel(unique(c.methods))==11);
assert(strcmp(c.methods{3},'Tikhonov') && strcmp(c.methods{4},'Tikhonov-lsqlin'));
assert(c.workers==2 && c.threadsPerWorker==2 && c.notify);
assert(~c.clipNegative && ~c.poissonEnabled && isempty(c.aux.total));
for name={'extended_config','extended_dataset','extended_solve','cdma_prepare'}
 resolved=which(name{1});assert(startsWith(resolved,[c.root filesep]),'Source shadowing: %s',resolved);
end
k=load(c.commonFile);
assert(size(k.A,1)==1224 && k.g.n==108 && numel(k.g.active)==5886);
assert(c.binsPerDecade==64 && c.positiveVoltageLevels==24 && c.positiveRotationLevels==48);
[manifest,~]=extended_plan(c);assert(height(manifest)==27);
assert(all(manifest.Modes==1) && all(manifest.N==1e5));
v6_noise_tests;
revision_constraint_tests;
v9_smooth_tests;
v9_pocs_tests;
v9_dispatch_tests;
v6_tv_tgv_tests;
v6_fine_forward_audit;
result=struct('passed',true,'finished',datestr(now,31),'version',c.version, ...
 'scope','Independent small references, constraints, signed noise, production geometry and fine-forward audit; not a guarantee of reconstruction quality');
writejson(fullfile(c.root,'V9_PREFLIGHT_PASS.json'),result);
fprintf('PASS: v9 preflight complete; production remains unstarted.\n');
end
function writejson(file,obj)
tmp=[file '.tmp'];fid=fopen(tmp,'w');assert(fid>=0);fwrite(fid,jsonencode(obj),'char');fclose(fid);movefile(tmp,file,'f');
end
