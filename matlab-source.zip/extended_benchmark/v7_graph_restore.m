function [checked,report]=v7_graph_restore(p,t,x,formulation)
% Bounded geometric feasibility restoration ONLY for a primal upper bound.
% Convergence is subsequently checked by full dual gap and KKT at checked.
% This is never sufficient by itself to label an optimisation converged.
checked=x;report=struct('attempted',true,'successful',false,'iterations',0, ...
 'relativeChange',0,'rawDataViolation',max(0,norm(p.B*x-p.b)-sqrt(p.target)));
for j=1:40
 checked=max(checked,0);
 for k=1:size(t.C,1)
  a=t.C(k,:)';den=a'*a;
  if den==0,continue;end
  v=t.C(k,:)*checked;vv=min(max(v,t.lo(k)),t.hi(k));checked=checked+((vv-v)/den)*a;
 end
 if strcmp(formulation,'morozov')
  % A small interior guard changes neither the stated ball nor the model;
  % it makes the checked point robustly feasible for the ORIGINAL ball.
  [checked,projection]=revision_ball_project(checked,p,p.target*(1-1e-10));
  if ~projection.verified,break;end
 end
 cv=max([0;-checked;t.lo-t.C*checked;t.C*checked-t.hi]);
 rounding=64*eps*max([1;abs(checked);abs(t.lo);abs(t.hi)]);
 feasible=cv<=rounding;
 if strcmp(formulation,'morozov'),feasible=feasible&&norm(p.B*checked-p.b)<=sqrt(p.target)+64*eps*max(1,sqrt(p.target));end
 if feasible,report.successful=true;break;end
end
report.iterations=j;report.relativeChange=norm(checked-x)/max(1,norm(x));
% Positivity is exact on return; this can invalidate ball feasibility, which
% is detected by the subsequent certificate rather than concealed.
checked=max(checked,0);
end
