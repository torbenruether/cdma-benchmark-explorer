function z=v7_graph_certificate(p,t,x,y,alpha,formulation,Kx,KTy)
% A feasible dual lower bound, not an iterate-difference surrogate.
% min_{x>=0} F(Kx) has dual -F*(y), provided K'*y>=0.
if nargin<7,Kx=t.K*x;end
if nargin<8,KTy=t.K'*y;end
r=Kx(t.data)-p.b;a=reshape(Kx(t.reg),t.n,2);
z.residual=norm(r)^2;z.penalty=sum(hypot(a(:,1),a(:,2)));
z.constraintViolation=max([0;-x;t.lo-Kx(t.slabs);Kx(t.slabs)-t.hi]);
roundPrimal=64*eps*max([1;abs(x);abs(Kx(t.slabs));abs(t.lo);abs(t.hi)]);
z.primalFeasible=z.constraintViolation<=roundPrimal;
if strcmp(formulation,'quadratic')
 z.objective=.5*z.residual+alpha*z.penalty;
else
 z.objective=z.penalty;
 z.primalFeasible=z.primalFeasible&&sqrt(z.residual)<=sqrt(p.target)+ ...
 64*eps*max(1,sqrt(p.target));
end
% Correction in a known strictly positive B' direction makes a genuine dual.
% It changes only q, whose conjugate domain is all of R^m.
g=KTy;direction=t.positiveDirection;positive=direction>0;
roundDual=64*eps*max(1,norm(g,inf));
fallback=any(g(~positive)<-roundDual);shift=0;yf=y;
if fallback
 yf=zeros(size(y));
else
 bad=g<roundDual;
 if any(bad&positive),shift=max((roundDual-g(bad&positive))./direction(bad&positive));end
 yf(t.data)=yf(t.data)+shift;
end
gf=t.K'*yf;z.dualFeasible=all(gf>=-64*eps*max(1,norm(gf,inf)));
v=reshape(yf(t.reg),t.n,2);z.dualFeasible=z.dualFeasible&& ...
 all(hypot(v(:,1),v(:,2))<=alpha+64*eps*max(1,alpha));
q=yf(t.data);
if strcmp(formulation,'quadratic'),z.dualObjective=-.5*(q'*q)-p.b'*q;
else,z.dualObjective=-p.b'*q-sqrt(p.target)*norm(q);end
if ~isempty(t.slabs)
 lambda=yf(t.slabs);z.dualObjective=z.dualObjective- ...
 t.hi'*max(lambda,0)-t.lo'*min(lambda,0);
end
z.dualCorrection=shift;z.certificateFallback=fallback;
z.gap=z.objective-z.dualObjective;
z.gapRoundoff=256*eps*max([1,abs(z.objective),abs(z.dualObjective)]);
z.gapConsistent=z.gap>=-z.gapRoundoff;
z.relativeGap=max(z.gap,0)/max([1,abs(z.objective),abs(z.dualObjective)]);
if ~z.primalFeasible||~z.dualFeasible||~z.gapConsistent,z.relativeGap=Inf;end
% Independent fixed-point diagnostics, computed at the SAME x/y (no clip).
px=max(x-t.tx.*KTy,0);
z.primalStationarity=norm((x-px)./t.sqrtTx)/max(1,norm(x./t.sqrtTx));
dy=y-v7_graph_dualprox(p,t,y+t.sy.*Kx,t.sy,alpha,formulation);
z.dualStationarity=norm(dy./t.sqrtSy)/max(1,norm(y./t.sqrtSy));
z.kkt=max(z.primalStationarity,z.dualStationarity);
z.converged=z.primalFeasible&&z.dualFeasible&&z.gapConsistent&& ...
 z.relativeGap<=t.tolerance&&z.kkt<=t.tolerance;
end
