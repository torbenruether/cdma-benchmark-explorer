function [p,d]=v7_prepare_control(dataset)
% Reuse identical stored measurement values and declared weights, never truth.
c=v7_config;maxNumCompThreads(c.threadsPerWorker);
file=fullfile(c.parentResults,'datasets',[dataset '.mat']);assert(exist(file,'file')==2);
d=load(file);k=load(c.commonFile);
p=cdma_prepare(k.A,d.data.y,d.data.sigma,k.g,c,k.scan);
[p.auxC,p.auxLo,p.auxHi]=extended_constraints(p.g,c.aux,p.scale);
assert(isempty(p.auxC),'No independent auxiliary measurements in main controls');
end
