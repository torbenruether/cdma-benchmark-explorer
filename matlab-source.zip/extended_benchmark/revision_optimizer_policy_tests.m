function revision_optimizer_policy_tests()
% Fresh bounded validation of Huber/entropy after coarse-path/selection repair.
c=extended_config;maxNumCompThreads(1);
c.pathMultipliers=[0 1e-5 1e-3];c.revisionAlphaRefinements=2;c.revisionTrace=true;
c.revisionPCGIterations=100;c.revisionSelectedNewtonIterations=100;
folder=fullfile(c.root,'test_outputs','optimizer_policy_check');
if ~exist(folder,'dir'),mkdir(folder);end
d=load(fullfile(c.root,'test_outputs','ds00005_problem.mat'));p=d.p;p.c=c;
methods={'Huber-TV','Maximum Entropy'};rows=struct([]);
for mi=1:numel(methods)
 method=methods{mi};fprintf('Fresh bounded policy test %s started\n',method);timer=tic;
 try
  s=extended_solve(method,p);
  met=large_metrics(s.binCounts,d.truth,p.g,d.components,c.totalN);
  rest=NaN;if isfield(s.diagnostics,'selectedSolver')&&isfield(s.diagnostics.selectedSolver,'kkt'),rest=s.diagnostics.selectedSolver.kkt;end
  q=struct('Dataset',char(d.row.Dataset),'Method',method,'Success',true, ...
   'Converged',s.converged,'BenchmarkValid',s.benchmarkValid, ...
   'DataCompatible',s.dataCompatible,'ParameterSelectionValid',s.parameterSelectionValid, ...
   'Seconds',toc(timer),'Iterations',s.iterations,'ReducedChi2',s.residual, ...
   'RelativeL2',met.RelativeL2,'Parameter',s.parameter,'Boundary',s.boundary, ...
   'KKT',rest,'Status',s.status,'Error','');
  % Atomic-ish own result is saved before summary writing; never reuse old output.
  save(fullfile(folder,[matlab.lang.makeValidName(method) '.mat']),'s','q','-v7');
 catch err
  q=struct('Dataset',char(d.row.Dataset),'Method',method,'Success',false, ...
   'Converged',false,'BenchmarkValid',false,'DataCompatible',false, ...
   'ParameterSelectionValid',false,'Seconds',toc(timer),'Iterations',0, ...
   'ReducedChi2',NaN,'RelativeL2',NaN,'Parameter',NaN,'Boundary',false, ...
   'KKT',NaN,'Status','execution failed','Error',err.message);
  save(fullfile(folder,[matlab.lang.makeValidName(method) '_error.mat']),'q','-v7');
  fprintf('%s\n',getReport(err,'extended','hyperlinks','off'));
 end
 rows=[rows;q]; %#ok<AGROW>
 writetable(struct2table(rows,'AsArray',true),fullfile(folder,'metrics.csv'));
 fprintf('%s completed: alpha %.5g, chi2 %.5g, KKT %.3g, converged=%d valid=%d %.1fs\n', ...
  method,q.Parameter,q.ReducedChi2,q.KKT,q.Converged,q.BenchmarkValid,q.Seconds);
end
save(fullfile(folder,'results.mat'),'rows','-v7');
end
