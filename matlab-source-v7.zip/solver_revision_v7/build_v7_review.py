"""Summarize experimental controls separately from the paused v6 benchmark."""
import csv, html, json, math, pathlib, datetime
from scipy.io import loadmat

ROOT = pathlib.Path(__file__).resolve().parent
PARENT = ROOT.parent / 'solver_revision_v6' / 'outputs' / 'factorial27_1224'
OUT = ROOT / 'outputs' / 'solver_controls'
METHODS = {'Tikhonov-Scaled': 'Tikhonov', 'POCS-CDMA-Dual': 'POCS-CDMA',
           'Tikhonov-LSQR-StrongPrecond': 'Tikhonov', 'TV-PD': 'TV-2D', 'TV-Morozov-PD': None}

def read(path):
    if not path.exists(): return []
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def num(row, key):
    try: return float(row[key])
    except (KeyError, ValueError, TypeError): return float('nan')

def yes(row, key): return row.get(key, '').lower() in ('true', '1')
def fmt(value, percent=False):
    if not math.isfinite(value): return '—'
    return ('%.2f %%' % (100 * value)) if percent else ('%.3g' % value)

def build():
    rows = []
    for path in sorted(OUT.glob('ds*_*.csv')):
        rows.extend(read(path))
    for r in rows:
        label=''.join(c if c.isascii() and c.isalnum() else '_' for c in r['Method'])
        s=loadmat(OUT/(r['Dataset']+'_'+label+'.mat'),simplify_cells=True)['s']
        d=s['diagnostics'];q=d.get('selectedSolver',d.get('certificate',{}))
        r['CertificateKKT']=q.get('kkt',q.get('relativeBoundKKT',float('nan')))
        r['CertificateRelativeGap']=q.get('relativeGap',q.get('relativeDualGap',float('nan')))
        r['BudgetStopped']=bool(q.get('budgetStopped',d.get('budgetStopped',False)))
        r['RawPrimalMinusDual']=r['CertificateRelativeGap']
        r['GapInterpretation']='feasible certificate' if q.get('primalFeasible',yes(r,'DataCompatible')) else 'infeasible primal: no valid optimality gap'
        if not q.get('primalFeasible',yes(r,'DataCompatible')):
            r['CertificateRelativeGap']=float('nan')
    baselines = {}
    for ds in ('ds00005','ds00002'):
        baselines[ds] = {r['Method']: r for r in read(PARENT/'metrics'/(ds+'.csv'))}
    fixtures = read(ROOT/'v7_fixture_summary.csv')
    complete_families = {r['family']: yes(r,'passed') for r in fixtures}
    table = []
    comparisons = []
    for r in rows:
        method, ds = r['Method'], r['Dataset']
        old = baselines[ds].get(METHODS[method], {})
        noise = '3 % relativ + 3 % absolut' if ds=='ds00005' else '3 % relativ + 0 % absolut'
        fields = [ds, noise, method, fmt(num(r,'Seconds'))+' s',
                  '✓' if yes(r,'ObjectiveConverged') else 'offen',
                  '✓' if yes(r,'DataCompatible') else 'nein',
                  '✓' if yes(r,'ParameterSelectionValid') else 'offen',
                  fmt(num(r,'RelativeL2'),True), fmt(num(old,'RelativeL2'),True),
                  '✓' if yes(r,'TargetPass') else 'nein']
        table.append('<tr>'+''.join('<td>'+html.escape(v)+'</td>' for v in fields)+'</tr>')
        comparisons.append({**r,'ParentMethod':METHODS[method] or '',
                            'ParentRelativeL2':num(old,'RelativeL2'),
                            'ParentObjectiveConverged':yes(old,'ObjectiveConverged'),
                            'ParentSeconds':num(old,'Seconds')})
    if comparisons:
        with (OUT/'controls_comparison.csv').open('w',encoding='utf-8',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(comparisons[0]));w.writeheader();w.writerows(comparisons)
    stamp = datetime.datetime.now().astimezone().isoformat(timespec='seconds')
    sources = [
        ('LSQR und Vorkonditionierung','https://www.mathworks.com/help/matlab/ref/lsqr.html'),
        ('Dykstra, ADMM und Dual-Koordinatenverfahren','https://arxiv.org/abs/1705.04768'),
        ('Primal-Dual mit Liniensuche','https://arxiv.org/abs/1608.08883'),
        ('TV mit expliziter Messfehlergrenze','https://arxiv.org/abs/1111.5632')]
    intro = (
        'Fünf zusätzliche Solverarme in eigener Revision v7. Tikhonov-Scaled, '
        'Tikhonov-LSQR-StrongPrecond, POCS-CDMA-Dual und TV-PD optimieren dieselben bisherigen Zielfunktionen. '
        'TV-Morozov-PD minimiert TV unter einer direkten gewichteten Messfehlergrenze '
        'und ist eine eigene Formulierung. Verbesserungen sind experimentell und '
        'werden nicht vorab als Erfolg gewertet. Der Hauptbenchmark v6 bleibt pausiert bei 83/297.')
    checks = '; '.join(k+': '+('bestanden' if v else 'fehlgeschlagen') for k,v in complete_families.items()) or 'noch ausstehend'
    body = '<article class="card prose"><h2>Neue Solvervarianten: getrennte v7-Prüfung</h2><p>'+intro+'</p>'
    body += '<p>Export '+html.escape(stamp)+'. Kleine unabhängige Referenztests: '+html.escape(checks)+'.</p>'
    body += '<p>Gleiche gespeicherte Messwerte, Messgewichte, 1.224 Messungen und 64 Bins/Dekade. '
    body += 'Tikhonov/TV-Vergleiche verwenden den zuvor allein aus Messdaten gewählten Parameter '
    body += 'und starten bei null. Eine vorher ungültige Parameterwahl bleibt ungültig. '
    body += 'Begrenzte Iterations- und Zeitbudgets; ausbleibende Zertifikate bleiben offen. '
    body += 'Die alten Laufzeiten enthalten eine Parametersuche, die festen v7-Kontrollen '
    body += 'nicht. Daraus darf kein Geschwindigkeitsfaktor abgeleitet werden.</p>'
    body += '<div class="tablewrap"><table><thead><tr>'+''.join('<th>'+v+'</th>' for v in
        ['Fall','Rauschen','Variante','Zeit','Optimum','Daten','Parameter','2D-Fehler','bisheriger 2D-Fehler','alle Ziele'])+'</tr></thead><tbody>'
    body += ''.join(table) or '<tr><td colspan="10">Gespeicherte Kontrollen folgen nach dem jeweiligen Solverabschluss.</td></tr>'
    body += '</tbody></table></div>'
    followups=[]
    for path in sorted((ROOT/'outputs'/'tv_followup').glob('*.mat')):
        d=loadmat(path,simplify_cells=True);q=d['info'];r=d['metrics']
        followups.append((path.stem,q,r))
    if followups:
        body+='<h3>Längere TV-Kontrollen, getrennt vom Startvergleich</h3><p>'
        body+='Je höchstens 25.000 Iterationen oder 120 s. Morozov verwendet hier '
        body+='eine gespeicherte Tikhonov-Lösung als Startwert aus Messdaten; die Laufzeit '
        body+='enthält deren frühere Berechnung nicht. Der vollständige Primal-Dual-Zustand ist gespeichert.</p><ul>'
        for name,q,r in followups:
            body+='<li>'+html.escape(name)+': Optimum '+('bestätigt' if q['converged'] else 'offen')
            body+=', '+fmt(q['seconds'])+' s, Gap '+fmt(q['relativeGap'])+', KKT '+fmt(q['kkt'])
            body+=', χ² '+fmt(q['residual'])+', 2D-Fehler '+fmt(r['RelativeL2'],True)+'.</li>'
        body+='</ul><p>Ein gültiges Optimierergebnis ersetzt keine abgesicherte Regularisierungsparameterwahl. '
        body+='Die feste TV-Parameterkontrolle bleibt deshalb aus einer wissenschaftlichen Bestenauswahl ausgeschlossen.</p>'
    strong_followup=None
    path=ROOT/'outputs'/'strong_followup'/'ds00002_Tikhonov_LSQR_StrongPrecond.mat'
    if path.exists():
        strong_followup=loadmat(path,simplify_cells=True)
        q=strong_followup['info'];r=strong_followup['metrics']
        body+='<h3>Längere Tikhonov-Kontrolle bei rein relativem Rauschen</h3><p>'
        body+='40 äußere Schritte, höchstens 1.200 LSQR-Schritte je Schritt, höchstens 120 s, '
        body+='Start mit der gespeicherten kurzen Kontrolle. Ergebnis: Optimum '+('bestätigt' if q['converged'] else 'offen')
        body+=', KKT '+fmt(q['kkt'])+', 2D-Fehler '+fmt(r['RelativeL2'],True)
        body+=', '+fmt(q['seconds'])+' s zusätzlich zu '+fmt(strong_followup['warmStartSeconds'])+' s für den Startwert. '
        body+='Die Parameterwahl des Ausgangslaufs bleibt unbestätigt.</p>'
    body += '<p>2D-Fehler: flächengewichteter relativer L2-Fehler der differentiellen Verteilung. '
    body += 'Alle Ziele: zusätzlich Konzentration, beide GMD und beide GSD jeweils ≤5 %, '
    body += '2D-Fehler ≤20 %, mit gültigen numerischen Zertifikaten. Keine Bestenauswahl '
    body += 'aus nicht konvergierten Ergebnissen. Lognormal-fit bleibt ausgeschlossen. '
    body += 'POCS-CDMA verwendet simultane Punktbänder. Tikhonov und TV-PD verwenden '
    body += 'gewichtete Least-Squares-Ziele mit Discrepancy-Parameterwahl und Datenprüfung. '
    body += 'Nur TV-Morozov hat eine direkte Fehlerball-Nebenbedingung.</p>'
    body += '<h3>Eigener Punkt: Nebenbedingungen im POCS-Dual-Solver</h3><p>'
    body += 'Nichtnegativität und dₛₜ ≤ dₘ sind Teil des zulässigen Problems. '
    body += 'Alle Messbänder werden simultan geprüft. Unabhängig gemessene Gesamtzahl '
    body += 'und Randverteilungen können zusätzliche Bänder bilden; sie sind mangels '
    body += 'solcher Messdaten in den realen Kontrollen deaktiviert. Die Sollverteilung '
    body += 'liefert keine Nebenbedingungen. Unter dem dokumentierten Umrechnungsmodell '
    body += 'folgt dₛₜ ≤ dᵥ ≤ dₘ. Nicht jede denkbare Partikelform ist dadurch beschrieben.</p>'
    body += '<p><a href="V7_REPORT.txt">v7-Prüfbericht</a> · <a href="v7_controls.csv">Kontrollen (CSV)</a> · '
    body += '<a href="v7_fixtures.csv">Referenztests</a> · <a href="matlab-source-v7.zip">v7-Quellen</a></p>'
    body += '<p>Grundlagen: '+', '.join('<a href="'+u+'">'+t+'</a>' for t,u in sources)+'.</p></article>'
    (ROOT/'V7_WEB.html').write_text(body,encoding='utf-8')
    lines=['V7 EXPERIMENTAL SOLVER STUDY',stamp,intro,'',
           'Independent fixture status: '+checks,
           'Saved controls: '+str(len(rows))+' / 10 (two stored datasets x five arms).',
           'Not the complete 27-dataset benchmark; no automatic resume.',
           'Controls use identical stored y, sigma, B, physical mask and regularization operators.',
              'Optimizer comparisons use the same measurement-only alpha, initially x=0.',
              'Parent times include parameter selection, fixed-alpha controls do not: no speedup ratio inferred.',
           'Scientific truth is consulted only after a returned solution, for error metrics.',
           'Auxiliary measurements are optional; absent real controls, never taken from truth.',
           'Independent optimum, data compatibility, parameter validity and quality targets remain separate.','']
    for r in rows:
        old=baselines[r['Dataset']].get(METHODS[r['Method']],{})
        lines.append('%s %s: %ss; objective=%s data=%s parameter=%s validated=%s targets=%s; L2=%s (parent=%s); KKT=%s gap=%s budgetStopped=%s.'%(
            r['Dataset'],r['Method'],fmt(num(r,'Seconds')),r['ObjectiveConverged'],r['DataCompatible'],
            r['ParameterSelectionValid'],r['Validated'],r['TargetPass'],fmt(num(r,'RelativeL2'),True),fmt(num(old,'RelativeL2'),True),
            fmt(num(r,'CertificateKKT')),fmt(num(r,'CertificateRelativeGap')),r['BudgetStopped']))
    if followups:
        lines+=['','LONGER TV CONTROLS (not mixed into primary table)',
                'Max25000 iterations /120s; Morozov starts from stored measurement-only Tikhonov reconstruction.',
                'Its prior warm-start computation time is excluded. Full primal-dual state is retained.']
        for name,q,r in followups:
            lines.append('%s: optimum=%s seconds=%s gap=%s KKT=%s chi2=%s L2=%s.'%(
                name,q['converged'],fmt(q['seconds']),fmt(q['relativeGap']),fmt(q['kkt']),fmt(q['residual']),fmt(r['RelativeL2'],True)))
    if strong_followup:
        q=strong_followup['info'];r=strong_followup['metrics']
        lines+=['','LONGER STRONG-PRECONDITIONED TIKHONOV CONTROL',
                'Same ds2 / alpha; stored short control as warm start, no oracle.',
                'Max40 outer /1200 inner LSQR /120s; warm-start time listed separately.',
                'objective=%s KKT=%s L2=%s time=%ss plus warm-start=%ss; parent parameter valid=%s.'%(
                    q['converged'],fmt(q['kkt']),fmt(r['RelativeL2'],True),fmt(q['seconds']),
                    fmt(strong_followup['warmStartSeconds']),strong_followup['parentParameterSelectionValid'])]
    lines+=['','INTERPRETATION / RECOMMENDATION',
            'Tikhonov-Scaled is a promising numerical core for mixed noise: same solution, independently certified.',
            'Stronger LSQR preconditioning improves the relative-only reconstruction in this control, but remains uncertified.',
            'POCS-CDMA-Dual certifies the mixed case at the same minimum-norm solution: optimizer improvement, no accuracy improvement.',
            'The broad POCS-CDMA solution reflects its bin-mass norm prior and simultaneous point bands; it misses the shape targets.',
            'TV-PD needs more than the short budget for a strict feasible-dual gap. Independent parameter selection still needs verification.',
            'No new arm in the primary controls meets all numerical AND accuracy targets. No universal best solver is established.']
    lines += ['','LIMITS',
              'Finite caps: failure is not proof of infeasibility and not scientific success.',
              'Two representative stored controls with one noise realization; no robustness claim for all 27 cases.',
              'No relaxed noise weights, physical bounds, or stopping tolerance to force a passing result.',
              'TV-Morozov is a different discrepancy formulation; no alpha sweep is claimed.',
              'Numerical convergence does not guarantee an accurate reconstruction in an underdetermined inverse problem.',
              'Lognormal-fit is excluded from evaluation and remains registered in the full configuration.',
              'Morozov budget validity is audited independently of optimisation; exact declared ball is used for its data check.',
              'Original metadata before that correction is archived in outputs/solver_controls/metadata_before_audit.',
              'The optional POCS fmincon fallback was disabled in the real controls; no performance claim for that branch.',
              'START: addpath('"'"'%s'"'"'); run_v7_tests; run_v7_solver_controls;' % str(ROOT),
              'Do not call the inherited v6 full-run launcher from this exploratory directory.','',
              'PRIMARY/OFFICIAL SOURCES'] + [t+': '+u for t,u in sources]
    (ROOT/'V7_REPORT.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    (ROOT/'V7_STATUS.json').write_text(json.dumps({'updated':stamp,'savedControls':len(rows),
        'plannedControls':10,'fixtureFamilies':complete_families,'parentState':'paused',
        'separateExperimentalStudy':True},indent=2),encoding='utf-8')
    print(json.dumps({'controls':len(rows),'fixtures':complete_families,'report':str(ROOT/'V7_REPORT.txt')}))

if __name__=='__main__': build()
