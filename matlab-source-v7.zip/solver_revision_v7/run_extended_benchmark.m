function run_extended_benchmark(mode)
% run_extended_benchmark('pilot') for one noisy dataset; default all 27.
if nargin<1,mode='full';end
c=extended_config();maxNumCompThreads(1);
if strcmp(mode,'pilot'),c.outputRoot=fullfile(c.root,'outputs','pilot');c.notify=false;end
for name={'datasets','metrics'},if ~exist(fullfile(c.outputRoot,name{1}),'dir'),mkdir(fullfile(c.outputRoot,name{1}));end;end
[manifest,plan]=extended_plan(c);
writejson(fullfile(c.outputRoot,'config.json'),c);writejson(fullfile(c.outputRoot,'plan.json'),plan);
writetable(manifest,fullfile(c.outputRoot,'manifest.csv'));
if ~exist(fullfile(c.outputRoot,'common.mat'),'file'),copyfile(c.commonFile,fullfile(c.outputRoot,'common.mat'));end
common=load(c.commonFile);assert(common.g.n==108);
if strcmp(mode,'pilot'),indices=5;else,indices=[5 14 23 1 10 19 setdiff(1:height(manifest),[5 14 23 1 10 19],'stable')];end
pool=gcp('nocreate');if isempty(pool),pool=parpool('local',c.workers);end
shared=parallel.pool.Constant(common);f=parallel.FevalFuture.empty;
for i=indices,f(end+1)=parfeval(pool,@extended_dataset,1,c,manifest(i,:),shared);end
started=datestr(now,31);
lastExport=-Inf;lastExportCount=-1;clock=tic;progress('running');
while any(~strcmp({f.State},'finished'))
 if exist(fullfile(c.outputRoot,'STOP'),'file'),cancel(f);break;end
 progress('running');pause(5);drawnow;
end
errors=cellfun(@(e)~isempty(e),{f.Error});state='complete';
if any(errors)
 state='failed';fid=fopen(fullfile(c.outputRoot,'worker_errors.txt'),'w');
 for ei=find(errors),fprintf(fid,'%s\n',getReport(f(ei).Error,'extended','hyperlinks','off'));end
 fclose(fid);
end
if exist(fullfile(c.outputRoot,'STOP'),'file'),state='stopped';end
progress(state);
delete(shared);delete(pool);
if c.notify
 h=msgbox(sprintf('CDMA Benchmark: %s\n27 Datensaetze, %d Verfahren.\nErgebnisse: %s',state,numel(c.methods),c.outputRoot),'CDMA Benchmark beendet');
 uiwait(h);
end
 function progress(state)
  files=dir(fullfile(c.outputRoot,'metrics','ds*.csv'));completed=0;conv=0;failed=0;validated=0;dataCompatible=0;
  for j=1:numel(files)
   try
    r=readtable(fullfile(files(j).folder,files(j).name));completed=completed+height(r);
    conv=conv+sum(r.Converged);failed=failed+sum(~r.Success);
    validated=validated+sum(r.Validated);dataCompatible=dataCompatible+sum(r.DataCompatible);
   catch,end
  end
  writejson(fullfile(c.outputRoot,'progress.json'),struct('state',state,'started',started, ...
   'updated',datestr(now,31),'completedSolverRuns',completed,'totalSolverRuns',numel(indices)*numel(c.methods), ...
   'converged',conv,'objectiveConverged',conv,'validated',validated, ...
   'dataCompatible',dataCompatible,'failed',failed,'datasets',numel(indices), ...
   'measurementCount',size(common.A,1),'binsPerDecade',c.binsPerDecade, ...
   'noisePolicy',c.noisePolicy,'version',c.version,'assessmentExcludes',{{'Lognormal-fit'}}));
  if (completed~=lastExportCount && toc(clock)-lastExport>=c.exportIntervalSeconds) || ~strcmp(state,'running')
   v6_export_checkpoint(c);lastExport=toc(clock);lastExportCount=completed;
  end
 end
end
function writejson(file,obj)
tmp=[file '.tmp'];fid=fopen(tmp,'w');fwrite(fid,jsonencode(obj),'char');fclose(fid);movefile(tmp,file,'f');
end
