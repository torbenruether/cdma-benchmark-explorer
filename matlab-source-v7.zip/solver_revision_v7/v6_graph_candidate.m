function [x,info,state]=v6_graph_candidate(p,t,alpha,state,cap)
% Over-relaxed two-block ADMM. Boyd et al. sections 3.3/3.4; relative
% penalty adaptation follows Wohlberg's scale-invariance analysis (2017).
if t.order==1,tol=p.c.tolerance;else,tol=p.c.tgvTolerance;end
if isempty(state)
 u=zeros(t.nvar,1);if isfield(p,'revisionWarmStart'),u(1:t.n)=max(p.revisionWarmStart,0);end
 z=t.D*u;y=zeros(size(z));rho=max(1,alpha);
else,u=state.u;z=state.z;y=state.y;rho=state.rho;end
converged=false;relaxation=1.6;rhoUpdates=0;
% Parameter changes retain physical (unscaled) multipliers, then project
% regularizer multipliers into the new conjugate balls.
offset=0;
for g=1:numel(t.widths)
 rows=offset+(1:t.n*t.widths(g));yy=reshape(y(rows),t.n,t.widths(g));
 radius=alpha*t.coefficients(g)*t.weights;mag=sqrt(sum(yy.^2,2));
 yy=yy./max(1,mag./max(radius,realmin));y(rows)=yy(:);offset=offset+numel(rows);
end
for k=1:cap
 oldz=z;consensus=t.D'*(z-y/rho);v=t.L\consensus(t.perm);pv=t.V'*v;
 % Range and null components evaluated separately, retaining all SVD values.
 yy=v-t.V*pv+t.V*((t.s.*t.ub+rho*pv)./(t.s.^2+rho));
 u=zeros(t.nvar,1);u(t.perm)=t.L'\yy;du=t.D*u;
 relaxed=relaxation*du+(1-relaxation)*oldz;v=relaxed+y/rho;z=v;offset=0;
 for g=1:numel(t.widths)
  rows=offset+(1:t.n*t.widths(g));vv=reshape(v(rows),t.n,t.widths(g));
  threshold=alpha*t.coefficients(g)*t.weights/rho;mag=sqrt(sum(vv.^2,2));
  vv=vv.*max(0,1-threshold./max(mag,realmin));z(rows)=vv(:);offset=offset+numel(rows);
 end
 z(t.pos)=max(v(t.pos),0);
 if ~isempty(t.slabs),z(t.slabs)=min(t.hi,max(t.lo,v(t.slabs)));end
 y=y+rho*(relaxed-z);
 primalAbs=norm(du-z);dualAbs=norm(rho*t.D'*(z-oldz));
 primal=primalAbs/max([1,norm(du),norm(z)]);dual=dualAbs/max(1,norm(t.D'*y));
 if mod(k,25)==0 || k==cap || max(primal,dual)<=tol
  auditU=u;auditU(1:t.n)=z(t.pos);x=auditU(1:t.n);r=p.B*x-p.b;
  station=t.B'*r+t.D'*y;kkt=norm(station,inf)/t.rhsInf;
  reg=t.Dreg*auditU;regularizer=0;offset=0;
  for g=1:numel(t.widths)
   rows=offset+(1:t.n*t.widths(g));vv=reshape(reg(rows),t.n,t.widths(g));
   regularizer=regularizer+alpha*t.coefficients(g)*sum(t.weights.*sqrt(sum(vv.^2,2)));offset=offset+numel(rows);
  end
  f=.5*(r'*r)+regularizer;
  % Fenchel-Young complementarity for feasible conjugate multipliers; this
  % augments residual checks without weakening their original tolerances.
  gap=regularizer-y(1:numel(reg))'*reg-y(t.pos)'*x;
  slabViolation=0;
  if ~isempty(t.slabs)
   value=t.D(t.slabs,:)*auditU;ys=y(t.slabs);
   gap=gap+max(ys,0)'*t.hi+min(ys,0)'*t.lo-ys'*value;
   slabViolation=max([0;t.lo-value;value-t.hi]);
  end
  complementarity=max(gap,0)/max(1,abs(f));clipImpact=norm(p.B*(x-u(1:t.n)));
  if max(primal,dual)<=tol && kkt<=tol && complementarity<=tol && clipImpact<=.01*sqrt(p.target) && slabViolation<=tol
   converged=true;break;
  end
 end
 % Finite adaptation followed by fixed-penalty ADMM retains standard
 % convergence assumptions. Physical multipliers require no rescaling.
 if mod(k,25)==0 && k<=min(2000,floor(cap/2))
  rp=primalAbs/max([norm(du),norm(z),1e-12]);
  rd=dualAbs/max([norm(t.D'*y),norm(t.rhs),1e-12]);oldrho=rho;
  if rp>10*rd,rho=rho*2;elseif rd>10*rp,rho=rho/2;end
  rho=min(max(rho,1e-12),1e20);rhoUpdates=rhoUpdates+(rho~=oldrho);
 end
end
x=z(t.pos);info=struct('iterations',k,'converged',converged,'objective',f, ...
 'primalResidual',primal,'dualResidual',dual,'kkt',kkt,'stationarityResidual',kkt, ...
 'complementarityGap',complementarity,'clippingMeasurementImpact',clipImpact, ...
 'slabViolation',slabViolation,'rho',rho,'rhoUpdates',rhoUpdates,'relaxation',relaxation, ...
 'algorithm','Over-relaxed two-block ADMM, sparse Cholesky/direct SVD, finite relative-residual penalty adaptation', ...
 'stopping','Original strict primal/dual residuals plus independent original-objective KKT and Fenchel complementarity');
state=struct('u',u,'z',z,'y',y,'rho',rho);
end
