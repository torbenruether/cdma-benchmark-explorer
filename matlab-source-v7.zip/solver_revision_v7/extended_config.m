function c=extended_config()
% Three physical shapes x three relative x three peak-referenced absolute levels.
c.root=fileparts(mfilename('fullpath'));addpath(c.root,fullfile(c.root,'core'));
c=merge(c,cdma_config); c.version='7.0-experimental-solvers';
c.binsPerDecade=64;c.rangeNm=10.^([84 192]/64);c.nBins=108;
c.pairsNm=[250 50;315 60;400 75];c.gsd=1.30;c.totalN=1e5;
c.relativeLevels=[0 .03 .05];c.absoluteLevels=[0 .03 .05];
c.replicates=1;c.seed=20261005;c.weightFloorCm3=1e-6;
c.outputRoot=fullfile(c.root,'outputs','factorial27_v7');
c.commonFile=fullfile(c.root,'cache','common.mat');
c.measurementCount=1224;c.positiveVoltageLevels=24;c.positiveRotationLevels=48;
c.fineFile=fullfile(fileparts(fileparts(c.root)),'outputs','mono_first_64bpd_20261005','forward_fine.mat');
c.methods={'POCS-PSS','Twomey-Markowski','Tikhonov','Tikhonov-lsqlin', ...
 'Lognormal-fit','TGV2-ADMM','TV-2D','Maximum Entropy','Bayesian GP-MAP','Huber-TV','POCS-CDMA', ...
 'Tikhonov-Scaled','Tikhonov-LSQR-StrongPrecond','POCS-CDMA-Dual','TV-PD','TV-Morozov-PD'};
c.workers=2;c.threadsPerWorker=2;c.notify=true;c.pathMultipliers=[0 logspace(-6,4,17)];
c.maxIterations=4000;c.tgvIterations=12000;c.tgvTolerance=2e-5;
c.revisionNewtonIterations=180;c.revisionPCGIterations=250;
c.revisionPathNewtonIterations=40;c.revisionPathPCGIterations=100;
c.revisionSelectedNewtonIterations=400;c.revisionAlphaRefinements=5;c.revisionTrace=true;
c.pocsIterations=15000;c.legacyIterations=1500;
c.tgvAlpha=logspace(-7,1,13);c.tgvRatio=2;
% No independent total or marginal measurement supplied: never take it from truth.
c.aux=struct('total',[],'dm',[],'dst',[],'tolerance',[]);
% Preserve declared additive Gaussian noise; fitted weights remain observed-signal proxies.
c.clipNegative=false;c.poissonEnabled=false;
c.noisePolicy='Signed additive Gaussian deviations; no negative-measurement clipping; nonnegative reconstruction';
c.exportPython='C:\Program Files\Python38\python.exe';c.exportIntervalSeconds=30;
end
function c=merge(c,b)
f=fieldnames(b);for i=1:numel(f),c.(f{i})=b.(f{i});end
end
